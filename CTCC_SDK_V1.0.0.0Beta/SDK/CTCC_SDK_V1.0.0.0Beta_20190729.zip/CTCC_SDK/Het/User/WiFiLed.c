/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, Bernie Liu
*   @File Name        : WiFiLed.c
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2019-06-25
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

/******************************************************************************\
*   @includes
\******************************************************************************/
#include "User_Define.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

typedef struct _tWiFiLed
{
    uint8_t     Mode;
    T_SoftTimer SoftTmr;
}T_WiFiLed, *P_WiFiLed;

static T_WiFiLed s_WiFiLed;

const uint32_t   FlashTmrValTbl[WiFi_Flash_Mode_On] =
{
    2000, // WiFi_Flash_Mode_Off
    200,  // WiFi_Flash_Mode_StartSmartConfig
    1000, // WiFi_Flash_Mode_ConnectRouter
};

/******************************************************************************\
*   @Functions
\******************************************************************************/

/******************************************************************************/
void WiFiLed_SetLed(uint8_t OnOff)
/******************************************************************************/
{
    HAL_GPIO_Write(PIN_LED1, OnOff);
}

/******************************************************************************/
void WiFiLed_ToggleLed(void)
/******************************************************************************/
{
    HAL_GPIO_Toggle(PIN_LED1);
}

/******************************************************************************/
void WiFiLed_Config(void)
/******************************************************************************/
{
    T_GpioParams myGpio;
    myGpio.Speed = H_GPIO_SPEED_FREQ_LOW;
    myGpio.Value = LED_SW_Off;
    myGpio.Mode  = H_GPIO_MODE_OUTPUT;
    myGpio.Pin   = PIN_LED1;
    myGpio.Pull  = H_GPIO_PULL_None;
    HAL_GPIO_Open(&myGpio);

    WiFiLed_SetFlashMode(WiFi_Flash_Mode_Off);

    LOGD("\r\n[WiFiLed_Config]Start...\r\n");
}

/******************************************************************************/
void WiFiLed_Loop(void)
/******************************************************************************/
{
    if (WiFi_Flash_Mode_On == s_WiFiLed.Mode)
    {
        WiFiLed_SetLed(LED_SW_On);
    }
    else
    {
        if (E_OK == SoftTimer_IsTimeout(&s_WiFiLed.SoftTmr))
        {
            SoftTimer_Open(&s_WiFiLed.SoftTmr, (FlashTmrValTbl[s_WiFiLed.Mode]));
            WiFiLed_ToggleLed();
        }
    }
}

/******************************************************************************/
void WiFiLed_SetFlashMode(uint8_t Mode)
/******************************************************************************/
{
    s_WiFiLed.Mode = Mode;

    if (s_WiFiLed.Mode < WiFi_Flash_Mode_On)
    {
        SoftTimer_Open(&s_WiFiLed.SoftTmr, (FlashTmrValTbl[s_WiFiLed.Mode]));
    }
    else
    {
        SoftTimer_Close(&s_WiFiLed.SoftTmr);
    }
}

/******************************* End of File (C) ******************************/

