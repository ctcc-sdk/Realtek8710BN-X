/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, Bernie Liu
*   @File Name        : KeyBtn.c
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2019-06-25
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

/******************************************************************************\
*   @includes
\******************************************************************************/
#include "User_Define.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

#define SW_STARTUP_STATUS    (SW_OFF)

typedef struct _SwParams
{
    uint8_t Pin;
    uint8_t Ststus;
    uint8_t StstusBak;
}T_SwParams, *P_SwHandle;

static T_SwParams s_SwParam[PRODUCT_CHANNEL_NUM] =
{
    { PIN_RLY, SW_STARTUP_STATUS, SW_STARTUP_STATUS },
};

/******************************************************************************\
*   @Functions
\******************************************************************************/

/******************************************************************************/
void Switcher_Config(void)
/******************************************************************************/
{
    T_GpioParams myGpio;
    myGpio.Speed = H_GPIO_SPEED_FREQ_LOW;
    myGpio.Value = SW_STARTUP_STATUS;
    myGpio.Mode  = H_GPIO_MODE_OUTPUT;
    myGpio.Pull  = H_GPIO_PULL_UP;
    
    int index;
    for (index = 0; index < PRODUCT_CHANNEL_NUM; index++)
    {
        s_SwParam[index].Ststus    = SW_STARTUP_STATUS;
        s_SwParam[index].StstusBak = s_SwParam[index].Ststus;

        myGpio.Pin = s_SwParam[index].Pin;
        HAL_GPIO_Open(&myGpio);
    }

    LOGD("\r\n[USR]Switcher_Config...\r\n");
}

/******************************************************************************/
void Switcher_Loop(void)
/******************************************************************************/
{
    /* Do Nothing */
}

/******************************************************************************/
void Switcher_StatusUpdate(void)
/******************************************************************************/
{
    int index, NeedReportChannel = 0;

    for (index = 0; index < PRODUCT_CHANNEL_NUM; index++)
    {
        if (s_SwParam[index].StstusBak != s_SwParam[index].Ststus)
        {
            /* 若多路，需分别判断 */
            s_SwParam[index].StstusBak = s_SwParam[index].Ststus;
            NeedReportChannel         |= (1 << index);
        }
    }

    if (NeedReportChannel > 0)
    {
        /* 上报状态 Code here */
        CP_StatusReport(NeedReportChannel);
        LOGD("\r\n[Switcher_Loop]Update Status Report...\r\n");
    }
}

/******************************************************************************/
void Switcher_Toggle(uint8_t Channel)
/******************************************************************************/
{
    int index = 0;
    for (index = 0; index < PRODUCT_CHANNEL_NUM; index ++)
    {
        if ((CHANNEL_ALL == Channel) || (Channel == (index + 1)))
        {
            HAL_GPIO_Toggle(s_SwParam[index].Pin);
            s_SwParam[index].Ststus = !s_SwParam[index].Ststus;
        }
    }
}

/******************************************************************************/
void Switcher_Write(uint8_t Channel, uint8_t Sw)
/******************************************************************************/
{
    int index = 0;
    for (index = 0; index < PRODUCT_CHANNEL_NUM; index ++)
    {
        if ((CHANNEL_ALL == Channel) || (Channel == (index + 1)))
        {
            HAL_GPIO_Toggle(s_SwParam[index].Pin);
            s_SwParam[index].Ststus = !s_SwParam[index].Ststus;
        }
    }
}

/******************************************************************************/
void Switcher_SetCtrl(uint8_t Channel, uint8_t Sw)
/******************************************************************************/
{
    if (SW_TOGGLE == Sw)
    {
        Switcher_Toggle(Channel);
    }
    else
    {
        Switcher_Write(s_SwParam[Channel].Pin, Sw);
    }
}

/******************************************************************************/
uint8_t Switcher_GetCtrl(uint8_t Channel)
/******************************************************************************/
{
    return s_SwParam[Channel].Ststus;
}

/******************************* End of File (C) ******************************/

