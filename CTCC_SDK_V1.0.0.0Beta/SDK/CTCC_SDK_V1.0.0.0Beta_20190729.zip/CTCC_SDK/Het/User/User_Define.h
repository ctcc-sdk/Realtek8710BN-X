/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, Bernie Liu
*   @File Name        : KeyBtn.h
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2019-06-25
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _User_Define_H_
#define _User_Define_H_


/******************************************************************************\
*   @includes Midlle Layer
\******************************************************************************/
#include <stdint.h>
#include "../HetLib/HOS_Inc.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

#define PIN_LED1   (H_GPIO_PIN_13)
#define PIN_KEY    (H_GPIO_PIN_14)
#define PIN_RLY    (H_GPIO_PIN_17)

#define PRODUCT_CHANNEL_MAX    (3) // 协议最大支持路数
#define PRODUCT_CHANNEL_NUM    (1) // 当前设备路数

/******************************************************************************\
*   @includes USer Layer
\******************************************************************************/

#include "ComProtocol.h"
#include "UserEntrance.h"
#include "KeyBtn.h"
#include "Switcher.h"
#include "WiFiLed.h"

#endif /* _User_Define_H_*/

/******************************* End of File (H) ******************************/

