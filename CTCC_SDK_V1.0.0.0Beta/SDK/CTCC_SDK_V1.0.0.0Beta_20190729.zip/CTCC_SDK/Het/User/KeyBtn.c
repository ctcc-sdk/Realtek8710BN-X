/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, Bernie Liu
*   @File Name        : KeyBtn.c
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2019-06-25
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

/******************************************************************************\
*   @includes
\******************************************************************************/
#include "User_Define.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

enum
{
    KeyBtn_Status_None = 0x0,
    KeyBtn_Status_Short,
    KeyBtn_Status_Short_Release,
    KeyBtn_Status_Short_Chk,
    KeyBtn_Status_Long,
    KeyBtn_Status_Long_Release,
    KeyBtn_Status_Max
};

typedef struct _tKeyBtn
{
    uint8_t  KeyStatus;
    uint32_t Counter;
}T_KeyBtn, *P_KeyBtn;

static T_KeyBtn s_tKeyBtn;

/******************************************************************************\
*   @Functions
\******************************************************************************/

/******************************************************************************/
void KeyBtn_Config(void)
/******************************************************************************/
{
    T_GpioParams myGpio;

    myGpio.Speed = H_GPIO_SPEED_FREQ_LOW;
    myGpio.Mode  = H_GPIO_MODE_INPUT;
    myGpio.Pull  = H_GPIO_PULL_None;
    myGpio.Pin   = PIN_KEY;
    myGpio.Value = 0;
    HAL_GPIO_Open(&myGpio);

    memset((uint8_t*)(&s_tKeyBtn), 0, sizeof(T_KeyBtn));

    LOGD("\r\n[USR]KeyBtn_Config...\r\n");
}

/******************************************************************************/
uint16_t KeyBtn_Loop(void)
/******************************************************************************/
{
    uint8_t  ReadKeyValue = 0;
    uint16_t RetKeyBtn    = KEY_BTN_NONE;

    if (E_OK == HAL_GPIO_Read(PIN_KEY, &ReadKeyValue))
    {
        switch (s_tKeyBtn.KeyStatus)
        {
        case KeyBtn_Status_None:
        {
            if (ReadKeyValue)
            {
                //LOGD("\r\n[KeyBtn]Start KeyBtn Trig");
                s_tKeyBtn.KeyStatus++;
                s_tKeyBtn.Counter = 0;
            }
        }
        break;

        case KeyBtn_Status_Short:
        {
            if (ReadKeyValue)
            {
                if (s_tKeyBtn.Counter >= TIME_SHORTKEY_MIN)
                {
                    //LOGD("\r\n[KeyBtn]Short Key Trig");
                    s_tKeyBtn.KeyStatus++;
                }
            }
            else
            {
                s_tKeyBtn.KeyStatus--;
            }
        }
        break;

        case KeyBtn_Status_Short_Release:
        {
            if (ReadKeyValue)
            {
                if (s_tKeyBtn.Counter >= TIME_SHORTKEY_MAX)
                {
                    //LOGD("\r\n[KeyBtn]Long Key Trig");
                    s_tKeyBtn.KeyStatus = KeyBtn_Status_Long;
                }
            }
            else
            {
                if (s_tKeyBtn.Counter >= TIME_SHORTKEY_CENTER)
                {
                    //LOGD("\r\n[KeyBtn]Short Key Release");
                    s_tKeyBtn.KeyStatus++;
                    s_tKeyBtn.Counter = 0;
                }
                else
                {
                    s_tKeyBtn.KeyStatus = KEY_BTN_NONE;
                }
            }
        }
        break;

        case KeyBtn_Status_Short_Chk:
        {
            if (!ReadKeyValue)
            {
                if (s_tKeyBtn.Counter >= TIME_SHORTKEY_MIN)
                {
                    //LOGD("\r\n[KeyBtn]Short Key Release");
                    s_tKeyBtn.KeyStatus = KEY_BTN_NONE;
                    RetKeyBtn           = KEY_BTN_SW;
                }
            }
        }
        break;

        case KeyBtn_Status_Long:
        {
            if (ReadKeyValue)
            {
                if (s_tKeyBtn.Counter >= TIME_LONGKEY)
                {
                    //LOGD("\r\n[KeyBtn]Long Key Trig");
                    s_tKeyBtn.KeyStatus++;
                    RetKeyBtn = KEY_BTN_SMARTCONFIG;
                }
            }
            else
            {
                s_tKeyBtn.KeyStatus = KEY_BTN_NONE;
            }
        }
        break;

        case KeyBtn_Status_Long_Release:
        {
            if (!ReadKeyValue)
            {
                //LOGD("\r\n[KeyBtn]Long Key Release");
                s_tKeyBtn.KeyStatus = KEY_BTN_NONE;
            }
        }
        break;

        default:
        {
        }
        break;
        }
        s_tKeyBtn.Counter++;
    }

    return RetKeyBtn;
}

/******************************* End of File (C) ******************************/

