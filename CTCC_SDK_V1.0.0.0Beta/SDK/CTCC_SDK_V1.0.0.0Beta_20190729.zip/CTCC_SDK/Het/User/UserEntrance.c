/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, Bernie Liu
*   @File Name        : UserMain.c
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2018-05-18
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

/******************************************************************************\
*   @includes
\******************************************************************************/
#include "User_Define.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

#define CHK_STATUS_TMR        (1000)
#define CHK_WAIT_READY_TMR    (2000)

static T_SoftTimer s_EntranceSoftTmr;

static uint8_t     s_WiFiStatus = { 0 };

static U_BYTE      s_SysFlags;
#define SYS_FLAG_PWRON    s_SysFlags.Bits.B0
#define SYS_FLAG_BIND     s_SysFlags.Bits.B1

/******************************************************************************\
*   @Functions
\******************************************************************************/

/******************************************************************************/
uint8_t Get_WiFiStatus(void)
/******************************************************************************/
{
    return s_WiFiStatus;
}

/******************************************************************************/
void WiFiStatusUnpack(uint8_t WiFiStatus)
/******************************************************************************/
{
    if (s_WiFiStatus != WiFiStatus)
    {
        s_WiFiStatus = WiFiStatus;
        LOG_DBG_PRINTF("WiFiStatus = %d", WiFiStatus);

        if (NET_LINK_OK(s_WiFiStatus))
        {
            /* 所有连接OK，表示可以正常通讯了，WiFi指示灯常亮 */
            WiFiLed_SetFlashMode(WiFi_Flash_Mode_On);

            if (V_TRUE == SYS_FLAG_BIND)
            {
                SYS_FLAG_BIND = V_FALSE;
            }

            if (NET_RDY_OK(s_WiFiStatus))
            {
                /* Profile 已准备好 */
                CP_StatusReport(CHANNEL_ALL);
            }
        }
        else if (NET_BUSY(s_WiFiStatus))
        {
            LOG_DBG_PRINTF("Modual is Busy!!!");
            /* BUSY，慢闪 */
            WiFiLed_SetFlashMode(WiFi_Flash_Mode_Busy);
        }
        else
        {
            if (V_FALSE == SYS_FLAG_BIND)
            {
                /* 非绑定模式下，未连接服务器，慢闪 */
                WiFiLed_SetFlashMode(WiFi_Flash_Mode_Off);
            }
        }
    }
}

/******************************************************************************/
void User_RecvCallback(uint8_t *pBuf, uint16_t Len)
/******************************************************************************/
{
    uint8_t    Result = 0;
    T_ComFrame myFrame;

    if (E_OK == OPP_COM_GetFrameStruct(&myFrame, pBuf, Len))
    {
        /* 符合一帧数据条件 */
        //LOG_DBG_RAW("[User_RecvCallback]Get Com Frame:\r\n", pBuf, Len);

        if ((myFrame.Head.Resullt & 0xF0) > 0)
        {
            LOG_DBG_PRINTF("Ack Error:");
        }

        switch (myFrame.Head.Code)
        {
        case EV_StatusQuery:        //设备状态查询
        {
            // 回复EV_StatusQuery_Ack;
            CP_StatusQueryAck();
        }
        break;

        case EV_StatusControl:        //设备状态控制请求
        {
            // EV_StatusControl_Ack;
            //LOG_DBG_RAW("[User_RecvCallback]Get Com Frame:\r\n", pBuf, Len);
            Result = CP_StatusControlUnpack(myFrame.pDataBuf, myFrame.DataLen);
            HOS_Write(EV_StatusControl_Ack, Result, V_NULL, 0);
        }
        break;

        case EV_StatusReportAck:        //设备状态上报ACK
        {
            LOG_DBG_PRINTF("[User_RecvCallback]EV_StatusReportAck...");
        }
        break;

        case EV_HeartBeat_Ack:         //心跳ACK
        {
            /* WiFi Status */
            WiFiStatusUnpack(*(myFrame.pDataBuf));
        }
        break;

        case EV_Bind_Ack:        //设备绑定ACK
        {
            SYS_FLAG_BIND = 1;
            WiFiLed_SetFlashMode(WiFi_Flash_Mode_StartSmartConfig);
            LOG_DBG_PRINTF("[User_RecvCallback]EV_Bind_Ack...");
        }
        break;

        case EV_FCT_Ack:        //设备产测ACK
        {
            LOG_DBG_PRINTF("[User_RecvCallback]EV_FCT_Ack...");
        }
        break;

        default:
        {
        }
        break;
        }
    }
}

/******************************************************************************/
void User_EventCallback(int Event)
/******************************************************************************/
{
}

/******************************************************************************/
void User_Config(void)
/******************************************************************************/
{
    LOGD("\r\n[USR]User_Config...\r\n");
    HOS_SrvStart();
    HOS_RegisterRecvCallback((void*)User_RecvCallback);
    HOS_RegisterEventCallback((void*)User_EventCallback);

    /* User Code Here */
    Switcher_Config();
    KeyBtn_Config();
    WiFiLed_Config();
    SYS_FLAG_PWRON = V_FALSE;
    SoftTimer_Open(&s_EntranceSoftTmr, CHK_WAIT_READY_TMR);
}

/******************************************************************************/
void User_Loop(void)
/******************************************************************************/
{
    if (!SYS_FLAG_PWRON)
    {
        if (E_OK == SoftTimer_IsTimeout(&s_EntranceSoftTmr))
        {
            SYS_FLAG_PWRON = V_TRUE;
        }
    }
    else
    {
        uint16_t KeyValue = KeyBtn_Loop();

        switch (KeyValue)
        {
        case KEY_BTN_SW:
        {
            Switcher_Toggle(CHANNEL_ALL);
            LOGD("\r\n[USR]Key Btn Event Sw...\r\n");
        }
        break;

        case KEY_BTN_SMARTCONFIG:
        {
            CP_Bind();
            LOGD("\r\n[USR]Key Btn Event SmartConfig...\r\n");
        }
        break;
        }

        Switcher_Loop();

        if (E_OK == SoftTimer_IsTimeout(&s_EntranceSoftTmr))
        {
            //LOGD("\r\n[USR]CP_HeartBeat...\r\n");
            /* 1S 刷新检测状态变化 */
            SoftTimer_Open(&s_EntranceSoftTmr, CHK_STATUS_TMR);

            if (NET_RDY_OK(s_WiFiStatus))
            {
                CP_StatusUpdate();
            }

            CP_HeartBeat();
        }
    }

    WiFiLed_Loop();
}

/******************************************************************************/
void TaskCode_User(void* arg)
/******************************************************************************/
{
    User_Config();

    while (1)
    {
        HAL_OS_Delay(TASK_USR_SLEEP);
        User_Loop();
    }
}

/******************************************************************************/
void User_Main(void)
/******************************************************************************/
{
    if (E_OK != HAL_OS_CreatTask(TaskCode_User, "User", 2048, 1, V_NULL))
    {
        LOGD("\n\r%s xTaskCreate failed\r\n", __FUNCTION__);
    }
}
/******************************* End of File (C) ******************************/

