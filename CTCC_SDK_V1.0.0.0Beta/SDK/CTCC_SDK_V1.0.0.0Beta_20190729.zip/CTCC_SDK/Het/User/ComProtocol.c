/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, Bernie Liu
*   @File Name        : ComProtocol.c
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2019-06-25
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

/******************************************************************************\
*   @includes
\******************************************************************************/
#include "User_Define.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

/* 以下信息仅供调试使用 */
#define TEST_MODE                 (1)
#if TEST_MODE
/* 以下数据为编写数据，测试开发需根据开发者网站生成的产品信息填写 */
#define TEST_DEV_INFO_DeviceID    "00B0150102030110223157465353380025"
#define TEST_DEV_INFO_PIN         "74823570845809769299905093946350"
#define TEST_DEV_INFO_CTEI        "180600000000007"
#endif

/******************************************************************************\
*   @Functions
\******************************************************************************/

/******************************************************************************/
void CP_HeartBeat(void)
/******************************************************************************/
{
    HOS_Write(EV_HeartBeat, 0, NULL, 0);
}

/******************************************************************************/
void CP_Bind(void)
/******************************************************************************/
{
#if TEST_MODE
    // 非样机测试的DeviceID，PIN，CTEI码由产测写入模组
    HOS_BaseInfoConfig(TEST_DEV_INFO_DeviceID, TEST_DEV_INFO_PIN, TEST_DEV_INFO_CTEI);
#endif

    HOS_Connection_Config(0);
}

/******************************************************************************/
int  CP_StatusControlUnpack(uint8_t *pDataBuf, uint16_t Len)
/******************************************************************************/
{
    uint8_t  tmp, channel = 0;
    uint16_t Index = 0;
    int      ret   = E_FAIL;

    for (Index = 0; Index < Len;)
    {
        tmp = *(pDataBuf + Index);

        switch (tmp)
        {
        case CODE_ID_CHANNEL:
        {
            channel = *(pDataBuf + Index + 1);
            Index  += 2;
        }
        break;

        case CODE_ID_SET_POWER:
        {
            /* 判断TYPE，LEN */
            if ((TYPE_VALUE == *(pDataBuf + Index + 1))
                && (1 == *(pDataBuf + Index + 2)))
            {
                Switcher_SetCtrl(channel, *(pDataBuf + Index + 3));
                LOG_DBG_PRINTF("[CP_StatusControlUnpack] Sw0 = %d", *(pDataBuf + Index + 3));
            }

            LOG_DBG_PRINTF("[CP_StatusControlUnpack] Sw1 = %d", *(pDataBuf + Index + 3));
            Index += (3 + 1);
            ret    = E_OK;
        }
        break;

        default:
        {
            LOG_DBG_PRINTF("[CP_StatusControlUnpack]ID Not Support: %d", tmp);
        }
        break;
        }
    }

    RETURN(ret);
}

/******************************************************************************/
static uint16_t  CP_StatusPak(uint8_t* pDesBuf, uint8_t ChannelSel)
/******************************************************************************/
{
    int      index;
    uint16_t BufLen = 0;

    for (index = 0; index < PRODUCT_CHANNEL_NUM; index++)
    {
        if ((CHANNEL_ALL == ChannelSel) || (ChannelSel & (1 << index)) > 0)
        {
            pDesBuf[BufLen++] = CODE_ID_CHANNEL;         // ID
            pDesBuf[BufLen++] = index;                   // Channel

            pDesBuf[BufLen++] = CODE_ID_POWER;           // ID
            pDesBuf[BufLen++] = TYPE_VALUE;              // TYPE
            pDesBuf[BufLen++] = 1;                       // LEN
            pDesBuf[BufLen++] = Switcher_GetCtrl(index); // Value
            LOG_DBG_PRINTF("[CP_StatusPak] ID =%d, status = %d", index, Switcher_GetCtrl(index));
        }
    }

    return BufLen;
}

/******************************************************************************/
static uint16_t  CP_ResourcePak(uint8_t* pDesBuf, uint8_t Channel,
                                uint8_t Id, uint8_t *strInfo, uint8_t Len)
/******************************************************************************/
{
    /* 资源格式为：
     * ID：CONSUM 的对应ID
     * TYPE：字符串类型，RESOURCE_ID_TYPE
     * LEN：实际资源的字符串长度
     * VALUE：资源信息
     * 例子：
     * CONSUM TYPE LEN VALUE
     * 3      3    73  "[{"CONSUM_ID":"348749488","CONSUM_NAME":"MAIN_FILTER","REMAIN_LIFE":"87"}]"
     *
     */
    uint16_t BufLen = 0;

    pDesBuf[BufLen++] = CODE_ID_RESOURCE_CHANNEL; // ID
    pDesBuf[BufLen++] = Channel;                  // Channel

    pDesBuf[BufLen++] = Id;                       // ID
    pDesBuf[BufLen++] = TYPE_STRING;              // TYPE
    pDesBuf[BufLen++] = Len;                      // LEN
    HAL_OS_memcmp((pDesBuf + BufLen), strInfo, Len);
    BufLen += Len;
    LOG_DBG_PRINTF("[CP_StatusPak] ID =%d, status = %s", Id, strInfo);

    return BufLen;
}

/******************************************************************************/
static uint16_t  CP_StatusWarInfoPak(uint8_t* pDesBuf, uint8_t Channel,
                                     uint8_t Id, uint32_t value,
                                     uint8_t *strInfo, uint8_t Len)
/******************************************************************************/
{
    /* 状态告警格式为：
     * ID：对应ID
     * TYPE：TYPE_VALUE
     * LEN：4
     * VALUE：40
     * len: Len
     * value:"空调温度过高"
     * time:1361542433
     */
    uint16_t BufLen = 0;
    uint32_t Temp   = value;

    pDesBuf[BufLen++] = CODE_ID_RESOURCE_CHANNEL; // ID
    pDesBuf[BufLen++] = Channel;                  // Channel

    pDesBuf[BufLen++] = Id;                       // ID
    pDesBuf[BufLen++] = TYPE_VALUE;               // TYPE
    pDesBuf[BufLen++] = 4;                        // LEN
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 24);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 16);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 8);
    pDesBuf[BufLen++] = (uint8_t)(Temp);

    pDesBuf[BufLen++] = Len;
    HAL_OS_memcmp((pDesBuf + BufLen), strInfo, Len);
    BufLen += Len;

    Temp              = HOS_GetTimeStamp();
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 24);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 16);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 8);
    pDesBuf[BufLen++] = (uint8_t)(Temp);

    LOG_DBG_PRINTF("[CP_EventInfoPak] channel = %d, ID =%d, status = %s", Channel, Id, strInfo);

    return BufLen;
}

/******************************************************************************/
static uint16_t  CP_EventInfoPak(uint8_t* pDesBuf, uint8_t Channel,
                                 uint8_t Id, uint8_t *strInfo, uint8_t Len)
/******************************************************************************/
{
    /* 事件信息格式为：
     * ID：LOCK_OPEN 的对应ID
     * TYPE：字符串类型，TYPE_STRING
     * LEN：实际资源的字符串长度
     * VALUE：资源信息
     * 例子：
     * ID     TYPE   LEN     VALUE
     * 4      3      73      "[{"KEY_ID":"1","KEY_TYPE":"1","TIME":"1361542433"}]"
     */
    uint16_t BufLen = 0;

    pDesBuf[BufLen++] = CODE_ID_RESOURCE_CHANNEL; // ID
    pDesBuf[BufLen++] = Channel;                  // Channel

    pDesBuf[BufLen++] = Id;                       // ID
    pDesBuf[BufLen++] = TYPE_STRING;              // TYPE
    pDesBuf[BufLen++] = Len;                      // LEN
    HAL_OS_memcmp((pDesBuf + BufLen), strInfo, Len);
    BufLen += Len;
    LOG_DBG_PRINTF("[CP_EventInfoPak] channel = %d, ID =%d, status = %s", Channel, Id, strInfo);

    return BufLen;
}

/******************************************************************************/
static uint16_t  CP_ErrorInfoPak(uint8_t* pDesBuf, uint8_t Channel,
                                 uint32_t ErrorCode,
                                 uint8_t *strErrorInfo, uint8_t ErrorInfoLen)
/******************************************************************************/
{
    /* 错误故障格式为：
     * LEN：6
     * VALUE："100001"
     * len: 5
     * value:"XXXXX"
     * time:1361542433
     */
    uint16_t BufLen = 0;
    uint32_t Temp   = ErrorCode;

    pDesBuf[BufLen++] = CODE_ID_CHANNEL;     // ID
    pDesBuf[BufLen++] = Channel;             // Channel

    pDesBuf[BufLen++] = (uint8_t)(Temp >> 24);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 16);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 8);
    pDesBuf[BufLen++] = (uint8_t)(Temp);

    pDesBuf[BufLen++] = ErrorInfoLen;
    HAL_OS_memcmp((pDesBuf + BufLen), strErrorInfo, ErrorInfoLen);
    BufLen += ErrorInfoLen;

    Temp              = HOS_GetTimeStamp();
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 24);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 16);
    pDesBuf[BufLen++] = (uint8_t)(Temp >> 8);
    pDesBuf[BufLen++] = (uint8_t)(Temp);

    LOG_DBG_PRINTF("[CP_EventInfoPak] channel = %d, ErrorCode =%d, status = %s", Channel, ErrorCode, strErrorInfo);

    return BufLen;
}

/******************************************************************************/
void CP_StatusReportAfterLinkOk(void)
/******************************************************************************/
{
    /* 成功连接路由后的首次上报状态，若有资源也一并上报 */
    uint8_t *pDesBuf = (uint8_t*)HAL_OS_malloc(256); // 根据实际情况适当申请资源

    if (V_NULL == pDesBuf)
    {
        LOG_DBG_PRINTF("[CP_StatusReportAfterLinkOk] Malloc Failed");
        return;
    }
    uint16_t TempLen     = 0;
    uint16_t TotalBufLen = 0;
    TempLen      = CP_StatusPak(pDesBuf, CHANNEL_ALL); // 首次上报必须是所有状态一起上报
    TotalBufLen += TempLen;

#if 0
    /* 若有资源, Code     here */
    TempLen = CP_ResourcePak((pDesBuf + TotalBufLen), 1, CODE_ID_RESOURCE_CONSUM,
                             RESOURCE_DEMO_INFO, strlen(RESOURCE_DEMO_INFO)); // 首次上报必须是所有状态一起上报
    TotalBufLen += TempLen;
#endif

    HOS_StatusReport(pDesBuf, TotalBufLen);
    HAL_OS_free(pDesBuf);
}


/******************************************************************************/
void CP_StatusReport(uint8_t ChannelSel)
/******************************************************************************/
{
    uint8_t  pDesBuf[16];
    uint16_t BufLen = CP_StatusPak(pDesBuf, ChannelSel);

    HOS_StatusReport(pDesBuf, BufLen);
}

/******************************************************************************/
void CP_ResouceReport(uint8_t Channel, uint8_t Id,
                      uint8_t *strInfo, uint8_t Len)
/******************************************************************************/
{
    uint16_t TotalBufLen = 0;
    uint8_t  *pDesBuf    = (uint8_t*)HAL_OS_malloc(256); // 根据实际情况适当申请资源

    if (V_NULL == pDesBuf)
    {
        LOG_DBG_PRINTF("[CP_ResouceReport] Malloc Failed");
        return;
    }

    TotalBufLen = CP_ResourcePak((pDesBuf), 1, Id,
                                 strInfo, Len); // 根据资源变化上报

    HOS_ResourceReport(pDesBuf, TotalBufLen);

    HAL_OS_free(pDesBuf);
}

/******************************************************************************/
void CP_StatusQueryAck(void)
/******************************************************************************/
{
    uint8_t  pDesBuf[16];
    uint16_t BufLen = CP_StatusPak(pDesBuf, CHANNEL_ALL);

    HOS_Write(EV_StatusQuery_Ack, 0, pDesBuf, BufLen);
    CP_StatusReport(CHANNEL_ALL);
}

/******************************************************************************/
void CP_StatusWarnReport(uint8_t Channel, uint8_t Id, uint32_t value,
                         uint8_t *strInfo, uint8_t Len)
/******************************************************************************/
{
    uint16_t TotalBufLen = 0;
    uint8_t  *pDesBuf    = (uint8_t*)HAL_OS_malloc(256); // 根据实际情况适当申请资源

    if (V_NULL == pDesBuf)
    {
        LOG_DBG_PRINTF("[CP_StatusWarnReport] Malloc Failed");
        return;
    }

    TotalBufLen = CP_StatusWarInfoPak(pDesBuf, Channel, Id, value, strInfo, Len);

    HOS_EventInfoReport(pDesBuf, TotalBufLen);
    HAL_OS_free(pDesBuf);
}

/******************************************************************************/
void CP_EventInfoReport(uint8_t Channel, uint8_t Id, uint8_t *strInfo, uint8_t Len)
/******************************************************************************/
{
    uint16_t TotalBufLen = 0;
    uint8_t  *pDesBuf    = (uint8_t*)HAL_OS_malloc(256); // 根据实际情况适当申请资源

    if (V_NULL == pDesBuf)
    {
        LOG_DBG_PRINTF("[CP_EventInfoReport] Malloc Failed");
        return;
    }

    TotalBufLen = CP_EventInfoPak(pDesBuf, Channel, Id, strInfo, Len);

    HOS_EventInfoReport(pDesBuf, TotalBufLen);
    HAL_OS_free(pDesBuf);
}

/******************************************************************************/
void CP_ErrorInfoReport(uint8_t Channel, uint32_t ErrorCode,
                        uint8_t *strInfo, uint8_t Len)
/******************************************************************************/
{
    uint16_t TotalBufLen = 0;
    uint8_t  *pDesBuf    = (uint8_t*)HAL_OS_malloc(256); // 根据实际情况适当申请资源

    if (V_NULL == pDesBuf)
    {
        LOG_DBG_PRINTF("[CP_ErrorInfoReport] Malloc Failed");
        return;
    }

    TotalBufLen = CP_ErrorInfoPak(pDesBuf, Channel, ErrorCode, strInfo, Len);

    HOS_EventInfoReport(pDesBuf, TotalBufLen);
    HAL_OS_free(pDesBuf);
}

/******************************************************************************/
void CP_StatusUpdate(void)
/******************************************************************************/
{
    /* 调用应用状态更新接口 */
    Switcher_StatusUpdate();
}

/******************************* End of File (C) ******************************/

