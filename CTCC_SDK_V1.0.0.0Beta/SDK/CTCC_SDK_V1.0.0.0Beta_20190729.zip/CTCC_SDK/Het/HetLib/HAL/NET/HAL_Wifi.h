

#ifndef _HAL_Wifi_H
#define _HAL_Wifi_H

/******************************************************************************\
*                            Includes
\******************************************************************************/


/******************************************************************************\
*                         Macro definitions
\******************************************************************************/
/*Static IP ADDRESS*/
#ifndef IP_ADDR0
#define IP_ADDR0    192
#define IP_ADDR1    168
#define IP_ADDR2    1
#define IP_ADDR3    80
#endif

/*NETMASK*/
#ifndef NETMASK_ADDR0
#define NETMASK_ADDR0    255
#define NETMASK_ADDR1    255
#define NETMASK_ADDR2    255
#define NETMASK_ADDR3    0
#endif

/*Gateway Address*/
#ifndef GW_ADDR0
#define GW_ADDR0    192
#define GW_ADDR1    168
#define GW_ADDR2    1
#define GW_ADDR3    1
#endif

/*Static IP ADDRESS*/
#ifndef AP_IP_ADDR0
#define AP_IP_ADDR0    192
#define AP_IP_ADDR1    168
#define AP_IP_ADDR2    43
#define AP_IP_ADDR3    1
#endif

/*NETMASK*/
#ifndef AP_NETMASK_ADDR0
#define AP_NETMASK_ADDR0    255
#define AP_NETMASK_ADDR1    255
#define AP_NETMASK_ADDR2    255
#define AP_NETMASK_ADDR3    0
#endif

/*Gateway Address*/
#ifndef AP_GW_ADDR0
#define AP_GW_ADDR0    192
#define AP_GW_ADDR1    168
#define AP_GW_ADDR2    43
#define AP_GW_ADDR3    1
#endif

/******************************************************************************\
*                        Typedef definitions
\******************************************************************************/
typedef enum
{
    NET_SECURITY_NONE     = WPS_ENABLED,                 /*!< open access point */
    NET_SECURITY_WEP      = WEP_ENABLED,                 /*!< phrase conforms to WEP */
    NET_SECURITY_WPA      = RTW_SECURITY_WPA_AES_PSK,    /*!< phrase conforms to WPA */
    NET_SECURITY_WPA2     = RTW_SECURITY_WPA2_AES_PSK,   /*!< phrase conforms to WPA2 */
    NET_SECURITY_WPA_WPA2 = RTW_SECURITY_WPA_WPA2_MIXED, /*!< phrase conforms to WPA/WPA2 */
    NET_SECURITY_UNKNOWN  = RTW_SECURITY_UNKNOWN,
}SecurityType_e;

#define PRODUCTION_SSID        "het-test-wifi"
#define PRODUCTION_SSID_KEY    "12345678"
#define PRODUCTION_KEY_TYPE    RTW_SECURITY_WPA2_AES_PSK

/******************************************************************************\
*                   Global variables and functions
\******************************************************************************/

/******************************************************************************/
extern
int HAL_Wifi_Open(void);
/******************************************************************************/

/*
 * 函数名称 : HAL_Wifi_APMode
 * 功能描述 : 切换到AP模式，并设置AP信息
 * 参     数 : SSID,AP账号;Key,账号密码;KeyType,密码类型;
 * 返 回 值 : TRUE,成功;FALSE,失败
 * 示     例 ：
 */
/******************************************************************************/
extern
int HAL_Wifi_APMode(uint8_t* SSID, uint8_t* Key, rtw_security_t KeyType, int Channel);
/******************************************************************************/

/*
 * 函数名称 : HAL_Wifi_STAMode
 * 功能描述 : 切换到STA模式
 * 参     数 : 无
 * 返 回 值 : TRUE,成功;FALSE,失败
 * 示     例 ：
 */
/******************************************************************************/
extern
int HAL_Wifi_STAMode(void);
/******************************************************************************/

/******************************************************************************/
extern
int HAL_Wifi_StopAPMode(void);
/******************************************************************************/

/******************************************************************************/
extern
int HAL_Wifi_ReconnectRouter(uint8_t* SSID, uint8_t* Key, uint8_t KeyType);
/******************************************************************************/

/******************************************************************************/
/*
 * 函数名称 : HAL_WIFI_GetRssi
 * 功能描述 : 读取路由分配Rssi状态
 * 参     数 : 无;
 * 返 回 值 : Rssi
 * 示     例 ：
 */
/******************************************************************************/
extern uint8_t HAL_WIFI_GetRssi(void);
/******************************************************************************/

/******************************************************************************/
extern
int HAL_WIFI_ConnectedRouter(const char *ssid, const char *passwd);
/******************************************************************************/

/******************************************************************************/
extern
int HAL_WIFI_GetMacAddr(uint8_t pmac[6]);
/******************************************************************************/

/******************************************************************************/
extern
int HAL_WIFI_GetBSSID(uint8_t bssid[6]);
/******************************************************************************/

/******************************************************************************/
extern
uint32_t HAL_WIFI_GetBroadcastAddr(void);
/******************************************************************************/

/******************************************************************************/
extern
uint32_t HAL_WIFI_GetLoaclIp(void);
/******************************************************************************/

/******************************************************************************/
extern
u32_t HAL_WIFI_GetBCIP(void);
/******************************************************************************/

/******************************************************************************/
extern
uint8_t HAL_Wifi_RouterIp(void);
/******************************************************************************/

#endif

/******************************* End of File (H) ******************************/

