

#ifndef _HAL_SOCKET_H
#define _HAL_SOCKET_H

/******************************************************************************\
*                            Includes
\******************************************************************************/

/******************************************************************************\
*                         Macro definitions
\******************************************************************************/


/******************************************************************************\
*                        Typedef definitions
\******************************************************************************/

typedef enum
{
    SOCKET_UDP = 0x0,
    SOCKET_TCP,
    SOCKET_MAX
}E_SocketType;

typedef enum
{
    SOCKET_CLIENT = 0x0,
    SOCKET_SERVER,
    IS_MAX
}E_SocketIs;

typedef struct _tSocketAcceptNode
{
    int                       fd;
    struct _tSocketAcceptNode *Next;
}T_SocketAcceptNode, *P_SocketAcceptHandle;

typedef struct
{
    E_SocketIs           isServer;
    E_SocketType         SocketType;
    int                  fd;
    struct sockaddr_in   To;
    struct sockaddr_in   From;
    P_SocketAcceptHandle pSocAcceptHandle;
}T_SocketParams;

typedef struct _tSocketNode
{
    T_SocketParams      tSocParams;
    struct _tSocketNode *Next;
}T_SocketNode, *P_SocketHandle;

typedef void * TcpSvrHandle_t;
typedef void * TcpSvrOfCliHandle_t;
typedef void (*TcpServerRecvCallback_t)(TcpSvrOfCliHandle_t, unsigned char *, int);

extern
const char *HAL_Socket_Convert2IpString(unsigned int ipaddr);

extern
uint32_t HAL_Socket_Conver2Ipaddr(const char *ipStr);

extern
uint32_t HAL_Socket_gethostbyname(const char *hostname);

extern
uint8_t HAL_Socket_IsIpString(const char *hostname);

extern
uint8_t HAL_Socket_IsIpString(const char *hostname);

/******************************************************************************/
extern
P_SocketHandle HAL_Socket_Open(const char *hostname, uint16_t Port,
                               E_SocketIs IsServer, E_SocketType SocketType);
/******************************************************************************/


/******************************************************************************/
extern
int HAL_Socket_Close(P_SocketHandle pHandle);
/******************************************************************************/

/******************************************************************************/
extern
int HAL_Socket_Write(P_SocketHandle pHandle, uint8_t *pData, uint32_t dLen);
/******************************************************************************/

/******************************************************************************/
extern
int HAL_Socket_Read(P_SocketHandle pHandle, uint8_t *pData, uint32_t dLen);
/******************************************************************************/

extern
TcpSvrHandle_t HAL_Socket_CreateTcpServer(const char *hostname, uint16_t Port,
                                          uint32_t timeout, TcpServerRecvCallback_t Cb);

extern
int HAL_Socket_DestroyTcpServer(TcpSvrHandle_t hdl);

extern
int HAL_Socket_TcpServerSend(TcpSvrOfCliHandle_t cli_hdl, unsigned char *pdata, int len);

extern
int HAL_Socket_TcpServerClose(TcpSvrOfCliHandle_t cli_hdl);

#endif

/******************************* End of File (H) ******************************/

