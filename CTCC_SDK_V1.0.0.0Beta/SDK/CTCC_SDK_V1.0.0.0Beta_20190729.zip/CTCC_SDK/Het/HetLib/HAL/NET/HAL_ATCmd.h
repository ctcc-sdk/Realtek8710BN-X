/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_ATCmd.h
*   @Author           : Bernie Liu & lwm
*   @Version          : V00.00.01
*   @Date             : 2018-09-28
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_AT_COMMAND_H_
#define _HAL_AT_COMMAND_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

#ifdef CHIP_SELECT_HFx30

#define MAX_CH               11
#define DEFAULT_CH           1

#define LAN_IP               "192.168.11.1"
#define GATE_WAY             "255.255.255.0"
#define WIFI_DOWN            "DOWN"
#define WIFI_UP              "UP"
#define LINK_OFF             "off"
#define LINK_ON              "on"
#define DISCONNECTED         "Disconnected"
#define MODE_AP              "AP"
#define MODE_STA             "STA"
#define SOCKA_SERVER         "SERVER"
#define SOCKA_CLIENT         "CLIENT"
#define SOCKA_UDP            "UDP"
#define SOCKA_TCP            "TCP"
#define SOCKB_UDP_SERVER     "UDPS"
#define SOCKB_UDP_CLIENT     "UDP"
#define SOCKB_TCP_CLIENT     "TCP"

//查询类命令
#define AT_CHK_WSSSID        "AT+WSSSID\r\n"                       //查询路由器SSID
#define AT_CHK_WSLK          "AT+WSLK\r\n"                         //查询路由器连接状态
#define AT_CHK_WMODE         "AT+WMODE\r\n"                        //查询模组工作模式
#define AT_CHK_WANN          "AT+WANN\r\n"                         //查询STA的网络参数
#define AT_CHK_LANN          "AT+LANN\r\n"                         //查询AP的网络参数
#define AT_CHK_WSMAC         "AT+WSMAC\r\n"                        //查询模组的MAC地址
#define AT_CHK_WIFI          "AT+WIFI\r\n"                         //查询wifi状态
#define AT_CHK_TCPLK         "AT+TCPLK\r\n"                        //查询socka连接状态
#define AT_CHK_TCPLKB        "AT+TCPLKB\r\n"                       //查询sockb连接状态

//设置类命令
#define AT_SET_WMODE         "AT+WMODE=%s\r\n"                     //设置模组工作模式
#define AT_SET_LAN           "AT+LANN=%s,%s\r\n"                   //设置AP的网络参数
#define AT_SET_WAP           "AT+WAP=11BGN,%s,CH%d\r\n"            //设置AP的配置参数
#define AT_SET_WAKEY_OPEN    "AT+WAKEY=OPEN,NONE\r\n"              //设置开放的AP的加密参数
#define AT_SET_WAKEY         "AT+WAKEY=WPA2PSK,AES,%s\r\n"         //设置AP的加密参数
#define AT_SET_UDPLCPT       "AT+UDPLCPT=0,%s\r\n"                 //设置UDP本地端口号
#define AT_SET_WIFI          "AT+WIFI=%s\r\n"                      //设置wifi状态
#define AT_SET_WSSSID        "AT+WSSSID=%s\r\n"                    //设置路由器SSID
#define AT_SET_WSKEY         "AT+WSKEY=%s,%s,%s\r\n"               //设置STA的加密参数
#define AT_SET_TCPDISB       "AT+TCPDISB=%s\r\n"                   //建立/断开sockb连接
#define AT_SET_TCPDIS        "AT+TCPDIS=%s\r\n"                    //建立/断开socka连接
#define AT_SET_SOCKA         "AT+NETP=%s,%s,%d,%s\r\n"             //配置socka连接参数
#define AT_SET_SOCKB         "AT+SOCKB=%s,%d,%s\r\n"               //配置sockb连接参数

#endif


/******************************************************************************\
*   @HET_EXTERN
\******************************************************************************/

#endif

/******************************* End of File (H) ******************************/

