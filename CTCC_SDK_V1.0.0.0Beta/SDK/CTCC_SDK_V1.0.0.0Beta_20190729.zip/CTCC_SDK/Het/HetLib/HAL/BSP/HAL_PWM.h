/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_PWM.h
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2018-10-08
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_PWM_H_
#define _HAL_PWM_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

typedef enum
{
    H_PWM_ID_0 = 0x0, // PA_14
    H_PWM_ID_1,       // PA_15
    H_PWM_ID_2,       // PA_0
    H_PWM_ID_3,       // PA_12
    H_PWM_ID_MAX
}PwmID_e;

/******************************************************************************\
*   @Extern
\******************************************************************************/

/*
 * Function Name : HAL_PWM_Open
 * Description   : Open the PWM by PWM Handle
 * Parameter     : p_PWMHandle, PWM Handle
 * Return value  : int, return Open resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_PWM_Open(PwmID_e id, uint32_t period_xus, uint32_t pulsewidth_xus);
/******************************************************************************/

/*
 * Function Name : HAL_PWM_Close
 * Description   : Close the PWM by PWM PwmID, Set PWM Reset Status
 * Parameter     : id, PWM Channel
 * Return value  : int, return Close resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_PWM_Close(PwmID_e id);
/******************************************************************************/

/*
 * Function Name : HAL_PWM_Eanble
 * Description   : Enable PWM By id
 * Parameter     : id, PWM Channel;
 * Return value  : int, return Enable resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_PWM_Enable(PwmID_e id);
/******************************************************************************/

/*
 * Function Name : HAL_PWM_Disable
 * Description   : Disable PWM By id
 * Parameter     : id, PWM Channel;
 * Return value  : int, return Disable resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_PWM_Disable(PwmID_e id);
/******************************************************************************/

/*
 * Function Name : HAL_PWM_SetDuty
 * Description   : Set PWM Duty By id and Duty
 * Parameter     : id, PWM Channel; Duty, PWM Current Duty, Duty <= MaxDuty;
 * Return value  : int, return SetDuty resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_PWM_SetDuty(PwmID_e id, uint32_t pulsewidth_xus);
/******************************************************************************/

#endif /* _HAL_PWM_H_ */

/******************************* End of File (H) ******************************/

