/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_UART.h
*   @Author           : Sean Tang
*   @Version          : V00.00.01
*   @Date             : 2018-10-08
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HET_HAL_USART_H_
#define _HET_HAL_USART_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/
#define COMSTOPBITS_1     0
#define COMSTOPBITS_2     1

#define COMBITS_5         5
#define COMBITS_6         6
#define COMBITS_8         8

#define COMPARITY_NONE    0
#define COMPARITY_ODD     1
#define COMPARITY_EVEN    2

typedef enum
{
    H_UART_ID_0 = 0x0,  
    //H_UART_ID_1, // not support
    H_UART_ID_2, // Log
    H_UART_ID_MAX
}E_UartId;

typedef enum
{
    H_UART_MODE_TX = 0x01, // 0b0001, Only use Tx mode
    H_UART_MODE_RX = 0x02, // 0b0010, Only use Rx mode
    H_UART_MODE_TX_RX = 0x03, // 0b0011, Use TX mode and RX mode  
}E_UartMode;

typedef enum
{
    H_UART_EVENT_TX = 0x0,
    H_UART_EVENT_RX,
    H_UART_EVENT_MAX
}E_UartEvent;

typedef enum
{
    H_UART_STOPBITS_1 = 0x0,
    H_UART_STOPBITS_2,
    H_UART_STOPBITS_MAX
}E_UartStopBits;

typedef enum
{
    H_UART_PARITY_NO = 0x0,
    H_UART_PARITY_EVEN,
    H_UART_PARITY_ODD,
    H_UART_PARITY_MAX
}E_UartParity;

typedef enum
{
    H_UART_WORDLENGTH_5B = 0x0,
    H_UART_WORDLENGTH_6B,
    H_UART_WORDLENGTH_8B,
    H_UART_WORDLENGTH_MAX
}E_UartWordLen;

typedef enum
{
    H_UART_HWCONTROL_NONE    = 0x00000000U,
    H_UART_HWCONTROL_RTS,
    H_UART_HWCONTROL_CTS,
    H_UART_HWCONTROL_RTS_CTS,
    H_UART_HWCONTROL_MAX
}E_UartHWCtrl;

typedef enum
{
    H_UART_IT_TXE = 0x0,
    H_UART_IT_RXNE,
    H_UART_IT_TXE_RXNE,
    H_UART_IT_MAX
}E_UartIT;

typedef struct
{
    E_UartId       ID;         /* Usart ID */
    uint32_t       BaudRate;   /* Baud rate */
    E_UartWordLen  WordLength; /* Length of the data */
    E_UartStopBits StopBits;   /* Stop bit */
    E_UartParity   Parity;     /* Parity bit */
    E_UartMode     Mode;       /* Mode */
    E_UartIT       IT;         /* Interrupt enable flag*/
    E_UartHWCtrl   HwFlowCtl;  /* Hardware flow control */
}T_UartParams, *P_UartHandle;

typedef void (*pUartCallback)(uint8_t);

#define UART0_DEFAULT_CONFIG  { \
    .ID           = H_UART_ID_0, \
    .BaudRate     = 921600, \
    .WordLength   = H_UART_WORDLENGTH_8B, \
    .StopBits     = H_UART_STOPBITS_1, \
    .Parity       = H_UART_PARITY_NO, \
    .Mode         = H_UART_MODE_TX_RX, \
    .IT           = H_UART_IT_RXNE, \
    .HwFlowCtl    = H_UART_HWCONTROL_NONE}

#define UART2_DEFAULT_CONFIG  { \
    .ID           = H_UART_ID_2, \
    .BaudRate     = 9600, \
    .WordLength   = H_UART_WORDLENGTH_8B, \
    .StopBits     = H_UART_STOPBITS_1, \
    .Parity       = H_UART_PARITY_NO, \
    .Mode         = H_UART_MODE_TX_RX, \
    .IT           = H_UART_IT_RXNE, \
    .HwFlowCtl    = H_UART_HWCONTROL_NONE}

/******************************************************************************\
*   @Extern
\******************************************************************************/

/*
 * Function Name : HAL_UART_Open
 * Description   : Open the USART by USART Handle
 * Parameter     : p_UsartHandle, USART Handle
 *                FunctionCB, Interrupt Callback Function
 * Return value  : int, return Open resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_UART_Open(T_UartParams *p_UsartHandle, \
                         pUartCallback FunctionCB);
/******************************************************************************/

/*
 * Function Name : HAL_UART_Close
 * Description   : Close the USART byID
 * Parameter     : ID, USART ID
 * Return value  : int, return Close resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_UART_Close(E_UartId ID);
/******************************************************************************/

/*
 * Function Name : HAL_UART_Write
 * Description   : Write Datas To the USART by ID
 * Parameter     : ID, USART ID
 *                pBuf, Write Buffer
 *                Len, Write Buffer Len
 *                Timeout, Write TimeOut
 * Return value  : int, return Write resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_UART_Write(E_UartId ID, uint8_t* pBuf, uint16_t Len, \
                          uint32_t Timeout);
/*******************************************************************************/

/*
 * Function Name : HAL_UART_Read
 * Description   : Read Datas From the USART by ID
 * Parameter     : ID, USART ID
 *                pBuf, Read Buffer
 *                Len, Read Buffer Len
 *                Timeout, Read TimeOut
 * Return value  : int, return Read resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_UART_Read(E_UartId ID, uint8_t* pBuf, uint16_t Len,
                         uint32_t Timeout);
/******************************************************************************/

/*
 * Function Name : HAL_UART_ChgBaudRate
 * Description   : Change USART Baud Rate by ID and Baud
 * Parameter     : ID, USART ID
 *                Baud, USART Baud
 * Return value  : int, return Change resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_UART_ChgBaudRate(E_UartId ID, uint32_t Baud);
/******************************************************************************/

#endif /* _HET_HAL_USART_H_ */

/******************************* End of File (H) ******************************/

