/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_GPIO.h
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2018-09-28
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_GPIO_H_
#define _HAL_GPIO_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

/* GPIO PIN Define */
enum
{
    H_GPIO_PIN_01 = 0x0,  // GPIOA_30 
    H_GPIO_PIN_02,        // GPIOA_29    
    H_GPIO_PIN_03,        // VA33_XTAL    
    H_GPIO_PIN_04,        // X0
    H_GPIO_PIN_05,        // XI
    H_GPIO_PIN_06,        // VR33SYN
    H_GPIO_PIN_07,        // GND_RF
    H_GPIO_PIN_08,        // VR33_PA
    H_GPIO_PIN_09,        // RFIO
    H_GPIO_PIN_10,        // VR33_PAD
    H_GPIO_PIN_11,        // VR33_TR
    H_GPIO_PIN_12,        // CHIP_EN
    H_GPIO_PIN_13,        // GPIOA_14
    H_GPIO_PIN_14,        // GPIOA_15
    H_GPIO_PIN_15,        // VD12_CORE
    H_GPIO_PIN_16,        // GPIOA_0  
    H_GPIO_PIN_17,        // GPIOA_12  
    H_GPIO_PIN_18,        // GPIOA_6   
    H_GPIO_PIN_19,        // GPIOA_7 
    H_GPIO_PIN_20,        // GPIOA_8
    H_GPIO_PIN_21,        // GPIOA_9
    H_GPIO_PIN_22,        // GPIOA_10
    H_GPIO_PIN_23,        // GPIOA_11
    H_GPIO_PIN_24,        // VD1833_FLASH
    H_GPIO_PIN_25,        // VD33_LDO
    H_GPIO_PIN_26,        // VD12_OUT  
    H_GPIO_PIN_27,        // VBAT_MEAS   
    H_GPIO_PIN_28,        // GPIOA_5    
    H_GPIO_PIN_29,        // GPIOA_18  
    H_GPIO_PIN_30,        // GPIOA_19
    H_GPIO_PIN_31,        // GPIOA_22
    H_GPIO_PIN_32,        // GPIOA_23
    H_GPIO_PIN_MAX
};

/* GPIO Mode Define */
enum
{
    H_GPIO_MODE_INPUT = 0x0,
    H_GPIO_MODE_OUTPUT,
    H_GPIO_MODE_MAX
};

//GPIO PULL UP/DN Define
enum
{
    H_GPIO_PULL_None = 0x0,
    H_GPIO_PULL_UP,
    H_GPIO_PULL_DOWN,
    H_GPIO_PULL_OpenDrain,
    H_GPIO_PULL_MAX,
};

//GPIO Speed Define
enum
{
    H_GPIO_SPEED_FREQ_LOW = 0x0,
    H_GPIO_SPEED_FREQ_MEDIUM,
    H_GPIO_SPEED_FREQ_HIGH,
    H_GPIO_SPEED_MAX
};

/* GPIO Handle Define */
typedef struct
{
    uint8_t Value;
    uint8_t Pin;
    uint8_t Mode;
    uint8_t Pull;
    uint8_t Speed;
}T_GpioParams, *P_GpioHandle;

/* Default Config */

#define GPIO_DEFAULT_CONFIG_INPUT {  \
    .Value = 0,                      \
    .Pin   = H_GPIO_PIN_MAX,           \
    .Mode  = H_GPIO_MODE_INPUT,        \
    .Pull  = H_GPIO_PULL_None,           \
    .Speed = H_GPIO_SPEED_FREQ_HIGH,   \
}

#define GPIO_DEFAULT_CONFIG_OUTPUT {  \
    .Value = 0,                       \
    .Pin   = H_GPIO_PIN_MAX,            \
    .Mode  = H_GPIO_MODE_OUTPUT,        \
    .Pull  = H_GPIO_PULL_None,            \
    .Speed = H_GPIO_SPEED_FREQ_HIGH,    \
}

/* IO Config */

/******************************************************************************\
*   @Extern
\******************************************************************************/

extern const PinName s_GpioRemapPinTbl[H_GPIO_PIN_MAX];


/*
 * Function Name : HAL_GPIO_Open
 * Description   : Open the GPIO by Gpio Handle
 * Parameter     : p_GpioHandle, Gpio Handle
 * Return value  : int, return Open resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_GPIO_Open(P_GpioHandle pHandle);
/******************************************************************************/

/******************************************************************************/

/*
 * Function Name : HAL_GPIO_Close
 * Description   : Close the GPIO by Pin
 * Parameter     : Pin, GPIO PIN
 * Return value  : int, return Close resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_GPIO_Close(uint8_t Pin);
/******************************************************************************/

/******************************************************************************/

/*
 * Function Name : HAL_GPIO_Write
 * Description   : Write GPIO by Pin and Value
 * Parameter     : Pin, GPIO PIN; Value, GPIO Value
 * Return value  : int, return Write resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_GPIO_Write(uint8_t Pin, uint8_t Value);
/******************************************************************************/

/******************************************************************************/

/*
 * Function Name : HAL_GPIO_Read
 * Description   : Read GPIO by Pin, return Value
 * Parameter     : Pin, GPIO PIN; Value, GPIO Value
 * Return value  : int, return Read resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_GPIO_Read(uint8_t Pin, uint8_t  *Value);
/******************************************************************************/

/******************************************************************************/

/*
 * Function Name : HAL_GPIO_Toggle
 * Description   : Toggle GPIO by Pin
 * Parameter     : Pin, GPIO PIN
 * Return value  : int, return Toggle resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_GPIO_Toggle(uint8_t Pin);
/******************************************************************************/

#endif /* _HET_HAL_GPIO_H_ */

/******************************* End of File (H) ******************************/


