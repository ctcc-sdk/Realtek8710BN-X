/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_WDG.h
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2018-10-08
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_WDG_H_
#define _HAL_WDG_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

/******************************************************************************\
*   @Extern
\******************************************************************************/

/*
 * Function Name : HET_WDG_Open
 * Description   : Open watchdog func, with timeout value
 * Parameter     : timeout_xMs, watchdog timeout
 * Return value  : void
 *
 * Example       :
 */
/******************************************************************************/
extern
void HET_WDG_Open(uint32_t timeout_xMs);
/******************************************************************************/

/*
 * Function Name : HET_WDG_Close
 * Description   : Close watchdog func
 * Parameter     : void
 * Return value  : void
 *
 * Example       :
 */
/******************************************************************************/
extern
void HET_WDG_Close(void);
/******************************************************************************/

/*
 * Function Name : HET_WDG_Enable
 * Description   : Enable watchdog func
 * Parameter     : void
 * Return value  : void
 *
 * Example       :
 */
/******************************************************************************/
extern
void HET_WDG_Enable(void);
/******************************************************************************/

/*
 * Function Name : HET_WDG_Disable
 * Description   : Disable watchdog func
 * Parameter     : void
 * Return value  : void
 *
 * Example       :
 */
/******************************************************************************/
extern
void HET_WDG_Disable(void);
/******************************************************************************/

/*
 * Function Name : HET_WDG_Feed
 * Description   : Feed watchdog func
 * Parameter     : void
 * Return value  : void
 *
 * Example       :
 */
/******************************************************************************/
extern
void HET_WDG_Feed(void);
/******************************************************************************/

#endif /* _HAL_WDG_H_ */

/******************************* End of File (H) ******************************/

