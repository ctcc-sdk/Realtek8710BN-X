/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_FLASH.h
*   @Author           : Sean Tang
*   @Version          : V00.00.01
*   @Date             : 2018-10-08
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_FLASH_H_
#define _HAL_FLASH_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

#define FLASH_USER_START_ADDR    0xF5000
#define FLASH_USER_MAX_SIZE      0x5000    // 20K, 5 Sectors

#define PAGE_SECTOR_SIZE         (4096)

/******************************************************************************\
*   @Extern
\******************************************************************************/


/******************************************************************************/
extern int  HAL_Flash_Erase(uint32_t StartAddr, uint32_t dwSize);
/******************************************************************************/

/*
 * Function Name : HAL_Flash_Write
 * Description   : Write Datas To Flash File By Address, Only 4k
 * Parameter     : StartAddr, Start Address, Can Set Any Val
 *                pBuf, Datas Buffer Pointer
 *                BytesSize, Datas Buffer Size, Need Change To One Byte
 * Return value  : int, return Write resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_Flash_Write(uint32_t StartAddr, uint8_t* pBuf, uint32_t BytesSize);
/******************************************************************************/

/*
 * Function Name : HAL_Flash_Open
 * Description   : Read Datas From Flash File By Address, Only 4k
 * Parameter     : StartAddr, Start Address, Can Set Any Val
 *                pBuf, Datas Buffer Pointer
 *                BytesSize, Datas Buffer Size, Need Change To One Byte
 * Return value  : int, return Read resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_Flash_Read(uint32_t StartAddr, uint8_t* pBuf, uint32_t BytesSize);
/******************************************************************************/

#endif /* _HET_HAL_FLASH_H_ */

/******************************* End of File (H) ******************************/


