/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HET_HAL_EXTI.h
*   @Author           : Bernie Liu & lwm
*   @Version          : V00.00.01
*   @Date             : 2018-10-08
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HET_HAL_EXTI_H_
#define _HET_HAL_EXTI_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

typedef enum
{
    H_EXTI_CH_00 = 0x0, // PA_6,     // H_GPIO_PIN_18,        // GPIOA_6   
    H_EXTI_CH_01, // PA_7,     // H_GPIO_PIN_19,        // GPIOA_7 
    H_EXTI_CH_02, // PA_8,     // H_GPIO_PIN_20,        // GPIOA_8
    H_EXTI_CH_03, // PA_9,     // H_GPIO_PIN_21,        // GPIOA_9
    H_EXTI_CH_04, // PA_10,    // H_GPIO_PIN_22,        // GPIOA_10
    H_EXTI_CH_05, // PA_11,    // H_GPIO_PIN_23,        // GPIOA_11
    H_EXTI_CH_06, // PA_5,     // H_GPIO_PIN_28,        // GPIOA_5    
    H_EXTI_CH_07, // PA_19,    // H_GPIO_PIN_30,        // GPIOA_19
    H_EXTI_CH_08, // PA_22,    // H_GPIO_PIN_31,        // GPIOA_22
    H_EXTI_CH_MAX
}ExitChannel_e;

/* EXTI Trigger Define */
typedef enum
{
    H_EXTI_IT_RISING = 0x0,   /* EXTI Trigger Rising */ 
    H_EXTI_IT_FALLING,        /* EXTI Trigger Falling */
    H_EXTI_IT_RISING_FALLING, /* EXTI Trigger Both Rising And Falling */
    H_EXTI_IT_MAX
}ExtiItMode_e;

typedef void (*ExtiCallBack)(uint32_t id, ExtiItMode_e mode); /*外部中断处理函数回*/

/******************************************************************************\
*   @Extern
\******************************************************************************/

/*
 * Function Name : HAL_EXTI_Open
 * Description   : Open the EXTI by Exti ch
 * Parameter     : ch, Exti channel; ItMode, irq mode; FunctionCB, Call Back FunctionCB
 * Return value  : int, return Open resullt:
 *                E_OK   : Success
 *                -E_INVAL: Parameters Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_EXTI_Open(ExitChannel_e ch, ExtiItMode_e ItMode, ExtiCallBack FunctionCB);
/******************************************************************************/

/*
 * Function Name : HAL_EXTI_Close
 * Description   : Close the EXTI by channel
 * Parameter     : ch, Exti channel
 * Return value  : int, return Close resullt:
 *                E_OK   : Success
 *                -E_INVAL: Parameters Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_EXTI_Close(ExitChannel_e ch);
/******************************************************************************/

#endif /* _HET_HAL_EXTI_H_ */

/******************************* End of File (H) ******************************/

