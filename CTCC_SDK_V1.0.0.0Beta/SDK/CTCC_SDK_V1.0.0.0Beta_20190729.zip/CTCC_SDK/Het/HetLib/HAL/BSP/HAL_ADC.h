/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_ADC.h
*   @Author           : Bernie Liu & lwm
*   @Version          : V00.00.01
*   @Date             : 2018-09-28
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_ADC_H_
#define _HAL_ADC_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

/* ADC Channel Define */
typedef enum
{
    H_ADC_CH_00 = 0,            // Not Surport
    H_ADC_CH_01,                // Not Surport
    H_ADC_CH_MAX
}ADCChannel_e;

/* ADC Data Aligh Define */
typedef enum
{
    H_ADC_DATAALIGN_RIGHT = 0,      // Data Aligh Right 
    H_ADC_DATAALIGN_LEFT,           // Data Aligh Left 
    H_ADC_DATAALIGN_MAX
}ADCDataAlign_e;

/******************************************************************************\
*   @Extern
\******************************************************************************/

/*
 * Function Name : HAL_ADC_Open
 * Description   : Open the ADC by ADC Handle
 * Parameter     : p_ADCHandle, ADC Handle
 * Return value  : int, return Open resullt:
 *                E_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_ADC_Open(ADCChannel_e ch, ADCDataAlign_e da);
/******************************************************************************/

/******************************************************************************/

/*
 * Function Name : HAL_ADC_Close
 * Description   : Close the ADC by ch
 * Parameter     : ch, ADC channel
 * Return value  : int, return Close resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_ADC_Close(ADCChannel_e ch);
/******************************************************************************/

/******************************************************************************/

/*
 * Function Name : HAL_ADC_Read
 * Description   : Read ADC by ch, return Value
 * Parameter     : ch, ADC channel; Value, ADC Value
 * Return value  : int, return Read resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_ADC_Read(ADCChannel_e ch, uint16_t *Value);
/******************************************************************************/

#endif /* _HAL_ADC_H_ */

/******************************* End of File (H) ******************************/

