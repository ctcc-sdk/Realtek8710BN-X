/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_TIM.h
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2018-10-08
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_TIM_H_
#define _HAL_TIM_H_

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

/* Timer ID Define */
typedef enum
{
    H_TIM_ID_0 = 0x0, // general timer
    H_TIM_ID_1,       // general timer
    H_TIM_ID_2,       // general timer
    H_TIM_ID_3,       // general timer
    H_TIM_ID_MAX
}TimerID_e;

typedef void (*pTimCallback)(void);

#define TIM_1US    (1)
#define TIM_1MS    (1000 * TIM_1US)
#define TIM_1S     (1000 * TIM_1MS)

/******************************************************************************\
*   @Extern
\******************************************************************************/

/*
 * Function Name : HAL_TIM_Open
 * Description   : Open the TIM by TIM Handle and FunctionCB
 * Parameter     : p_TIMHandle, TIM Handle; FunctionCB, CALL BACK FunctionCB
 * Return value  : int, return Open resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern
int HAL_TIM_Open(TimerID_e id, uint32_t timeout_xus, pTimCallback cb);
/******************************************************************************/

/*
 * Function Name : HAL_TIM_Close
 * Description   : Close the TIM by id
 * Parameter     : id, TIM id
 * Return value  : int, return Close resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_TIM_Close(TimerID_e id);
/******************************************************************************/

/*
 * Function Name : HAL_TIM_Enable
 * Description   : Enable TIM By id
 * Parameter     : id, TIM id;
 * Return value  : int, return Enable resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_TIM_Enable(TimerID_e id);
/******************************************************************************/

/*
 * Function Name : HAL_TIM_Disable
 * Description   : Disable TIM By id
 * Parameter     : id, TIM id;
 * Return value  : int, return Disable resullt:
 *                HET_OK   : Success
 *                HET_ERROR: Error
 *
 * Example       :
 */
/******************************************************************************/
extern int HAL_TIM_Disable(TimerID_e id);
/******************************************************************************/

#endif /* _HAL_TIM_H_ */

/******************************* End of File (H) ******************************/

