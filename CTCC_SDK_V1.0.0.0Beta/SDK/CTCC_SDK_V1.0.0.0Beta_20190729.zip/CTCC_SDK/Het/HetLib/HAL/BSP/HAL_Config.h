/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, HeT
*   @File Name        : HAL_Config.h
*   @Author           : Bernie Liu & lwm
*   @Version          : V00.00.01
*   @Date             : 2018-09-28
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _HAL_CONFIG_H_
#define _HAL_CONFIG_H_

/******************************************************************************\
*   @includes
\******************************************************************************/
/*       SYS      */
#include "../../Config/Platform_Config.h"

/* Costomer Include Files */
#include "../../Common/Type_Define.h"
#include "../../Common/Error_Define.h"

/*    CTCC  CONFIG      */
#include "../../Protocol/NET/NET_Public/profile_utils.h"

/* Config Include */
#include "../../Config/Protocol_Config.h"
#include "../../Common/Log_Debug.h"
#include "../../Common/stdlibc.h"
#include "../../Common/Data_Cache.h"
#include "../../Common/Data_Stream.h"

/* HAL Include */
#include "../../HAL/BSP/HAL_SYS.h"
#include "../../HAL/BSP/HAL_GPIO.h"
#include "../../HAL/BSP/HAL_ADC.h"
#include "../../HAL/BSP/HAL_TIM.h"
#include "../../HAL/BSP/HAL_UART.h"
#include "../../HAL/BSP/HAL_EXTI.h"
#include "../../HAL/BSP/HAL_FLASH.h"
//#include "../../HAL/BSP/HAL_RTC.h"
#include "../../HAL/BSP/HAL_PWM.h"

#include "../../HAL/NET/HAL_Wifi.h"
#include "../../HAL/NET/HAL_Socket.h"
#include "../../HAL/NET/HAL_OS.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

/******************************************************************************\
*   @HET_EXTERN
\******************************************************************************/

#endif

/******************************* End of File (H) ******************************/

