
/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  Protocol_Config.h
**  功能描述 :      用于网络管理层宏定义
**  作     者  :  Bernie Liu
**  日     期  :  2018.01.01
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/2018.07.25
**           1 首次创建
\******************************************************************************/

#ifndef _PROTOCOL_CONFIG_H_
#define _PROTOCOL_CONFIG_H_


/******************************************************************************\
*                            Includes
\******************************************************************************/


/******************************************************************************\
*                         Macro definitions
\******************************************************************************/

#define ENCRYPT_TYPE_AES                (3)

#define NETWORK_DEFAULT_ENCRYPT_TYPE    (ENCRYPT_TYPE_AES)
#define NETWORK_PRODUCT_ENCRYPT_TYPE    (0)


#define NETWORK_PRODUCT_RELEASE_VER     "525-A18321A-C-U1-V1.0.1(20180930)"
#define NETWORK_RELEASE_DATE            "2019-04-17"
#define NETWORK_RELEASE_VER             "110202010100HF-LPTx30-10000V4.13.20000"
/* |||||||||||||||||||||||||||||||||||||--保留1BYTE
 |||||||||||||||||||||||||||------------原厂SDK版本10BYTE
 ||||||||||||---------------------------模组型号15BYTE
 ||||-----------------------------------模组硬件信息4BYTE
 * ---------------------------------------
 * 模组固件版本2BYTE
 */

#define IDENTIFY_TOTAL_TIMEOUT          (200)  // s
#define IDENTIFY_RESEND_TIMEOUT         (5)    // s

#define WIFI_200MS_TIMEOUT              (200)  // ms
#define WIFI_500MS_TIMEOUT              (500)  // ms
#define WIFI_1S_TIMEOUT                 (1000) // ms

#define RELINK_ROUTER_TIMEOUT           (20)   // s
#define RELINK_SERVER_TIMEOUT           (30)   // s

#define SOCKET_RESEND_CNTS              (3)    // counters


#define WIFI_HUM_API                    (0)
#define WIFI_HUM_PRE                    (1)
#define WIFI_HUM_DP                     (2)

#define DOMIAN_DP_ADDR                  "dp.clife.net"
#define DOMIAN_PRE_ADDR                 "pre.api.clife.cn"
#define DOMIAN_API_ADDR                 "api.clife.cn"
#define HTTP_DEFAULT_FORMAT             "GET /v1/device/init/getWiFiBindConfig?deviceCode=0000c4f1000b0102&mac=18fe34d85e4b&bindCode=5ftol298&configType=1&moduleType=1 HTTP/1.1\r\nHost:dp.clife.net\r\n\r\n"
#define HTTP_GET_FORMAT                 "GET /v1/device/init/getWiFiBindConfig?deviceCode=%02x%02x%02x%02x%02x%02x%02x%02x&mac=%02x%02x%02x%02x%02x%02x&bindCode=%s&configType=1&moduleType=1 HTTP/1.1\r\nHost:%s\r\n\r\n"

#define HTTP_FILE_PATH                  "/v1/device/data/file/upload"

#define HTTP_FILE_POST_HEAD             "POST %s HTTP/1.1\r\nHost: %s\r\nContent-Length: %d\r\nContent-Type: multipart/form-data; boundary=----JKBernie\r\n\r\n"
#define HTTP_FILE_POST_CONTENT          "------JKBernie\r\nContent-Disposition: form-data; name=\"deviceCode\"\r\n\r\n%s\r\n------JKBernie\r\nContent-Disposition: form-data; name=\"mac\"\r\n\r\n%s\r\n------JKBernie\r\nContent-Disposition: form-data; name=\"data\"; filename=\"%s\"\r\nContent-Type: text/plain\r\n\r\n"
#define HTTP_FILE_POST_END              "\r\n------JKBernie--\r\n"


#define HTTP_FILE_TEST                  "POST /v1/device/data/file/upload HTTP/1.1\r\nHost: api.clife.cn\r\nContent-Length: 296\r\nContent-Type: multipart/form-data; boundary=----JKBernie\r\n\r\n------JKBernie\r\nContent-Disposition: form-data; name=\"deviceCode\"\r\n\r\n0000C558000B011E\r\n------JKBernie\r\nContent-Disposition: form-data; name=\"mac\"\r\n\r\nee953601c95c\r\n------JKBernie\r\nContent-Disposition: form-data; name=\"data\"; filename=\"xx.txt\"\r\nContent-Type: text/plain\r\n\r\nABCDEFG\r\n------JKBernie--\r\n"
#define PRODUCTION_SSID                 "het-test-wifi"
#define PRODUCTION_SSID_KEY             "12345678"
#define PRODUCTION_KEY_TYPE             NET_SECURITY_WPA_WPA2
#define PRODUCTION_IP                   (0xC0A80A64)
#define PRODUCTION_PORT                 (18080)

#define DEFAULT_IDENTIFY_SSID           "HET_000106_579C"
#define DEFAULT_IDENTIFY_SSID_KEY       V_NULL
#define DEFAULT_IDENTIFY_KEY_TYPE       NET_SECURITY_NONE

/* UDP server port */
#define UDP_SERVER_PORT                 (18899)
#define UDP_SERVER_PORT_CHAR            "18899"

/* CTCC AP TCP server port */
#define CTCC_TCP_SERVER_PORT            (7681)

#define TASK_MGR_SLEEP                  (50) // ms, Do Not Change
#define TASK_TRANSFER_SLEEP             (50) // ms, Do Not Change
#define TASK_DS_CTRL_SLEEP              (50) // ms, Do Not Change
#define TASK_USR_SLEEP                  (20) // ms
#define TASK_COMPONENT_SLEEP            (10) // ms, Do Not Change

#define SECOND2MS                       (1000)


/******************************************************************************\
*                        Typedef definitions
\******************************************************************************/


/******************************************************************************\
*                   Global variables and functions
\******************************************************************************/

#endif

/******************************* End of File (H) ******************************/

