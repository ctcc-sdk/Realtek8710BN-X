/******************************************************************************\
*   @Copyright (c/C++): 2016-2026, Bernie Liu
*   @File Name        : PlatformConfig.h
*   @Author           : Bernie Liu
*   @Version          : V00.00.01
*   @Date             : 2018-06-21
*   @Description      :
*
*   @Others           :
*
\******************************************************************************/

#ifndef _PLATFORM_CONGIF_H_
#define _PLATFORM_CONGIF_H_


/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

#define DEV_DEVICEFW_VERSION       "1.0.0.0"
#define DEV_PROFILE_VERSION        "0"
#define DEV_PROTOCOL_VERSION       "1.0.0.0"

/* "1": 8710BN  "2": 8710BX  "3": ESP8266  "4": MTK7682 */
#define DEV_MODEL                  "1"
#define DEV_NAME                   "8710BN"
#define DEV_FIRM                   "HET-REALTEK"

#define CHIP_SELECT_ESP82xx        0
#define CHIP_SELECT_HFx30          1

#define NETWORK_WIFI_PROCESS_EN    1

#if NETWORK_WIFI_PROCESS_EN
    #define THIRD_COM_EN           1
    #define HTTP_FILE_EN           0

    #if THIRD_COM_EN
        #define COM_ID                 H_UART_ID_0
        #if HTTP_FILE_EN
            #define COM_BDR        1500000
        #else
            #define COM_BDR        9600
        #endif
    #endif
#endif

/* 设置编译环境：0，非GCC编译环境；1，GCC编译环境 */
#define USE_SYS_GCC_BUILD_EN    1

/* 是否使能系统串口打印：0，禁能；1，使能 */
#define USE_SYS_DBG_MODE_EN     1

/* 配置串口打印参数：串口号和波特率 */
#if USE_SYS_DBG_MODE_EN
    #define DBG_ID     HET_USART_ID_2
    #define DBG_BDR    921600
#endif

/* FLASH 存储地址定义 */
#define COMPONENT_FLASH_ADDR_START         (4 * 1024)
#define PROTOCOL_STORE_FLASH_ADDR_START    0


/* 此处添加原厂SDK底层硬件头文件 */
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include "FreeRTOS.h"
#include "task.h"


#include "lwip/inet.h"
#include "lwip/ip_addr.h"
#include <lwip/sockets.h>
#include "lwip/netdb.h"
#include <lwip_netconf.h>
#include "lwip/sys.h"
#include "lwip/arch.h"
#include "FreeRTOS.h"
#include "task.h"
#include <osdep_service.h>
#include <platform/platform_stdlib.h>
#include <platform_opts.h>

#include "wifi_constants.h"
#include "wifi_structures.h"
#include "wireless.h"
#include "wifi_conf.h"

#include "gpio_irq_api.h"
#include "objects.h"
#include "timer_api.h"
#include "device_lock.h"
#include "flash_api.h"
#include "PinNames.h"
#include "device.h"
#include "pwmout_api.h"
#include "analogin_api.h"


#endif

/***********************************END OF FILE*******************************************/

