﻿
1. Connection: 小军
2. COM/NET/Common： 书龙
3. Profile/OTA/ServiceActive： 陈文
4. Clife 郑超

Note：

使用场景：读代码前了解模块和文件框架

使用人员：代码移植工程师，Review人员

文件夹说明：

    COM : COM协议解析和数据收发处理
    
    Common ： OPP_CTEI(数据存储内容的数据库定义)
                         OPP_Store 定义Protocol的Flash位置和空间大小，存储（需做加密存储）
                         OPP_TimeStamps 邮戳管理，给协议提供邮戳服务
                         OPP_Define : OPP_DataBase公共宏定义

    Connection : 包括配网，认证登录，和解绑流程

    FCT :  产测模式

    Manager : 调度管理流程

    NET : 对接云协议解析和数据收发处理

    OTA : OTA升级处理

    //OPP_VersionManager: 版本管理/版本号管理   V8.20.1  :  模组source, protocol, 

    Profile : Profile管理及解析

    ServiceActive : 正常业务流程（正常连接业务平台后的心跳及管理）

    

