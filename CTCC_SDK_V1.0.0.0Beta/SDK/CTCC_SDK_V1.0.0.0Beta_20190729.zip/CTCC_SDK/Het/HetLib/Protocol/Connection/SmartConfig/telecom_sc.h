/*
 *
 *
 * Copyright (2019) chenw
 */

#ifndef __TELECOM_SC_H__
#define __TELECOM_SC_H__

#ifdef __cplusplus
extern "C" {
#endif

enum
{
    SC_STATUS_NOTINIT        = -3,
    SC_STATUS_INVALID_PARAMS = -2,
    SC_STATUS_FAILED         = -1,
    SC_STATUS_START          = 0,
    SC_STATUS_CONTINUE       = 0,
    SC_STATUS_CHANNEL_LOCKED = 1,
    SC_STATUS_COMPLETE       = 2,
};

/******************************************************************************/
extern
int32_t telecom_sc_init(void);
/******************************************************************************/

/******************************************************************************/
extern
void telecom_sc_deinit(void);
/******************************************************************************/

/******************************************************************************/
extern
int32_t telecom_sc_parse(uint8_t *pbuffer, int32_t len);
/******************************************************************************/

/******************************************************************************/
extern
int32_t telecom_sc_getResult(char *ssid, int32_t *ssid_len, char *passwd, int32_t *passwd_len);
/******************************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* __TELECOM_SC_H__ */

