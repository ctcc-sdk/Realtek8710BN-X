/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  OPP_COM_Frame.h
**  功能描述 :      用于Clife协议
**  日     期  :  2019.05.15
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/ 2019.05.15  By JKBernie Liu
**           1 首次创建
**
\******************************************************************************/

#ifndef  _OPP_COM_FRAME_H
#define  _OPP_COM_FRAME_H

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

typedef enum
{
    COM_OF_HEAD    = 0x0,
    COM_OF_LEN,                      //1
    COM_OF_RESULLT = COM_OF_LEN + 2, //3
    COM_OF_CMD,                      //4
    COM_OF_DATAS   = COM_OF_CMD + 2, //6
}TE_FRAME_OFFSET_COM;

typedef enum
{
    COM_FRAME_STEP_NONE = 0x0,
    COM_FRAME_STEP_LEN,
    COM_FRAME_STEP_DATAS,
}TE_FRAME_STEP_COM;


typedef struct _tComFrameHead
{
    uint8_t  MagicCode;
    uint16_t FrameLen;
    uint8_t  Resullt;
    uint16_t Code;
}T_ComFrameHead, *P_ComFrameHead;


typedef struct _tComFrame
{
    T_ComFrameHead Head;
    uint16_t       Crc;
    uint16_t       DataLen;
    uint8_t        *pDataBuf;
}T_ComFrame, *P_ComFrame;

/******************************************************************************\
*   @Functions
\******************************************************************************/

/******************************************************************************/
extern
int  OPP_COM_GetFrameStruct(P_ComFrame pCFHdl, uint8_t *pBuf, uint16_t Len);
/******************************************************************************/

/******************************************************************************/
extern
int  OPP_COM_SetFrameHead(uint8_t *pDesBuf, int Code,
                          uint8_t Resullt, uint16_t Len);
/******************************************************************************/

#endif

/******************************* End of File (H) ******************************/
