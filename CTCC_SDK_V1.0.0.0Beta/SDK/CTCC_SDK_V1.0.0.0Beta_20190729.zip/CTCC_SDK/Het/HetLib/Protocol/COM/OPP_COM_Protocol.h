/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  OPP_COM_Protocol.h
**  功能描述 :      用于Clife协议
**  日     期  :  2019.05.15
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/ 2019.05.15  By JKBernie Liu
**           1 首次创建
**
\******************************************************************************/

#ifndef  _OPP_COM_Protocol_H
#define  _OPP_COM_Protocol_H

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/

#define COM_FRAME_HEAD         (0x5A)                                     // 串口协议头码
#define COM_FRAME_MIN_SIZE     (7 + 1)                                    // 串口协议帧最小长度
#define COM_FRAME_DATA_SIZE    (1024)
#define COM_FRAME_MAX_SIZE     (COM_FRAME_DATA_SIZE + COM_FRAME_MIN_SIZE) // 串口协议帧最大长度
#define DC_COM_SIZE            (256)

/* COM Protocol */
enum
{
    EV_DeviceInfo_Report     = 92,         //DeviceID, PIN, CTEI上报
    EV_DeviceInfo_Ack        = 93,         //ACK
    EV_DeviceInfo_Read_Req   = 94,         //读取DeviceID, PIN, CTEI请求
    EV_DeviceInfo_Read_Ack   = 95,         //ACK
    EV_NameVer_Report        = 96,         //Name & Version上报
    EV_NameVer_Ack           = 97,         //ACK
    EV_HeartBeat             = 98,         //心跳,设备主动发起
    EV_HeartBeat_Ack         = 99,         //心跳ACK
    EV_Bind                  = 100,        //设备绑定
    EV_Bind_Ack              = 101,        //设备绑定ACK
    EV_FCT                   = 102,        //设备产测
    EV_FCT_Ack               = 103,        //设备产测ACK
    EV_OTA_Req               = 104,        //控制器升级请求
    EV_OTA_Ack               = 105,        //控制器升级Ack
    EV_OTA_Data_Req          = 106,        //控制器数据请求
    EV_OTA_Data_Ack          = 107,        //控制器数据ACK
    EV_OTA_Result_Report     = 108,        //OTA结果上报
    EV_OTA_Result_Report_Ack = 109,        //OTA结果上报ACK
};

typedef struct
{
    uint8_t  Step;
    uint8_t  Buffer[COM_FRAME_MAX_SIZE];
    uint16_t Len;
    uint16_t Index;
}TS_FRAME_COM;

typedef struct
{
    P_DcHandle   PreDc;
    TS_FRAME_COM Frame;
}TS_CONSOLE_COM;


/******************************************************************************\
*   @Functions
\******************************************************************************/

/*
 * 函数名称 : OPP_COM_In
 * 功能描述 : 获取16位CRC校验
 * 参     数 :
 * 返 回 值 :
 * 示     例 ：
 */
/******************************************************************************/
extern
void  OPP_COM_In(uint8_t Data);
/******************************************************************************/

/*
 * 函数名称 : OPP_COM_FrameChk
 * 功能描述 : 获取16位CRC校验
 * 参     数 :
 * 返 回 值 :
 * 示     例 ：
 */
/******************************************************************************/
extern
uint8_t  OPP_COM_FrameChk(void);
/******************************************************************************/

/*
 * 函数名称 : OPP_COM_GetHandle
 * 功能描述 :
 * 参     数 :
 * 返 回 值 :
 * 示     例 ：
 */
/********************************************************************************/
extern
TS_CONSOLE_COM*  OPP_COM_GetHandle(void);
/********************************************************************************/

/*
 * 函数名称 : Protocol_FrameGet16CRC
 * 功能描述 : 获取16位CRC校验
 * 参     数 :
 * 返 回 值 :
 * 示     例 ：
 */
/********************************************************************************/
extern
uint16_t  OPP_FrameGetCRC16(uint8_t *pBuf, uint16_t Len, uint16_t startPos);
/********************************************************************************/

/******************************************************************************/
uint16_t  OPP_COM_Pack(uint8_t* pDesBuf,
                       int code, uint8_t resullt,
                       uint8_t *pSrcBuf, int len, char from, char to);
/******************************************************************************/

/*
 * 函数名称 : OPP_COM_PackToDS
 * 功能描述 : COM帧查询处理
 * 参     数 : 无
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_COM_PackToDS(int code, uint8_t resullt,
                      uint8_t *pBuf, int len, char from, char to);
/******************************************************************************/


/*
 * 函数名称 : OPP_COM_Unpack
 * 功能描述 : COM帧查询处理
 * 参     数 : 无
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_COM_Unpack(P_DSParam pDsParam);
/******************************************************************************/

#endif

/******************************* End of File (H) ******************************/
