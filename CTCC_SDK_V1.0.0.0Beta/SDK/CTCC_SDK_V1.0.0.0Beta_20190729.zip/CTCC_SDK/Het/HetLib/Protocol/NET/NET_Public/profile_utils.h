#ifndef __PROFILE_UTILS_H__
#define __PROFILE_UTILS_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "cJSON.h"

#define     STORE_SEQUENCE_MAX_NUM    4
#define     str_addr_get              value_addr_get
#define     IsIpString                HAL_Socket_IsIpString

typedef struct _T_Object
{
    char  *buf;
    short buf_size;
    short buf_len;
}T_Object;

typedef enum
{
    OBJ_TYPE_INT,
    OBJ_TYPE_UINT,
    OBJ_TYPE_INT2STR,
    OBJ_TYPE_BOOL,
    OBJ_TYPE_NULL,
    OBJ_TYPE_STRING,
}obj_type_e;

typedef enum
{
    FW_VER,
    PROT_VER,
    PROFILE_VER,
}version_e;

typedef enum
{
    SVR_TYPE_LOGIN = 0,
    SVR_TYPE_TCP,
    SVR_TYPE_UDP,
}svr_type_e;

extern char devMac[13];
extern char devCTEI[17];

extern char parentDevMac[13];
extern char acDevip[20];
extern char rptType[5];

extern int hexstr2hex(uint8_t *out, uint8_t *in, int len);

extern T_Object *Object_init(int max_size);

extern int profile_svr_init(void);

/************************************************************
 * Communication parameters
 *************************************************************/
extern const char *get_version(version_e ver);
extern const char *get_firm(version_e firm);

extern const char *get_name(void);

extern const char *get_profileversion(version_e ver);

extern const char *get_model(void);

extern const char *get_token(void);

extern int set_token(const char *token, int token_len);

extern const char *get_devId(void);
extern const char *get_ctei(void);

//extern const char *get_serialId(void);
extern const char *get_errorCode(void);
extern const char *get_errorInfo(void);


extern const char *get_traceId(void);

extern const char *get_devPINcode(void);

extern const char *get_sessionKey(void);

extern int set_sessionKey(const char *sessionKey, int sessionKey_len);

/*************ADD start*********************/

extern int  get_log_switch(void);
extern void  set_log_switch(char sw);
/*************ADD module start*********************/

/****************ADD end*****************************/
extern int get_sequence(void);

extern void set_sequence(int seq);


extern void  set_heartBeat(int heartBeat);
extern void  set_authInterval(int authInterval);

extern int set_local_expt_seq(int code, int seq);
extern unsigned char check_local_expt_seq(int code, int seq);
extern int  get_local_sequence(void);
extern void  set_local_sequence(int seq);

extern int  get_remote_sequence(int code);
extern void  set_remote_sequence(int seq, int code);
extern void  clr_remote_sequence(int code);
extern void  clr_remote_sequence_force(int code);

extern int  get_log_level(void);
extern void  set_log_level(const char *level);
extern int  get_log_type(void);
extern void  set_log_type(int type);

extern unsigned char is_self_process_profile(void);

extern uint32_t get_timestamp(void);
extern void set_timestamp(uint32_t time);
extern int set_obj_alarmTime(T_Object *obj, uint32_t alarmTime);

extern void timestamp_increase(void);

extern int get_serialId_max(void);
extern int get_modules_max(void);

extern svr_type_e get_svr_type(void);

extern void set_svr_type(svr_type_e type);

extern int get_svr_info(uint8_t ip[4], uint16_t *port, svr_type_e info_type);

extern int set_svr_info(const char *info_str, svr_type_e info_type);

extern int  server_command_ack(int32_t code, uint32_t result, void *args);

extern int get_mods_number(void);

extern const char *get_mod_name(unsigned char index);

extern const char *get_mod_version(unsigned char index);

extern const char *get_mod_version_by_name(const char *name);

extern void set_ota_notify_code(int code);

/************************************************************
 * Utils of cbc aes
 *************************************************************/
extern int obj_data_encode(uint8_t *pdata, unsigned int *pdata_len, unsigned char is_login);

extern int obj_data_decode(uint8_t *pdata, unsigned int *pdata_len, unsigned char is_login);

/************************************************************
 * Utils of json object
 *************************************************************/

extern T_Object *Object_init(int max_size);

extern void Object_deinit(T_Object *obj);

extern char *get_cur_obj_buf(T_Object *obj);

extern int set_cur_obj_buf(T_Object *obj, int len);

extern int set_pkg_start(T_Object *obj);

extern int set_pkg_end(T_Object *obj);

extern int set_symbol(T_Object *obj, char symbol);

extern int set_obj_start(T_Object *obj);

extern int set_obj_end(T_Object *obj);

extern int set_struct_start(T_Object *obj);

extern int set_struct_end(T_Object *obj);

extern int set_comma(T_Object *obj);

extern int set_quotation_mark(T_Object *obj);

extern int set_objs(T_Object *obj, const char *name, void *value, obj_type_e type);


extern int set_obj_code(T_Object *obj, int code);
extern int set_obj_sequence(T_Object *obj, int seq);

extern int set_obj_deviceId(T_Object *obj, const char *devid);

//extern int set_obj_serialId(T_Object *obj, const char *serialId);

extern int set_obj_errorCode(T_Object *obj, const char *errorCode);

extern int set_obj_errorInfo(T_Object *obj, const char *errorInfo);

extern int set_obj_traceId(T_Object *obj, const char *traceid);

extern int set_obj_firm(T_Object *obj, const char *firm);

//extern int set_obj_devMac(T_Object *obj, const char *devmac);
//extern int set_obj_mac(T_Object *obj, const char *mac);

extern int  set_obj_devMac(T_Object *obj);
extern int  set_obj_parentDevMac(T_Object *obj);


extern int set_obj_devCTEI(T_Object *obj, const char *devctei);

extern int set_obj_PardevMac(T_Object *obj, const char *padevmac);

extern int set_obj_ip(T_Object *obj);

extern int set_obj_rptType(T_Object *obj, int ptType);
extern int set_obj_type(T_Object *obj, const char *Type);
//extern int set_obj_logLevel(T_Object *obj, const char *logLevel);
extern int  set_obj_logLevel(T_Object *obj, int level);

extern int set_obj_message(T_Object *obj, const char *message);


extern int set_obj_timestamp(T_Object *obj, uint32_t timestamp);

extern int set_obj_errorTime(T_Object *obj, uint32_t errorTime);

extern int set_obj_serialId(T_Object *obj, int serialId);

extern int set_obj_token(T_Object *obj, const char *token);
extern int set_obj_model(T_Object *obj, const char *model);

extern int set_obj_modules(T_Object *obj, const char *module);

extern int set_obj_moduleName(T_Object *obj, const char *moduleName);

extern int set_obj_version(T_Object *obj, const char *ver);

extern int set_obj_curVersion(T_Object *obj, const char *curver);

extern int set_obj_name(T_Object *obj, const char *name);


extern int set_obj_dev_version(T_Object *obj, const char *ver);

extern int set_obj_profileversion(T_Object *obj, const char *ver);


extern int set_obj_result(T_Object *obj, int result);

extern int set_obj_status(T_Object *obj, const char *sta);

extern void objs_show(T_Object *obj);
extern void json_show_by_len(const char *json, int len);
extern const char * json_get_string(const char *psrc, int psrc_len, const char *name, int *dest_len);


#endif
