/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  OPP_COM.h
**  功能描述 :      用于Clife协议
**  日     期  :  2019.05.15
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/ 2019.05.15  By JKBernie Liu
**           1 首次创建
**
\******************************************************************************/
#ifndef __OPP_PROFILE_H__
#define __OPP_PROFILE_H__
/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/
#define    PROFILE_UPGRADE_TIMEOUT_MS2SECOND    1.2e5            //2min

#define    PROFILE_JSON_NAME_MAX_LEN            20
#define    PROFILE_DP_FORMAT_BASE_LEN           4

#define    PROFILE_JSON_CMD_STRING              "cmd"
#define    PROFILE_JSON_MODE_KEY_STRING         "mode"
#define    PROFILE_JSON_MODE_VALUE_STRING       "MODEL"

/* This used for MCU format */
enum
{
    DP_TYPE_BOOL = 0,
    DP_TYPE_VALUE,
    DP_TYPE_ENUM,
    DP_TYPE_STRING,
    DP_TYPE_RAW,
};

enum
{
    DP_FMT_POS_ID = 0,
    DP_FMT_POS_TYPE,
    DP_FMT_POS_LEN,
    DP_FMT_POS_VALUE,
};

/******************************************************************************\
*   @Functions
\******************************************************************************/

/*
 * 函数名称 : OPP_Profile_Init
 * 功能描述 : Profile 初始化，需要在系统开机启动时调用
 * 参     数 : 无
 * 返 回 值 : @int 成功返回SUCCESS
 *                      失败见错误码
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_Profile_Init(void);
/******************************************************************************/

/*
 * 函数名称 : OPP_Profile_DeInit
 * 功能描述 : Profile 去初始化，更新Profile文件后调用
 * 参     数 : 无
 * 返 回 值 : @int 成功返回SUCCESS
 *                      失败见错误码
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_Profile_DeInit(void);
/******************************************************************************/

/*
 * 函数名称 : OPP_Profile_Upgrade
 * 功能描述 : profile文件升级接口
 * 参     数 : @p_cVersion 传入参数，profile文件版本号（字符串格式）
 *           @p_cUrl 传入参数，profile文件所在的url地址（字符串格式）
 *           @p_cMd5 传入参数，profile文件对应的MD5校验码（字符串格式）
 * 返 回 值 : @int 成功返回SUCCESS
 *                      失败见错误码
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_Profile_Upgrade(const char *p_cVersion,
                         const char *p_cUrl,
                         const char *p_cMd5);
/******************************************************************************/

/*
 * 函数名称 : OPP_Profile_GetSerialIdMaxNum
 * 功能描述 : 获取产品功能的数量值（如3路开关：3个功能相同的开关）
 * 参     数 : 无
 * 返 回 值 : @int32_t 返回产品功能的总个数数值
 * 示     例 ：
 */
/******************************************************************************/
extern
int32_t  OPP_Profile_GetSerialIdMaxNum(void);
/******************************************************************************/

/*
 * 函数名称 : OPP_Profile_Parse2Device
 * 功能描述 : 服务器协议数据格式转换成设备端（MCU）识别的格式
 * 参     数 : @p_cOut 传出参数，存放解析后的设备端（MCU）格式
 *           @p_sdwOutLen 传入传出参数
 *                        传入指定p_cOut的存放空间大小
 *                        传出为实际的设备端（MCU）格式长度
 *           @p_cName 传入参数，服务器协议数据格式带'Name'字段的数据
 *           @p_cParams 传入参数，服务器协议数据格式带'Value'字段的数据
 * 返 回 值 : @int 成功返回SUCCESS
 *                      失败见错误码
 * 示     例 ：
 *         char pbuf[512];
 *         int data_offt = 0;
 *         pbuf[data_offt] = 0x5A;//MCU format of clife
 *         //...do sothing
 *         tRet = OPP_Profile_Parse2Device(&pbuf[data_offt], sizeof(pbuf) - data_offt,
 *                                         "SET_POWER","0");
 */
/******************************************************************************/
extern
int  OPP_Profile_Parse2Device(char *p_cOut,
                              int *p_sdwOutLen,
                              const char *p_cName,
                              const char *p_cParams);
/******************************************************************************/

/*
 * 函数名称 : OPP_Profile_Parse2Server
 * 功能描述 : 设备端（MCU）识别的格式转换成服务器协议数据格式
 * 参     数 : @p_cOutName 传出参数，存放解析后的服务器协议数据格式带'Name'字段的数据
 *           @p_sdwOutNameLen 传入传出参数
 *                        传入指定p_cOutName的存放空间大小
 *                        传出为实际的服务器协议数据格式长度
 *           @p_cOutParams 传出参数，存放解析后的服务器协议数据格式带'Value'字段的数据
 *           @p_sdwOutParamsLen 传入传出参数
 *                        传入指定p_cOutParams的存放空间大小
 *                        传出为实际的服务器协议数据格式长度
 *           @p_cIn 传入参数，设备端（MCU）数据格式
 *           @sdwInLen p_cIn对应的数据长度
 * 返 回 值 : @int 成功返回EOK
 *                失败见错误码“errno.h”
 * 示     例 ：
 *           char pbufName[20] = {0};
 *           char pbufParams[20] = {0};
 *           int pbufName_len = sizeof(pbufName);
 *           int pbufParams_len = sizeof(pbufParams);
 *           // ID, TYPE, LEN, VALUE defined by profile
 *           char pbufMCUdata[4] = {ID, TYPE, LEN, VALUE};
 *           tRet = OPP_Profile_Parse2Server(pbufName, &pbufName_len,
 *                                           pbufParams, &pbufParams_len,
 *                                           pbufMCUdata, sizeof(pbufMCUdata));
 *           //Result, maybe pbufName is string 'POWER', and pbufParams is string '1'
 */
/******************************************************************************/
extern
int  OPP_Profile_Parse2Server(char *p_cOutName,
                              int32_t *p_sdwOutNameLen,
                              char *p_cOutParams,
                              int32_t *p_sdwOutParamsLen,
                              const char *p_cIn,
                              int32_t sdwInLen);
/******************************************************************************/

/*
 * 函数名称 : OPP_Profile_Upgrade_Loop
 * 功能描述 : profile文件下载任务接口
 * 参     数 : 无
 * 返 回 值 : @int 成功返回SUCCESS
 * 失败见错误码
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_Profile_Upgrade_Loop(void);
/******************************************************************************/

#endif

/******************************* End of File (H) ******************************/
