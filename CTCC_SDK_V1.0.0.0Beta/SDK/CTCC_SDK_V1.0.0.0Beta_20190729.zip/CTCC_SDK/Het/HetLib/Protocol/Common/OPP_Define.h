/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  Protocol_Define.h
**  功能描述 :      用于Clife协议
**  作     者  :  Bernie Liu
**  日     期  :  2018.01.01
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/2018.07.25
**           1 首次创建
\******************************************************************************/

#ifndef _OPP_DEFINE_H
#define _OPP_DEFINE_H

#include "../../HAL/BSP/HAL_Config.h"

/******************************************************************************\
*                         Macro definitions
\******************************************************************************/


/******************************************************************************\
*                        Typedef definitions
\******************************************************************************/

#define COM_ID                  H_UART_ID_0


#define STOP_CHAR     '\0'

/* DataStream Direction Define */
#define DIR_MCU       (0) // 模组端
#define DIR_CLOUD     (1) // CLOUD 端
#define DIR_APP       (2) // APP 端
#define DIR_MODULE    (3) // 模组端

/*
 *  DF = Dirction From
 *  DT = Direction To
 */
typedef enum
{
    FROM_MCU    = DIR_MCU,
    FROM_CLOUD  = DIR_CLOUD,
    FROM_APP    = DIR_APP,
    FROM_MODULE = DIR_MODULE,
    FROM_MAX
}E_DS_FromType;

typedef enum
{
    TO_MCU    = DIR_MCU,
    TO_CLOUD  = DIR_CLOUD,
    TO_APP    = DIR_APP,
    TO_MODULE = DIR_MODULE,
    TO_UNKOWN,
    TO_MAX
}E_DS_ToType;

// Command Define


// Command Define
#if 1
typedef enum
{
    EV_CM_PT_HeartBeat                       = 1000, //心跳
    EV_PT_CM_HeartBeat_Ack                   = 1001, //心跳响应
    EV_CM_PT_Login                           = 1002, //设备登录
    EV_PT_CM_Login_Ack                       = 1003, //设备登录响应
    EV_CM_PT_Connect                         = 1004, //设备连接
    EV_PT_CM_Connect_Ack                     = 1005, //设备连接响应
    EV_PT_CM_AttrConstraint_Notice_Ack       = 2000, //设备属性约束通知响应
    EV_CM_PT_AttrConstraint_Notice_Req       = 2001, //设备属性约束通知请求
    EV_CM_PT_Status_Query_Ack                = 2002, //设备状态查询响应
    EV_PT_CM_Status_Query_Req                = 2003, //设备状态查询请求
    EV_CM_PT_Status_Control_Ack              = 2004, //设备状态控制响应
    EV_PT_CM_Status_Control_Req              = 2005, //设备状态控制请求
    EV_CM_PT_Status_Report                   = 2006, //设备状态上报请求
    EV_PT_CM_Status_Report_Ack               = 2007, //设备状态上报响应
    EV_CM_PT_Status_Alarm_Req                = 2008, //设备状态告警请求
    EV_PT_CM_Status_Alarm_Ack                = 2009, //设备状态告警响应
    EV_CM_PT_Fault_Feedback_Req              = 2010, //设备故障反馈请求
    EV_PT_CM_Fault_Feedback_Ack              = 2011, //设备故障反馈响应
    EV_CM_PT_SubDev_Login                    = 2012, //子设备鉴权请求
    EV_PT_CM_SubDev_Login_Ack                = 2013, //子设备鉴权响应
    EV_CM_PT_SubDev_Relieve_Ack              = 2014, //子设备解绑响应
    EV_PT_CM_SubDev_Relieve_Req              = 2015, //子设备解绑请求
    EV_CM_PT_SubDev_Bind_Report              = 2016, //子设备绑定上报请求
    EV_PT_CM_SubDev_Bind_Report_Ack          = 2017, //子设备绑定上报响应
    EV_CM_PT_SubDev_Relieve_Report           = 2018, //子设备解绑上报请求
    EV_PT_CM_SubDev_Relieve_Report_Ack       = 2019, //子设备解绑上报响应
    EV_CM_PT_SubDev_Online_Status_Report     = 2020, //子设备在线状态上报请求
    EV_PT_CM_SubDev_Online_Status_Report_Ack = 2021, //子设备在线状态上报响应
    EV_CM_PT_Version_Report                  = 2022, //设备版本上报请求
    EV_PT_CM_Version_Report_Ack              = 2023, //设备版本上报响应
    EV_CM_PT_OTA_Notice_Ack                  = 2024, //设备版本升级通知响应
    EV_PT_CM_OTA_Notice_Req                  = 2025, //设备版本升级通知请求
    EV_CM_PT_OTA_Result_Report               = 2026, //设备版本升级结果上报请求
    EV_PT_CM_OTA_Result_Report_Ack           = 2027, //设备版本升级结果上报响应
    EV_CM_PT_ResourceChange_Report           = 2028, //设备资源变化上报请求
    EV_PT_CM_ResourceChange_Report_Ack       = 2029, //设备资源变化上报响应
    EV_CM_PT_Resource_Mgr_Ack                = 2030, //设备资源管理响应
    EV_PT_CM_Resource_Mgr_Req                = 2031, //设备资源管理请求
    EV_CM_PT_EventInfo_Report                = 2032, //设备事件信息上报请求
    EV_PT_CM_EventInfo_Report_Ack            = 2033, //设备事件信息上报响应
    EV_CM_PT_Speech_Synthesis_Req            = 3000, //语音合成请求
    EV_PT_CM_Speech_Synthesis_Ack            = 3001, //语音合成响应
    EV_CM_PT_Speech_Control_Req              = 3002, //语音控制请求
    EV_PT_CM_Speech_Control_Ack              = 3003, //语音控制响应

    EV_CM_PT_Profile_Version_Report          = 4000, //Profile版本上报请求包
    EV_PT_CM_Profile_Version_Report_Ack      = 4001, //Profile版本上报响应包
    EV_CM_PT_Profile_OTA_Ack                 = 4002, //Profile文件下发响应包
    EV_PT_CM_Profile_OTA_Req                 = 4003, //Profile文件下发请求包
    EV_CM_PT_Profile_OTA_Result_Report       = 4004, //Profile版本升级结果上报请求包
    EV_PT_CM_Profile_OTA_Result_Report_Ack   = 4005, //Profile版本升级结果上报响应包
    EV_CM_PT_Log_Report                      = 4006, //模组日志信息上报请求包
    EV_PT_CM_Log_Report_Ack                  = 4007, //模组日志信息上报响应包
    EV_CM_PT_Log_Set_Ack                     = 4008, //模组日志上报设置响应包
    EV_PT_CM_Log_Set_Req                     = 4009, //模组日志上报设置请求包
    EV_CM_PT_Module_Version_Report           = 4010, //模组版本上报请求包
    EV_PT_CM_Module_Version_Report_Ack       = 4011, //模组版本上报响应包
    EV_CM_PT_Module_OTA_Ack                  = 4012, //模组版本升级通知响应包
    EV_PT_CM_Module_OTA_Req                  = 4013, //模组版本升级通知请求包
    EV_CM_PT_Module_OTA_Result_Report        = 4014, //模组版本升级结果上报请求包
    EV_PT_CM_Module_OTA_Result_Report_Ack    = 4015, //模组版本升级结果上报响应包
}TE_CTCC_COMMAND;

/* error code about net protocol frame */
enum
{
    ERR_CODE_SUCESS          = 0,      //success
    ERR_CODE_INVALID         = 100001, //request args invalid
    ERR_CODE_DEVID           = 200001, //device id not exists
    ERR_CODE_PIN             = 200002, //device pin code error
    ERR_CODE_LOGIN           = 200003, //device login(auth) failed
    ERR_CODE_OFFLINE         = 300001, //device or sub device offline
    ERR_CODE_UNSUPPORT       = 300002, //device or sub device unsupport the 'CODE'
    ERR_CODE_VOICE           = 400001, //voice not exists
    ERR_CODE_VOICE_MORE      = 400002, //has more voice later
    ERR_CODE_NO_VOICE_DEV    = 400003, //no voice device
    ERR_CODE_UNSUPPORT_VOICE = 400004, //unsupport bussness about voice
    ERR_CODE_RECONG_VOICE    = 400005, //voice recongnition failed
    ERR_CODE_DEV_UNKNOWN     = 899999, //unknown error about the device
    ERR_CODE_SVR_UNKNOWN     = 999999, //unknown error about the server
};

#endif


/******************************************************************************\
*                   Global variables and functions
\******************************************************************************/

/******************************************************************************\
*                            Includes
\******************************************************************************/

#include "../../Common/Error_Define.h"
#include "OPP_TimeStamp.h"
#include "OPP_DataBase.h"
#include "OPP_SoftTimer.h"
#include "OPP_Store.h"
#include "OPP_TimeStamp.h"

#include "OPP_Utils.h"
#include "../OTA/http/OPP_Http.h"
#include "../Profile/OPP_Profile.h"
#include "../Connection/Auth/OPP_Auth.h"
#include "../Manager/OPP_Manager.h"
#include "../Manager/OPP_DSContorl.h"
#include "../COM/OPP_COM_Communication.h"
#include "../COM/OPP_COM_Protocol.h"
#include "../COM/OPP_COM_Frame.h"
#include "../NET/OPP_NET_Protocol.h"
#include "../NET/OPP_NET_Communication.h"
#include "../OTA/OPP_OTA.h"
#include "../ServiceActive/OPP_ServiceActive.h"
#include "../Connection/OPP_Connection.h"
#include "../Connection/AP/OPP_AP.h"
#include "../Connection/SmartConfig/OPP_SmartConfig.h"
#include "../OTA/OPP_MOD_OTA.h"

#endif

/******************************* End of File (H) ******************************/
