/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  OPP_DataBase.h
**  功能描述 :      用于Clife协议
**  日     期  :  2019.05.15
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/ 2019.05.15  By JKBernie Liu
**           1 首次创建
**
\******************************************************************************/
#ifndef _OPP_DATABASE_H
#define  _OPP_DATABASE_H

/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/
/* USER sector: F5000 - FA000*/

/* database sector: 0xFD000 - 0xFE000 */
#define KPD_START_ADDR               (0xFD000)
#define KPD_BACKUP_START_ADDR        (0xFE000)

/* profile sector: 0xFB000 - 0xFC000 */
#define PROFILE_START_ADDR           (0xFB000)
#define PROFILE_MAX_SECTORS          (2)

#define FLASH_SECTOR_SIZE            (0x1000)

#define FLAG_SIZE                    (1)
#define BIND_FLAG_SIZE               (FLAG_SIZE)
#define ROUTER_SSID_SIZE             (32)
#define ROUTER_PWD_SIZE              (64)
#define DEVICE_ID_SIZE               (34)
#define PIN_CODE_SIZE                (32)
#define CTEI_SIZE                    (16)
#define VERSION_SIZE                 (16)
#define FW_VERSION_SIZE              VERSION_SIZE
#define PROT_VERSION_SIZE            VERSION_SIZE
#define PROFILE_VERSION_SIZE         (3)
#define LOGIN_HOST_SIZE              (32)
#define LOGIN_PORT_SIZE              (2)

#define LINK_HOST_SIZE               (16)


#define DEVICE_VERSION_SIZE          (16)

#if 1 //add by zhengxj  WifiStatus  bit 20190628
#define NET_WIFI_STATUS_RSSI_MASK    (0x07)
#define NET_WIFI_STATUS_NET_MASK     (0x70)
#define NET_WIFI_STATUS_PROFILE      (3)
#define NET_WIFI_STATUS_BIND         (4)
#define NET_WIFI_STATUS_ROUTER       (5)
#define NET_WIFI_STATUS_SERVER       (6)
#define NET_WIFI_STATUS_OTA          (7)
#define NET_WIFI_STATUS_ALL          (0)
#endif

#define DEVICEID_CLASS_POS_START     (8)

/* ramdata 中的'sock_type'用 */
typedef enum
{
    SERVER_SOCK_TYPE_TCP = (uint8_t) 0,
    SERVER_SOCK_TYPE_UDP = (uint8_t) 1,
}server_sock_type_e;

/* ramdata 中的'systemState' 用 */
typedef enum
{
    SYS_STATE_IDLE = 0,
    SYS_STATE_NETCFG,
    SYS_STATE_ROUTER_LINK,
    SYS_STATE_TIME_ASYN,
    SYS_STATE_LOGIN,
    SYS_STATE_LOGIN_FAULT,
    SYS_STATE_LINK,
    SYS_STATE_LINK_FAULT,
    SYS_STATE_NORMAL,
}sys_state_e;

/* romdata 中的'logLevel' 用 */
enum
{
    LOG_LEVEL_ALL = 0,
    LOG_LEVEL_DEBUG,
    LOG_LEVEL_INFO,
    LOG_LEVEL_WARN,
    LOG_LEVEL_ERROR,
};

/* romdata 中的'logSwitch' 用 */
enum
{
    LOG_SWITCH_OFF = 0,
    LOG_SWITCH_ON  = !LOG_SWITCH_OFF,
};

#pragma pack(1)
/* 需要存储到flash的数据结构 */
typedef struct _romdata_t
{
    uint8_t  bindFlag;
    uint8_t  profileVer[PROFILE_VERSION_SIZE + 1]; //profile version
    uint8_t  fwVer[VERSION_SIZE + 1];              //firmware version
    uint8_t  protVer[VERSION_SIZE + 1];            //protocol version of Elink
    uint8_t  ssid[ROUTER_SSID_SIZE + 1];           //router ssid
    uint8_t  passwd[ROUTER_PWD_SIZE + 1];          //router password
    uint8_t  deviceId[DEVICE_ID_SIZE + 1];
    uint8_t  pinCope[PIN_CODE_SIZE + 1];
    uint8_t  ctei[CTEI_SIZE + 1];
    uint8_t  loginHost[LOGIN_HOST_SIZE + 1];
    uint16_t loginPort;
    uint8_t  selfProcessMode;
    uint8_t  logLevel;
    uint8_t  logSwitch;
#define ROMDATA_SIZE    ((PROFILE_VERSION_SIZE + 1) + (VERSION_SIZE + 1) + \
                         (VERSION_SIZE + 1) + (ROUTER_SSID_SIZE + 1) +     \
                         (ROUTER_PWD_SIZE + 1) + (DEVICE_ID_SIZE + 1) +    \
                         (PIN_CODE_SIZE + 1) + (CTEI_SIZE + 1) +           \
                         (LOGIN_HOST_SIZE + 1) + LOGIN_PORT_SIZE +         \
                         BIND_FLAG_SIZE + FLAG_SIZE + FLAG_SIZE + FLAG_SIZE)
#if (ROMDATA_SIZE % 4) // 4 bytes aligned
    uint8_t full[4 - (ROMDATA_SIZE % 4)];
#endif
}romdata_t;

/* 不需要存储到flash的数据结构 */
typedef struct _ramdata_t
{
    char     linkHost[LINK_HOST_SIZE];
    uint16_t linkPort;

    uint8_t  sock_type;
    uint8_t  WifiStatus; //wifi 状态
    uint8_t  systemState;
    uint8_t  profileDnState;
    uint8_t  logType;
    uint8_t  modsOtaState; //modules(except master) ota state
    uint8_t  OtaState;
}ramdata_t;
#pragma pack()

typedef romdata_t T_StoreDataBase, *P_StoreDataBase;

typedef struct
{
    /* 新的存储结构 */
    romdata_t romdata;
    ramdata_t ramdata;
}T_DataBase, *P_DataBase;

#define    DB_SET_STATE_BITS(org, value, bit_pos) \
    do { if (((org) & (1 << (bit_pos))) != ((value) << (bit_pos))) { if (value) { DB_Set_WifiStatus((org) | ((value) << bit_pos)); }else{ DB_Set_WifiStatus((org) & (uint8_t) ~(1 << (bit_pos))); } } } while (0)

#define    DB_Set_RssiLevel(level)       DB_Set_WifiStatus((DB_Get_WifiStatus() & (uint8_t) ~NET_WIFI_STATUS_RSSI_MASK) | ((level) & NET_WIFI_STATUS_RSSI_MASK))
#define    DB_Set_ProfileState(state)    DB_SET_STATE_BITS(DB_Get_WifiStatus(), ((state) != 0 ? 1 : 0), NET_WIFI_STATUS_PROFILE)
#define    DB_Set_RouterState(state)     DB_SET_STATE_BITS(DB_Get_WifiStatus(), ((state) != 0 ? 1 : 0), NET_WIFI_STATUS_ROUTER)
#define    DB_Set_BindState(state)       DB_SET_STATE_BITS(DB_Get_WifiStatus(), ((state) != 0 ? 1 : 0), NET_WIFI_STATUS_BIND)
#define    DB_Set_ServerState(state)     DB_SET_STATE_BITS(DB_Get_WifiStatus(), ((state) != 0 ? 1 : 0), NET_WIFI_STATUS_SERVER)
#define    DB_Set_OTAState(state)        DB_SET_STATE_BITS(DB_Get_WifiStatus(), ((state) != 0 ? 1 : 0), NET_WIFI_STATUS_OTA)

#define    DB_Get_RssiLevel()            (DB_Get_WifiStatus() & NET_WIFI_STATUS_RSSI_MASK)
#define    DB_Get_ProfileState()         (DB_Get_WifiStatus() & (1 << NET_WIFI_STATUS_PROFILE))
#define    DB_Get_RouterState()          (DB_Get_WifiStatus() & (1 << NET_WIFI_STATUS_ROUTER))
#define    DB_Get_BindState()            (DB_Get_WifiStatus() & (1 << NET_WIFI_STATUS_BIND))
#define    DB_Get_ServerState()          (DB_Get_WifiStatus() & (1 << NET_WIFI_STATUS_SERVER))
#define    DB_Get_OTAState()             (DB_Get_WifiStatus() & (1 << NET_WIFI_STATUS_OTA))
#define    DB_Is_WifiStatusOk()          (DB_Get_WifiStatus() & NET_WIFI_STATUS_NET_MASK)
/******************************************************************************\
*   @Functions
\******************************************************************************/

/*
 * 函数名称 : DB_Get_StoreHandle
 * 功能描述 : 数据库存储接口协议操作handle
 * 参     数 : 无
 * 返 回 值 : P_StoreDataBase 存储结构数据句柄
 * 示     例 ：
 */
/********************************************************************************/
extern
P_StoreDataBase  DB_Get_StoreHandle(void);
/********************************************************************************/



/*
 * 函数名称 : DB_Get_Handle
 * 功能描述 : 获取database操作接口句柄
 * 参     数 : 无
 * 返 回 值 : database操作接口句柄
 * 示     例 ：
 */
/******************************************************************************/
extern
P_DataBase  DB_Get_Handle(void);
/******************************************************************************/


/*
 * 函数名称 : DB_Set_BindFlag
 * 功能描述 : 设置绑定标志
 * 参     数 : 无
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
void  DB_Set_BindFlag(uint8_t Bindflag);
/******************************************************************************/


/*
 * 函数名称 : DB_Get_Bind_Flag
 * 功能描述 : 获取绑定标志
 * 参     数 : 无
 * 返 回 值 : 绑定标志
 * 示     例 ：
 */
/******************************************************************************/
extern
uint8_t  DB_Get_BindFlag(void);
/******************************************************************************/



/*
 * 函数名称 : DB_SetRouterSSID
 * 功能描述 : 设置路由器ssid
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS，失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_RouterSSID(uint8_t* pucSSID, int len);
/******************************************************************************/


/*
 * 函数名称 : DB_GetRouterSSID
 * 功能描述 : 获取路由器ssid
 * 参     数 : 无
 * 返 回 值 : 路由器ssid
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_RouterSSID(void);
/******************************************************************************/


/*
 * 函数名称 : DB_Set_RouterPWD
 * 功能描述 : 设置路由器密码
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS，失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_RouterPWD(uint8_t *pPwd, int len);
/******************************************************************************/


/*
 * 函数名称 : DB_Get_RouterPWD
 * 功能描述 : 获取路由器密码
 * 参     数 : 无
 * 返 回 值 : 路由器密码
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_RouterPWD(void);
/******************************************************************************/

/*
 * 函数名称 : DB_Set_DeviceID
 * 功能描述 : 设置deviceId
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS，失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_DeviceID(uint8_t* pDevID, int len);
/******************************************************************************/


/*
 * 函数名称 : DB_Get_DeviceID
 * 功能描述 : 获取deviceId
 * 参     数 : 无
 * 返 回 值 : deviceId
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_DeviceID(void);
/******************************************************************************/


/*
 * 函数名称 : DB_Set_PIN_Code
 * 功能描述 : 设置PIN码
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS，失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_PINCode(uint8_t *pPinCode, int len);
/******************************************************************************/

/*
 * 函数名称 : DB_Get_PINCode
 * 功能描述 : 获取PIN码
 * 参     数 : 无
 * 返 回 值 : PIN码
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_PINCode(void);
/******************************************************************************/


/*
 * 函数名称 : DB_Set_CTEI
 * 功能描述 : 设置CTEI接口
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS，失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_CTEI(uint8_t *pCtei, int len);
/******************************************************************************/

/*
 * 函数名称 : DB_Get_CTEI
 * 功能描述 : 获取CTEI接口
 * 参     数 : 无
 * 返 回 值 : 返回对应的CTEI码
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_CTEI(void);
/******************************************************************************/


/*
 * 函数名称 : DB_Set_DeviceFwVer
 * 功能描述 : 设置设备固件版本
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS，失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_DeviceFwVer(uint8_t *pDevVer, int Len);
/******************************************************************************/


/*
 * 函数名称 : DB_Get_DeviceFwVer
 * 功能描述 : 获取设备固件版本
 * 参     数 : 无
 * 返 回 值 : 设备固件版本
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_DeviceFwVer(void);
/******************************************************************************/

/*
 * 函数名称 : DB_Set_ProtocolVer
 * 功能描述 : 设置Elink协议版本
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS， 失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_ProtocolVer(uint8_t *pVer, int Len);
/******************************************************************************/


/*
 * 函数名称 : DB_Get_ProtocolVer
 * 功能描述 : 获取Elink协议版本
 * 参     数 : 无
 * 返 回 值 : 返回Elink协议版本
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_ProtocolVer(void);
/******************************************************************************/


/*
 * 函数名称 : DB_Set_ProfileVer
 * 功能描述 : 设置profile版本
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS， 失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Set_ProfileVer(uint8_t* pProfileVer, int Len);
/******************************************************************************/

/*
 * 函数名称 : DB_Get_ProfileVer
 * 功能描述 : 获取profile版本
 * 参     数 : 无
 * 返 回 值 : profile版本号
 * 示     例 ：
 */
/******************************************************************************/
extern
const char*  DB_Get_ProfileVer(void);
/******************************************************************************/


/*
 * 函数名称 : DB_Write_Profile
 * 功能描述 : 写profile文件接口
 * 参     数 : 无
 * 返 回 值 : 成功返回SUCCESS， 失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Write_Profile(uint32_t Offset, uint8_t* pBuf, int Len);
/******************************************************************************/


/*
 * 函数名称 : DB_Read_Profile
 * 功能描述 : 读profile文件
 * 参     数 : Offset 偏移地址，
 * 返 回 值 : 成功返回SUCCESS， 失败返回FAIL
 * 示     例 ：
 */
/******************************************************************************/
extern
int  DB_Read_Profile(uint32_t Offset, uint8_t* pBuf, int Len);
/******************************************************************************/


/*
 * 函数名称 : DB_Initial
 * 功能描述 : 初始化DB
 * 参     数 : Offset 偏移地址，
 * 返 回 值 : int,列出该接口所对应的所有Code，并说明
 * 示     例 ：
 */
/******************************************************************************/
extern int  DB_Initial(void);
/******************************************************************************/

#if 1 //added by chenw 20190626
extern
void  DB_Set_LoginHost(const char *host);

extern
void  DB_Set_LoginPort(uint16_t port);

extern
const char * DB_Get_LoginHost(void);

extern
uint16_t  DB_Get_LoginPort(void);

extern
void  DB_Set_LinkHost(const char *host);

extern
void  DB_Set_LinkPort(uint16_t port);

extern
const char * DB_Get_LinkHost(void);

extern
uint16_t  DB_Get_LinkPort(void);

extern
void  DB_Set_ServerSockType(server_sock_type_e type);

extern
server_sock_type_e  DB_Get_ServerSockType(void);

extern
uint8_t  DB_Get_DevSerialIdNum(void);

extern
sys_state_e  DB_Get_systemState(void);

extern
void  DB_Set_systemState(sys_state_e state);

extern
void  DB_Set_UpgradeProfileState(uint8_t state);

extern
uint8_t  DB_Get_UpgradeProfileState(void);

extern
void  DB_Set_SelfProcessProfile(unsigned char mode);

extern
unsigned char  DB_Get_SelfProcessProfile(void);

extern
unsigned char  DB_Get_logLevel(void);

extern
void  DB_Set_logLevel(unsigned char level);

extern
unsigned char  DB_Get_logSwitch(void);

extern
void  DB_Set_logSwitch(unsigned char sw);

extern
unsigned char  DB_Get_logType(void);

extern
void  DB_Set_logType(unsigned char type);

extern
void  DB_Set_modsOtaState(uint8_t state);

extern
unsigned char  DB_Get_modsOtaState(void);

extern
void  DB_Set_masterModOtaState(uint8_t state);

extern
uint8_t  DB_Get_masterModOtaState(void);

#endif

#if 1 //add by zhengxj 20190628
/********************************************************************************/
extern
void  DB_Set_WifiStatus(const uint8_t wifiStatus);
/********************************************************************************/

/********************************************************************************/
extern
uint8_t  DB_Get_WifiStatus(void);
/********************************************************************************/
#endif

#endif

/******************************* End of File (H); ******************************/
