/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  OPP_COM.h
**  功能描述 :      用于Clife协议
**  日     期  :  2019.05.15
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/ 2019.05.15  By JKBernie Liu
**           1 首次创建
**
\******************************************************************************/
#ifndef __OPP_MOD_OTA_H__
#define __OPP_MOD_OTA_H__
/******************************************************************************\
*   @includes
\******************************************************************************/

/******************************************************************************\
*   @Definitions
\******************************************************************************/
#define    MOD_OTA_TIMEOUT_MS2SECOND    3e5            //5min
#define    MOD_OTA_SUPPORT_MAX_NUM      4
#define    MOD_OTA_NAME_SIZE            8
#define    MOD_OTA_VERSION_SIZE         16

/******************************************************************************\
*   @Typedef
\******************************************************************************/
typedef void (*modulesOtaCallback_t)(unsigned char *, int, int, int);

/******************************************************************************\
*   @Functions
\******************************************************************************/

/******************************************************************************/
/*
 * 函数名称 : OPP_Profile_Upgrade
 * 功能描述 : profile文件升级接口
 * 参     数 : @p_cName 传入参数，子模块名称（字符串格式）
 *           @p_cVersion 传入参数，子模块升级固件包版本号（字符串格式）
 *           @p_cUrl 传入参数，子模块升级固件包所在的url地址（字符串格式）
 *           @p_cMd5 传入参数，子模块升级固件包对应的MD5校验码（字符串格式）
 * 返 回 值 : @int 成功返回SUCCESS
 *                      失败见错误码
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_MOD_OTA_ModUpgrade(const char *p_cName,
                            const char *p_cVersion,
                            const char *p_cUrl,
                            const char *p_cMd5);


/******************************************************************************/
/*
 * 函数名称 : OPP_MOD_OTA_Loop
 * 功能描述 : 子模块升级任务接口
 * 参     数 : 无
 * 返 回 值 : @int 成功返回SUCCESS
 * 失败见错误码
 * 示     例 ：
 */
/******************************************************************************/
extern
int  OPP_MOD_OTA_Loop(void);

extern
int OPP_MOD_OTA_Config(const char *name, const char *version, modulesOtaCallback_t otaCb);

extern
const char *OPP_MOD_OTA_Get_versionByName(const char *name);

extern
const char *OPP_MOD_OTA_Get_versionByIndex(unsigned char index);

extern
const char *OPP_MOD_OTA_Get_nameByIndex(unsigned char index);

extern
int OPP_MOD_OTA_Get_modulesNum(void);

#endif

/******************************* End of File (H) ******************************/
