/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  HOS_Inc.h
**  功能描述 :      供SOC应用层使用
**  日     期  :  2019.05.15
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/ 2019.05.15  By JKBernie Liu
**           1 首次创建
**
\******************************************************************************/
#ifndef __HOS_INC_H__
#define __HOS_INC_H__
/******************************************************************************\
*   @includes
\******************************************************************************/

#include "../HetLib/Protocol/Common/OPP_Define.h"

/******************************************************************************\
*   @Definitions
\******************************************************************************/

typedef enum
{
    EVENT_SUCCESS = 0,
    EVENT_ROUTER,          //连接到路由器
    EVENT_ERR_ROUTER,      //没有连接到路由器
    EVENT_LOGIN,           //登录到服务器
    EVENT_ERR_LOGIN,       //没有登录到服务器
    EVENT_AUTH,            //服务器认证通过
    EVENT_ERR_AUTH,        //没有进行服务器认证
    EVENT_ERR_DEVID,       //没有配置deviceId
    EVENT_ERR_INNER,       //内部错误：内存不足、程序异常、参数问题等
}EventCode_e;

typedef void (*pEventFunc)(int);
typedef void (*pRecvFunc)(uint8_t*, uint16_t);

/******************************************************************************\
*   @Functions
\******************************************************************************/

/*
 * Function Name : HOS_SrvStart
 * Description   : Start Het OS Service
 * Parameter     : none
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
extern
void  HOS_SrvStart(void);
/******************************************************************************/

/*
 * Function Name : HOS_RegisterEventCallback
 * Description   : Register Event Callback function, when keypoint event start,
 *                will call
 * Parameter     : func handle
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_RegisterEventCallback    OPP_RegisterEventCallback
/******************************************************************************/

/*
 * Function Name : HOS_RegisterRecvCallback
 * Description   : Register Recv Callback function, when Recv data frame from cloud,
 *                while the data to mcu
 * Parameter     : func handle
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_RegisterRecvCallback    OPP_RegisterRecvCallback
/******************************************************************************/

/*
 * Function Name : HOS_Write
 * Description   : Write To Vitral DS buffer
 * Parameter     : pbuf, Data Buffer
 *                len,Data Length
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_Write    OPP_Write
/******************************************************************************/

/*
 * Function Name : HOS_Connection_Config
 * Description   : dev bind to cloud, By config the router SSID & Key
 * Parameter     : type, default value is TYPE_SC_AP
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_Connection_Config    OPP_Connection_Config
/******************************************************************************/

/*
 * Function Name : HOS_BaseInfoConfig
 * Description   : Set the basic info from Develemper web(CTCC)
 * Parameter     : deviceID,distribution from CTCC
 *                pin,distribution from CTCC
 *                ctei,distribution from CTCC
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_BaseInfoConfig    OPP_BaseInfoConfig
/******************************************************************************/

/*
 * Function Name : HOS_ServerInfoConfig
 * Description   : Set the Login Service IP & Port, Default Don't use
 * Parameter     : ip, Login Service ip
 *                port,Login Service port
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_ServerInfoConfig    OPP_ServerInfoConfig
/******************************************************************************/

/*
 * Function Name : HOS_ModualInfoConfig
 * Description   : set device info
 * Parameter     : model, Device model name
 *                version, Device version
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_ModualInfoConfig(Ver)    OPP_ModualInfoConfig(NULL, Ver)
/******************************************************************************/

/*
 * Function Name : HOS_StatusReport
 * Description   : Report status to cloud, First Write To Vitral DS buffer
 * Parameter     : pbuf, Data Buffer
 *                len,Data Length
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_StatusReport(pbuf, len)    HOS_Write(EV_CM_PT_Status_Report, 0, pbuf, len)
/******************************************************************************/

/*
 * Function Name : HOS_ResourceReport
 * Description   : Report Resource Info To Cloud, First Write To Vitral DS buffer
 * Parameter     : pbuf, Data Buffer
 *                len,Data Length
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_ResourceReport(pbuf, len)    HOS_Write(EV_CM_PT_ResourceChange_Report, 0, pbuf, len)
/******************************************************************************/

/*
 * Function Name : HOS_EventInfoReport
 * Description   : Report Event Info To Cloud, First Write To Vitral DS buffer
 * Parameter     : pbuf, Data Buffer
 *                len,Data Length
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_EventInfoReport(pbuf, len)    HOS_Write(EV_CM_PT_EventInfo_Report, 0, pbuf, len)
/******************************************************************************/

/*
 * Function Name : HOS_StatusWarnReport
 * Description   : Report Status Warn Info To Cloud, First Write To Vitral DS buffer
 * Parameter     : pbuf, Data Buffer
 *                len,Data Length
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_StatusWarnReport(pbuf, len)    HOS_Write(EV_CM_PT_Status_Alarm_Req, 0, pbuf, len)
/******************************************************************************/

/*
 * Function Name : HOS_ErrorReport
 * Description   : Report Error Info To Cloud, First Write To Vitral DS buffer
 * Parameter     : pbuf, Data Buffer
 *                len,Data Length
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_ErrorReport(pbuf, len)    HOS_Write(EV_CM_PT_Fault_Feedback_Req, 0, pbuf, len)
/******************************************************************************/

/*
 * Function Name : HOS_GetTimeStamp
 * Description   : Get Current timestamp
 * Parameter     : none
 * Return value  : none
 *
 * Example       :
 */
/******************************************************************************/
#define HOS_GetTimeStamp    OPP_GetTimestamp
/******************************************************************************/

#endif

/******************************* End of File (H) ******************************/
