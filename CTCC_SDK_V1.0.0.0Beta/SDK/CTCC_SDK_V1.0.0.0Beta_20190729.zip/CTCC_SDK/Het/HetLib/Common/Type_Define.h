/******************************************************************************\
*  @Copyright (c/C++): 2016-2026, Bernie Liu
*  @File Name        : Type_Define.h
*  @Author           : Bernie Liu
*  @Version          : V00.00.01
*  @Date             : 2018-06-21
*  @Description      :
*
*  @Others           :
*
\******************************************************************************/

#ifndef _TYPE_CONGIF_H_
#define _TYPE_CONGIF_H_


/******************************************************************************\
*  @includes
\******************************************************************************/
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
/******************************************************************************\
*  @Definitions
\******************************************************************************/

/* NULL类型定义 */
#define V_NULL    ((void*)(0))
/* 判断是否为空 */
#define isNULL(p)    (V_NULL == p)

/* true false值定义 */
#define V_TRUE     (1)
#define V_FALSE    (0)

/* 时间秒，分，小时转换成对应秒的数值 */
#define TIME_SEC(t)      ((t))
#define TIME_MIN(t)      ((t) * 60)
#define TIME_HOUR(t)     ((t) * 3600)

/* 时间秒转换成秒，分，小时的数值 */
#define TIME_CSEC(t)     ((t))
#define TIME_CMIN(t)     ((t) / 60)
#define TIME_CHOUR(t)    ((t) / 3600)

/* 时间MS与S之间的转换 */
#define TMR_CS2MS(t)     ((t) * 1000)     // s->ms
#define TMR_CMS2S(t)     ((t) / 1000)     // ms->s

/* 最大值比较，a>b返回V_TRUE，反之返回V_FALSE */

#define H_MAX(a, b)    (((a) > (b)) ? V_TRUE : V_FALSE)


/* 计算数组元素个数 */
#define ARR_SIZE(ARR)    (sizeof(ARR) / sizeof(ARR[0]))

/* 位操作定义，左移N位 */
#define BLTS(N)          (1 << N)

/* 位操作定义，右移N位 */
#define BRTS(N)          (1 >> N)

/* 位操作定义，第N位置位 */
#define BSET(X, N)       (X) |= BLTS(N)

/* 位操作定义，第N位清空 */
#define BCLR(X, N)       (X) &= (~BLTS(N))

/* 位操作定义，第N位异或 */
#define BCPL(X, N)       (X) ^= BLTS(N)

/* 位操作定义，获取该位值 */
#define BTST(X, N)       ((X)&BLTS(N))

/* 数组与整型数据之间的转换 */
#define C2BYTES2HEX(pBuf) \
    (uint16_t)((*(pBuf) << 8) | *(pBuf + 1))

#define C3BYTES2HEX(pBuf) \
    (uint32_t)((*(pBuf) << 16) | (*(pBuf + 1) << 8) | *(pBuf + 2))

#define C4BYTES2HEX(pBuf) \
    (uint32_t)((*(pBuf) << 24) | (*(pBuf + 1) << 16) | (*(pBuf + 2) << 8) | *(pBuf + 3))

#define C16HEX2BYTES(pBuf, Data16)        \
    *(pBuf)     = (uint8_t)(Data16 >> 8); \
    *(pBuf + 1) = (uint8_t)(Data16)

#define C24HEX2BYTES(pBuf, Data24)         \
    *(pBuf)     = (uint8_t)(Data24 >> 16); \
    *(pBuf + 1) = (uint8_t)(Data24 >> 8);  \
    *(pBuf + 2) = (uint8_t)(Data24)

#define C32HEX2BYTES(pBuf, Data32)         \
    *(pBuf)     = (uint8_t)(Data32 >> 24); \
    *(pBuf + 1) = (uint8_t)(Data32 >> 16); \
    *(pBuf + 2) = (uint8_t)(Data32 >> 8);  \
    *(pBuf + 3) = (uint8_t)(Data32)

/* 联合体中使用的位定义，1字节，8位 */
typedef struct
{
    uint8_t B0 : 1;
    uint8_t B1 : 1;
    uint8_t B2 : 1;
    uint8_t B3 : 1;
    uint8_t B4 : 1;
    uint8_t B5 : 1;
    uint8_t B6 : 1;
    uint8_t B7 : 1;
}T_Uint8Bits;

/* 联合体中使用的位定义, 2字节，16位 */
typedef struct
{
    uint8_t B0  : 1;
    uint8_t B1  : 1;
    uint8_t B2  : 1;
    uint8_t B3  : 1;
    uint8_t B4  : 1;
    uint8_t B5  : 1;
    uint8_t B6  : 1;
    uint8_t B7  : 1;
    uint8_t B8  : 1;
    uint8_t B9  : 1;
    uint8_t B10 : 1;
    uint8_t B11 : 1;
    uint8_t B12 : 1;
    uint8_t B13 : 1;
    uint8_t B14 : 1;
    uint8_t B15 : 1;
}T_Uint16Bits;

/* 联合体中使用的位定义, 4字节，32位 */
typedef struct
{
    uint8_t B0  : 1;
    uint8_t B1  : 1;
    uint8_t B2  : 1;
    uint8_t B3  : 1;
    uint8_t B4  : 1;
    uint8_t B5  : 1;
    uint8_t B6  : 1;
    uint8_t B7  : 1;
    uint8_t B8  : 1;
    uint8_t B9  : 1;
    uint8_t B10 : 1;
    uint8_t B11 : 1;
    uint8_t B12 : 1;
    uint8_t B13 : 1;
    uint8_t B14 : 1;
    uint8_t B15 : 1;
    uint8_t B16 : 1;
    uint8_t B17 : 1;
    uint8_t B18 : 1;
    uint8_t B19 : 1;
    uint8_t B20 : 1;
    uint8_t B21 : 1;
    uint8_t B22 : 1;
    uint8_t B23 : 1;
    uint8_t B24 : 1;
    uint8_t B25 : 1;
    uint8_t B26 : 1;
    uint8_t B27 : 1;
    uint8_t B28 : 1;
    uint8_t B29 : 1;
    uint8_t B30 : 1;
    uint8_t B31 : 1;
}T_Uint32Bits;

/* 联合体位类型定义，1字节 */
typedef union
{
    T_Uint8Bits Bits;
    uint8_t     V8;
}U_BYTE;

/* 联合体位类型定义，2字节 */
typedef union
{
    T_Uint16Bits Bits;
    uint8_t      V8[2];
    uint16_t     V16;
}U_WORD;

/* 联合体位类型定义，4字节 */
typedef union
{
    T_Uint32Bits Bits;
    uint8_t      V8[4];
    uint16_t     V16[2];
    uint32_t     V32;
}U_DEWORD;

/* 0~31 bit位定义 */
#define H_BIT0     (1 << 0)
#define H_BIT1     (1 << 1)
#define H_BIT2     (1 << 2)
#define H_BIT3     (1 << 3)
#define H_BIT4     (1 << 4)
#define H_BIT5     (1 << 5)
#define H_BIT6     (1 << 6)
#define H_BIT7     (1 << 7)
#define H_BIT8     (1 << 8)
#define H_BIT9     (1 << 9)
#define H_BIT10    (1 << 10)
#define H_BIT11    (1 << 11)
#define H_BIT12    (1 << 12)
#define H_BIT13    (1 << 13)
#define H_BIT14    (1 << 14)
#define H_BIT15    (1 << 15)
#define H_BIT16    (1 << 16)
#define H_BIT17    (1 << 17)
#define H_BIT18    (1 << 18)
#define H_BIT19    (1 << 19)
#define H_BIT20    (1 << 20)
#define H_BIT21    (1 << 21)
#define H_BIT22    (1 << 22)
#define H_BIT23    (1 << 23)
#define H_BIT24    (1 << 24)
#define H_BIT25    (1 << 25)
#define H_BIT26    (1 << 26)
#define H_BIT27    (1 << 27)
#define H_BIT28    (1 << 28)
#define H_BIT29    (1 << 29)
#define H_BIT30    (1 << 30)
#define H_BIT31    (1 << 31)


#endif

/******************************* End of File (H) ******************************/

