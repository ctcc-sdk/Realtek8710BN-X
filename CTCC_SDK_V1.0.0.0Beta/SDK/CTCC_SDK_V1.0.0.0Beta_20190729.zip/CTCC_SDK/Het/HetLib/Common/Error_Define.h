/******************************************************************************
 * Copyright 2019 HET Corporation
 * FileName          ： Error_Define.h
 * FileIdentication  ：
 * DESCRIPTION       ：For all error code definition
 * Others            ：
 * Version           ： 1.0
 * Author            ： T.Liu
 * Date              ： 2019-5-14 10:00
 *
 *******************************************************************************/
#ifndef _ERROR_DEFINE_H_
#define _ERROR_DEFINE_H_

/******************************************************************************
 *                        Include file                                    *
 *****************************************************************************/

/******************************************************************************
 *                        Macro Definitions                               *
 *****************************************************************************/

/* Return Code Define */
#define E_OK                0       /* No Error */
#define E_FAIL              1       /* Operation not permitted */
#define E_PERM              E_FAIL  /* Operation not permitted */
#define E_NOENT             2       /* No such file or directory */
#define E_SRCH              3       /* No such process */
#define E_INTR              4       /* Interrupted system call */
#define E_IO                5       /* I/O error */
#define E_NXIO              6       /* No such device or address */
#define E_2BIG              7       /* Argument list too long */
#define E_NOEXEC            8       /* Exec format error */
#define E_BADF              9       /* Bad file number */
#define E_CHILD             10      /* No child processes */
#define E_AGAIN             11      /* Try again */
#define E_NOMEM             12      /* Out of memory */
#define E_ACCES             13      /* Permission denied */
#define E_FAULT             14      /* Bad address */
#define E_NOTBLK            15      /* Block device required */
#define E_BUSY              16      /* Device or resource busy */
#define E_EXIST             17      /* File exists */
#define E_XDEV              18      /* Cross-device link */
#define E_NODEV             19      /* No such device */
#define E_NOTDIR            20      /* Not a directory */
#define E_ISDIR             21      /* Is a directory */
#define E_INVAL             22      /* Invalid argument */
#define E_NFILE             23      /* File table overflow */
#define E_MFILE             24      /* Too many open files */
#define E_NOTTY             25      /* Not a typewriter */
#define E_TXTBSY            26      /* Text file busy */
#define E_FBIG              27      /* File too large */
#define E_NOSPC             28      /* No space left on device */
#define E_SPIPE             29      /* Illegal seek */
#define E_ROFS              30      /* Read-only file system */
#define E_MLINK             31      /* Too many links */
#define E_PIPE              32      /* Broken pipe */
#define E_DOM               33      /* Math argument out of domain of func */
#define E_RANGE             34      /* Math result not representable */
#define E_DEADLK            35      /* Resource deadlock would occur */
#define E_NAMETOOLONG       36      /* File name too long */
#define E_NOLCK             37      /* No record locks available */
#define E_NOSYS             38      /* Function not implemented */
#define E_NOTEMPTY          39      /* Directory not empty */
#define E_LOOP              40      /* Too many symbolic links encountered */
#define E_WOULDBLOCK        E_AGAIN /* Operation would block */
#define E_NOMSG             42      /* No message of desired type */
#define E_IDRM              43      /* Identifier removed */
#define E_CHRNG             44      /* Channel number out of range */
#define E_L2NSYNC           45      /* Level 2 not synchronized */
#define E_L3HLT             46      /* Level 3 halted */
#define E_L3RST             47      /* Level 3 reset */
#define E_LNRNG             48      /* Link number out of range */
#define E_UNATCH            49      /* Protocol driver not attached */
#define E_NOCSI             50      /* No CSI structure available */
#define E_L2HLT             51      /* Level 2 halted */
#define E_BADE              52      /* Invalid exchange */
#define E_BADR              53      /* Invalid request descriptor */
#define E_XFULL             54      /* Exchange full */
#define E_NOANO             55      /* No anode */
#define E_BADRQC            56      /* Invalid request code */
#define E_BADSLT            57      /* Invalid slot */

#define E_DEADLOCK          E_DEADLK
#define E_BFONT             59  /* Bad font file format */
#define E_NOSTR             60  /* Device not a stream */
#define E_NODATA            61  /* No data available */
#define E_TIME              62  /* Timer expired */
#define E_NOSR              63  /* Out of streams resources */
#define E_NONET             64  /* Machine is not on the network */
#define E_NOPKG             65  /* Package not installed */
#define E_REMOTE            66  /* Object is remote */
#define E_NOLINK            67  /* Link has been severed */
#define E_ADV               68  /* Advertise error */
#define E_SRMNT             69  /* Srmount error */
#define E_COMM              70  /* Communication error on send */
#define E_PROTO             71  /* Protocol error */
#define E_MULTIHOP          72  /* Multihop attempted */
#define E_DOTDOT            73  /* RFS specific error */
#define E_BADMSG            74  /* Not a data message */
#define E_OVERFLOW          75  /* Value too large for defined data type */
#define E_NOTUNIQ           76  /* Name not unique on network */
#define E_BADFD             77  /* File descriptor in bad state */
#define E_REMCHG            78  /* Remote address changed */
#define E_LIBACC            79  /* Can not access a needed shared library */
#define E_LIBBAD            80  /* Accessing a corrupted shared library */
#define E_LIBSCN            81  /* .lib section in a.out corrupted */
#define E_LIBMAX            82  /* Attempting to link in too many shared libraries */
#define E_LIBEXEC           83  /* Cannot exec a shared library directly */
#define E_ILSEQ             84  /* Illegal byte sequence */
#define E_RESTART           85  /* Interrupted system call should be restarted */
#define E_STRPIPE           86  /* Streams pipe error */
#define E_USERS             87  /* Too many users */
#define E_NOTSOCK           88  /* Socket operation on non-socket */
#define E_DESTADDRREQ       89  /* Destination address required */
#define E_MSGSIZE           90  /* Message too long */
#define E_PROTOTYPE         91  /* Protocol wrong type for socket */
#define E_NOPROTOOPT        92  /* Protocol not available */
#define E_PROTONOSUPPORT    93  /* Protocol not supported */
#define E_SOCKTNOSUPPORT    94  /* Socket type not supported */
#define E_OPNOTSUPP         95  /* Operation not supported on transport endpoint */
#define E_PFNOSUPPORT       96  /* Protocol family not supported */
#define E_AFNOSUPPORT       97  /* Address family not supported by protocol */
#define E_ADDRINUSE         98  /* Address already in use */
#define E_ADDRNOTAVAIL      99  /* Cannot assign requested address */
#define E_NETDOWN           100 /* Network is down */
#define E_NETUNREACH        101 /* Network is unreachable */
#define E_NETRESET          102 /* Network dropped connection because of reset */
#define E_CONNABORTED       103 /* Software caused connection abort */
#define E_CONNRESET         104 /* Connection reset by peer */
#define E_NOBUFS            105 /* No buffer space available */
#define E_ISCONN            106 /* Transport endpoint is already connected */
#define E_NOTCONN           107 /* Transport endpoint is not connected */
#define E_SHUTDOWN          108 /* Cannot send after transport endpoint shutdown */
#define E_TOOMANYREFS       109 /* Too many references: cannot splice */
#define E_TIMEDOUT          110 /* Connection timed out */
#define E_CONNREFUSED       111 /* Connection refused */
#define E_HOSTDOWN          112 /* Host is down */
#define E_HOSTUNREACH       113 /* No route to host */
#define E_ALREADY           114 /* Operation already in progress */
#define E_INPROGRESS        115 /* Operation now in progress */
#define E_STALE             116 /* Stale NFS file handle */
#define E_UCLEAN            117 /* Structure needs cleaning */
#define E_NOTNAM            118 /* Not a XENIX named type file */
#define E_NAVAIL            119 /* No XENIX semaphores available */
#define E_ISNAM             120 /* Is a named type file */
#define E_REMOTEIO          121 /* Remote I/O error */
#define E_DQUOT             122 /* Quota exceeded */
#define E_NOMEDIUM          123 /* No medium found */
#define E_MEDIUMTYPE        124 /* Wrong medium type */

extern int unix_errno;          /* must define in a source file */

#define SET_ERRNO(err)    unix_errno = (err) > 0 ? (err) : (-(err))
#define GET_ERRNO()       unix_errno
#define RETURN(r)         do { SET_ERRNO(r); return (-unix_errno); } while (0)

#endif

