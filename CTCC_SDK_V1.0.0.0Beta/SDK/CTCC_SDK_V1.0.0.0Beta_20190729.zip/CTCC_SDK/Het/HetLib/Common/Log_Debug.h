/******************************************************************************\
**  版     权  ： 深圳市和而泰智能控制股份有限公司所有（2020）
**  文 件 名    :  Log_Debug.h
**  功能描述 :      用于打印信息处理
**  作     者  :  Bernie Liu
**  日     期  :  2018.01.01
**  版     本  ： V0.0.1
**  变更记录 :
**           V0.0.1/2018.07.25
**           1 首次创建
\******************************************************************************/

#ifndef _LOG_DEBUG_H_
#define _LOG_DEBUG_H_

/******************************************************************************\
*                            Includes
\******************************************************************************/
#include <stdio.h>
#include "../HAL/NET/HAL_OS.h"
/******************************************************************************\
*                         Macro definitions
\******************************************************************************/

#define _DBG                                 printf
#define _DBG_POS()                           LOGD("%s: %d\n", __FUNCTION__, __LINE__); //os_printf("%s: %d\n", __FUNCTION__, __LINE__);

#define DBG_LOCK()                           do { if (HAL_OS_IsSchedulerStart()) { HAL_OS_BlockSemaphoreTake(&s_LogDbgSemaphore); } } while (0)
#define DBG_UNLOCK()                         do { if (HAL_OS_IsSchedulerStart()) { HAL_OS_BlockSemaphoreGive(s_LogDbgSemaphore); } } while (0)

#define LOGD(format, ...)                    do { if (HAL_OS_IsSchedulerStart()) { HAL_OS_BlockSemaphoreTake(&s_LogDbgSemaphore); } \
                                                  _DBG(format, ## __VA_ARGS__); if (HAL_OS_IsSchedulerStart()) { HAL_OS_BlockSemaphoreGive(s_LogDbgSemaphore); } } while (0)

#define DBG_HEADER(head_Str, format, ...)    do { const char *str = format; if (str[0] == '\n') { LOGD("\n"); str++; } LOGD("[%s] ", head_Str); LOGD(str, ## __VA_ARGS__); } while (0)

#define RESULT_STRING(r)                     (r) ? "sucess." : "failed!"

#define DBG_FUNC(str)                        LOGD("%s %s\n", __FUNCTION__, str)

#define DBG_MALLOC_ERR()                     LOGD("[malloc] Error at line %d in func %s!!!\r\n", __LINE__, __FUNCTION__)

#define DBG_HEAP_SIZE()                      LOGD("\n\r%s(%d), [init_thread]Available heap 0x%x\r\n", __FUNCTION__, __LINE__, xPortGetFreeHeapSize())

#define NORMAL_PRINT                (uint16_t)1

#define PRINT_LEVEL_CLOSE_ALL       (uint8_t)0
#define PRINT_LEVEL_LOW             (uint8_t)1
#define PRINT_LEVEL_NORMAL          (uint8_t)2
#define PRINT_LEVEL_HIGH            (uint8_t)3
#define PRINT_LEVEL_HIGHEST         (uint8_t)4
#define PRINT_LEVEL_CRITICAL        (uint8_t)5
#define PRINT_LEVEL_OPEN_ALL        (uint8_t)0xFF


#define PRINT_DESTINATION_UART      (uint8_t)1
#define PRINT_DESTINATION_SERVER    (uint8_t)2
#define PRINT_DESTINATION_FLASH     (uint8_t)4
#define PRINT_DESTINATION_UDP       (uint8_t)8


//---------- Print Module define begin ----------------------------------------------//
#define     PRINT_CMO_BEGIN_OPP                       (uint16_t)0 // CMO: Communication Module
#define     PRINT_CMO_BEGIN_OPP_NAME                  "OPP"
#define     PRINT_CMO_FIRST_MODULE                    (uint16_t)(PRINT_CMO_BEGIN_OPP + 1)

#define     PRINT_CMO_COMMOM                          (uint16_t)(PRINT_CMO_BEGIN_OPP + 1)
#define     PRINT_CMO_COMMOM_NAME                     "PRINT_CMO_COMMOM"
#define     PRINT_CMO_HAL                             (uint16_t)(PRINT_CMO_BEGIN_OPP + 2)
#define     PRINT_CMO_HAL_NAME                        "HAL"
#define     PRINT_CMO_PROTOCOL_COM                    (uint16_t)(PRINT_CMO_BEGIN_OPP + 3)
#define     PRINT_CMO_PROTOCOL_COM_NAME               "COM"
#define     PRINT_CMO_PROTOCOL_NET                    (uint16_t)(PRINT_CMO_BEGIN_OPP + 4)
#define     PRINT_CMO_PROTOCOL_NET_NAME               "NET"
#define     PRINT_CMO_PROTOCOL_OTA                    (uint16_t)(PRINT_CMO_BEGIN_OPP + 5)
#define     PRINT_CMO_PROTOCOL_OTA_NAME               "OTA"
#define     PRINT_CMO_PROTOCOL_FCT                    (uint16_t)(PRINT_CMO_BEGIN_OPP + 6)
#define     PRINT_CMO_PROTOCOL_FCT_NAME               "FCT"
#define     PRINT_CMO_PROTOCOL_PROFILE                (uint16_t)(PRINT_CMO_BEGIN_OPP + 7)
#define     PRINT_CMO_PROTOCOL_PROFILE_NAME           "PROFILE"
#define     PRINT_CMO_PROTOCOL_COMMON                 (uint16_t)(PRINT_CMO_BEGIN_OPP + 8)
#define     PRINT_CMO_PROTOCOL_COMMON_NAME            "COMMON"
#define     PRINT_CMO_PROTOCOL_CONNECTION             (uint16_t)(PRINT_CMO_BEGIN_OPP + 9)
#define     PRINT_CMO_PROTOCOL_CONNECTION_NAME        "CONNECTION"
#define     PRINT_CMO_PROTOCOL_SERVICE_ACTIVE         (uint16_t)(PRINT_CMO_BEGIN_OPP + 10)
#define     PRINT_CMO_PROTOCOL_SERVICE_ACTIVE_NAME    "SERVICE_ACTIVE"
#define     PRINT_CMO_PROTOCOL_MANAGER                (uint16_t)(PRINT_CMO_BEGIN_OPP + 11)
#define     PRINT_CMO_PROTOCOL_MANAGER_NAME           "MANAGER"


#define     PRINT_CMO_LAST_MODULE                     (uint16_t)(PRINT_CMO_BEGIN_OPP + 11)
#define     PRINT_CMO_MODULE_END                      (uint16_t)(PRINT_CMO_LAST_MODULE + 1)
#define     PRINT_CMO_MODULE_END_NAME                 "END"


//---------- Print Module define end -----------------------------------------------//


#define MAX_PRINT_CHAR_LENGTH    (uint8_t)(200)

/******************************************************************************\
*                        Typedef definitions
\******************************************************************************/

typedef struct tagSYS_CLOCK
{
    uint16_t wSysYear;  /* 年 */
    uint8_t  ucSysMon;  /* 月 */
    uint8_t  ucSysDay;  /* 日 */

    uint8_t  ucSysHour; /* 时 */
    uint8_t  ucPading0; /* 填充字*/
    uint8_t  ucSysMin;  /* 分 */
    uint8_t  ucSysSec;  /* 秒 */

    uint16_t wMilliSec; /* 毫秒 */
    uint8_t  ucSysWeek; /* 周 */
    uint8_t  ucPading1; /* 填充字*/
}T_SysSoftClock;        /* 系统软时钟结构，表示绝对时间 */



/*
 *  缩写释义：DBG--->Debug
 *            M----->Module
 *            PROC-->Process
 *            DB---->DataBase
 *            PM---->Process Managerment
 *            PT---->Product Test
 *            SPEC-->Special
 */
typedef enum
{
    LOG_M_SYS = 0x0, /* 系统相关/打印 */
    LOG_M_EVENT,     /* 事件日志/打印 */
    LOG_M_DB_COM,    /* COM端数据处理日志/打印 */
    LOG_M_DB_NET,    /* NET端数据处理日志/打印 */
    LOG_M_PM_BIND,   /* 绑定日志/打印 */
    LOG_M_PM_NORMAL, /* 正常流程日志/打印 */
    LOG_M_PM_PT,     /* 产测流程日志/打印 */
    LOG_M_PM_SPEC,   /* 其他特殊功能流程日志/打印 */
    LOG_M_MAX
}TE_LOG_Module;

typedef enum
{
    LOG_LEV_ERR = 0x0,  /* 日志等级：错误 */
    LOG_LEV_WARN,       /* 日志等级：告警 */
    LOG_LEV_INFO,       /* 日志等级：关键信息 */
    LOG_LEV_DEBUG,      /* 日志等级：调试信息，release版本需要关闭 */
    LOG_LEV_MAX
}TE_LOG_Level;

#define LOG_ALL_ON     (0xFF)
#define LOG_ALL_OFF    (0x0)

/******************************************************************************\
*                   Global variables and functions
\******************************************************************************/
extern void *s_LogDbgSemaphore;

/*
 * 函数名称 : LOG_LevSWOn
 * 功能描述 : 打开打印对象
 * 参     数 : 无;
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
void  LOG_LevSWOn(TE_LOG_Level LogLev);
/******************************************************************************/

/*
 * 函数名称 : LOG_LevSWOff
 * 功能描述 : 打开打印对象
 * 参     数 : 无;
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
void  LOG_LevSWOff(TE_LOG_Level LogLev);
/******************************************************************************/

/*
 * 函数名称 : LOG_IsLevSWOn
 * 功能描述 : 打开打印对象
 * 参     数 : 无;
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
uint8_t  LOG_IsLevSWOn(TE_LOG_Level LogLev);
/******************************************************************************/

/*
 * 函数名称 : LOG_PRINTF_RAW
 * 功能描述 : 打开打印对象
 * 参     数 : 无;
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
void  LOG_DBG_RAW(const char *str,
                  uint8_t *pHexBuf, uint16_t Len);
/******************************************************************************/

/*
 * 函数名称 : LOG_DBG_PRINTF
 * 功能描述 : 打开打印对象
 * 参     数 : 无;
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
void  LOG_DBG_PRINTF(const char *fmt, ...);
/******************************************************************************/

/*
 * 函数名称 : LOG_PRINTF
 * 功能描述 : 日志打印
 * 参     数 : 无;
 * 返 回 值 : 无
 * 示     例 ：
 */
/******************************************************************************/
extern
void  LogPrintf(TE_LOG_Module Module, TE_LOG_Level LogLev,
                int ErrCode,
                const char *fmt, ...);
/******************************************************************************/


/*
 * 函数名称 : LOG_Open
 * 功能描述 : 打开打印对象
 * 参	   数 : 无;
 * 返 回 值 : 无
 * 示	   例 ：
 */
/******************************************************************************/
extern
void  LOG_Open(void);
/******************************************************************************/



/******************************************************************************
* Function:		CMOPrint
* Description:
* Input:
*		 wModuleName:
*           #define     PRINT_CMO_COMMOM                        (uint16_t)(PRINT_CMO_BEGIN_OPP+1)
*           #define     PRINT_CMO_HAL                           (uint16_t)(PRINT_CMO_BEGIN_OPP+2)
*           #define     PRINT_CMO_PROTOCOL_COM                  (uint16_t)(PRINT_CMO_BEGIN_OPP+3)
*           #define     PRINT_CMO_PROTOCOL_NET                  (uint16_t)(PRINT_CMO_BEGIN_OPP+4)
*           #define     PRINT_CMO_PROTOCOL_OTA                  (uint16_t)(PRINT_CMO_BEGIN_OPP+5)
*           #define     PRINT_CMO_PROTOCOL_FCT                  (uint16_t)(PRINT_CMO_BEGIN_OPP+6)
*           #define     PRINT_CMO_PROTOCOL_PROFILE              (uint16_t)(PRINT_CMO_BEGIN_OPP+7)
*           #define     PRINT_CMO_PROTOCOL_COMMON               (uint16_t)(PRINT_CMO_BEGIN_OPP+8)
*           #define     PRINT_CMO_PROTOCOL_CONNECTION           (uint16_t)(PRINT_CMO_BEGIN_OPP+9)
*           #define     PRINT_CMO_PROTOCOL_SERVICE_ACTIVE       (uint16_t)(PRINT_CMO_BEGIN_OPP+10)
*           #define     PRINT_CMO_PROTOCOL_MANAGER              (uint16_t)(PRINT_CMO_BEGIN_OPP+11)
*
*		BYTE  ucPrnCtrlLevel 使用方法如下：
*           #define PRINT_LEVEL_LOW                   (uint8_t)1
*           #define PRINT_LEVEL_NORMAL                (uint8_t)2
*           #define PRINT_LEVEL_HIGH                  (uint8_t)3
*           #define PRINT_LEVEL_HIGHEST               (uint8_t)4
*           #define PRINT_LEVEL_CRITICAL              (uint8_t)5
*
*		WORD32 dwPrintCtrlPara使用方法如下：
*			 #define PRN_NORMAL                      (WORD32)0x0	  正常打印
*			 #define PRN_ERROR						 (WORD32)0x10000  错误打印
*			 当要打印业务信道建立流程和空中接口消息时， dwPrintCtrlPara使用方法是：
*										  传入实际的参数，如：ATI，信号名，空中接口消息
* Output:	 None.
* Return:	 VOID
* Others:
* Modify Date		   Author  Modification:
* -----------------------------------------------
* 2019-05-20 15:15    T.Liu	First edition
******************************************************************************/


void    OPP_Print(uint16_t wModuleIndex, uint16_t wErrorCode, uint8_t ucPrintCtrlLevel,
                  const char *pcFormat, ...);


/******************************************************************************
* Function:         GetSystemTimeStamp
* Description:		GetSystemTimeStamp
* Input:
* Output:	None.
* Return:	VOID
* Others:
* Modify Date		 Author  Modification:
* -----------------------------------------------
* 2019-05-20 17:14	 T.Liu	 First edition
******************************************************************************/
extern void GetSystemTimeStamp(char *auData);


#endif

/******************************* End of File (H) ******************************/

