/*
 *
 *
 * Copyright (2018)
 */

#ifndef __HET_STDLIBC_H__
#define __HET_STDLIBC_H__

#ifdef __cplusplus
extern "C" {
#endif
#include "Type_Define.h"
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdbool.h>

#ifndef false
#define false    0
#endif

#ifndef true
#define true    1
#endif

/* lib function */
/******************
 * //atoi (表示 ascii to integer)是
 * 把字符串转换成整型数的一个函数
 *
 *******************/
extern int std_atoi(const char *str);
extern float std_atof(const char *str);
size_t strcspn(const char *str1, const char *str2);


#define het_malloc(size)                 malloc(size)
#define het_calloc(n, s)                 calloc(n, s)
//#define het_realloc(ptr, size)      os_realloc(ptr, size)
#define het_free(ptr)                    free(ptr)


#define het_memset(src, c, n)            memset(src, c, n)
#define het_memcpy(dest, src, n)         memcpy(dest, src, n)
#define het_memmove(dest, src, n)        memmove(dest, src, n)
#define het_memcmp(dest, src, n)         memcmp(dest, src, n)
#define het_strlen(str)                  strlen(str)
#define het_strcpy(dest, src)            strcpy(dest, src)
#define het_strncpy(dest, src, n)        strncpy(dest, src, n)
#define het_strstr(pstr, str)            strstr(pstr, str)
#define het_strchr(pstr, c)              strchr(pstr, c)
#define het_strcmp(d, s)                 strcmp(d, s)
#define het_strncmp(d, s, n)             strncmp(d, s, n)
#define het_strcspn(s, d)                strcspn(s, d)
//#define het_strcspn(s,d)            strcspn(s,d)
#define het_sprintf(buf, format, ...)    sprintf(buf, format, ## __VA_ARGS__)


#include "Error_Define.h"
#include "Log_Debug.h"


#define ARRAY_SIZE(array)    (sizeof(array) / sizeof(array[0]))

#ifdef __cplusplus
}
#endif

#endif /* __HET_STDLIBC_H__ */


