#ifndef __MD5_H__
#define __MD5_H__

#ifdef __cplusplus
extern "C" {
#endif

void  md5(const unsigned char *src,
          unsigned int src_len, unsigned char *result);


#ifdef __cplusplus
}
#endif

#endif /* __MD5_H__ */


