/****************************************************************************
****************************************************************************/
#ifndef _USER_AES_CBC_COM_H_
#define _USER_AES_CBC_COM_H_

#include "../../../stdlibc.h"

#ifdef TEAT_AES_CBC
void test_aes_cbc_console(void);
#endif

int Base64_required_len(int len);

void AESCBCDecode(unsigned char *cipher, unsigned int *cipherlen,
                  unsigned char *key, unsigned int keylen,
                  unsigned char *iv);

void AESEncode_base64(unsigned char *plain, unsigned int *plainlen,
                      unsigned char *key, unsigned int keylen, unsigned char *iv);
void AESDecode_base64(unsigned char *cipher, unsigned int *cipherlen,
                      unsigned char *key, unsigned int keylen, unsigned char *iv);



#endif

