/*
 *
 *
 * Copyright (2019) chenw
 */

#ifndef _HET_CRC_H__
#define _HET_CRC_H__

#ifdef __cplusplus
extern "C" {
#endif
#include "stdlibc.h"

#define CRC16_POLY    0x8408
#define CRC8_POLY     0x8e

unsigned short  getCRC16(void *pbuf, int len);
unsigned char  getCRC8(void *pbuf, int len);


#ifdef __cplusplus
}
#endif

#endif /* _HET_CRC_H__ */

