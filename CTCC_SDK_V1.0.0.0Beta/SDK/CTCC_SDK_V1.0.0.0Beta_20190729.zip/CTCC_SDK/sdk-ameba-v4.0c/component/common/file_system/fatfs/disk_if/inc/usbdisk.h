#ifndef _USBDISK_H_
#define _USBDISK_H_

#include "fatfs_ext/inc/ff_driver.h"

extern ll_diskio_drv USB_disk_Driver;
#endif

