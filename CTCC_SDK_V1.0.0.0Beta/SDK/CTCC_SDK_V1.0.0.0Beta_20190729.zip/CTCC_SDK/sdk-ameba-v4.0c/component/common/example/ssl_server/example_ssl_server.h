#ifndef EXAMPLE_SSL_SERVER_H
#define EXAMPLE_SSL_SERVER_H

void example_ssl_server(void);

#endif /* EXAMPLE_SSL_SERVER_H */
