#ifndef EXAMPLE_MEDIA_AUDIO_FROM_RTP_H
#define EXAMPLE_MEDIA_AUDIO_FROM_RTP_H
#include <platform/platform_stdlib.h>
#include "platform_opts.h"
#include "osdep_api.h"

void example_media_geo_rtp(void);
#endif