#ifndef EXAMPLE_MDNS_H
#define EXAMPLE_MDNS_H

void example_mdns(void);

#endif /* EXAMPLE_MDNS_H */
