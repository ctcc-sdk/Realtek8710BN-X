#ifndef EXAMPLE_WLAN_SCENARIO_H
#define EXAMPLE_WLAN_SCENARIO_H

#include <platform/platform_stdlib.h>
#include "platform_opts.h"

void example_wlan_scenario(char* id);

#endif
