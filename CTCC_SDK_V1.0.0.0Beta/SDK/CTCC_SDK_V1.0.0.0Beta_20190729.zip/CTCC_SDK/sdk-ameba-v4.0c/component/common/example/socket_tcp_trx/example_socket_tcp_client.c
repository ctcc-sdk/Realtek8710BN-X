#define     _SOCKET_TEST1_
#ifdef      _SOCKET_TEST1_

#include <platform/platform_stdlib.h>
#include <platform_opts.h>
#include <stdio.h>
#include "osdep_service.h"
#include "lwip/ip_addr.h"
#include "main.h"
#include "FreeRTOS.h"
#include "task.h"

#include <lwip/sockets.h>
//#include <osdep_api.h>
#include <osdep_service.h>
#include"wifi_constants.h"
#include <lwip_netconf.h>
#include "Net_HAL.h"


//typedef signed char S8;
//typedef signed short S16;
//typedef signed long  S32;

//typedef unsigned char  U8, UINT8, uint8;
//typedef unsigned short U16, UINT16, uint16;
//typedef unsigned long  U32, UINT32, uint32;
#define BZERO(s, n)         memset(s, 0, n)

/** 255.255.255.255 */
#define INADDR_NONE         IPADDR_NONE
/** 127.0.0.1 */
#define INADDR_LOOPBACK     IPADDR_LOOPBACK
/** 0.0.0.0 */
#define INADDR_ANY          IPADDR_ANY
/** 255.255.255.255 */
#define INADDR_BROADCAST    IPADDR_BROADCAST


#define SERVER_PORT     18899
#define LISTEN_QLEN     2


#define PRODUCTION_SSID                "het-test-wifi"
#define PRODUCTION_SSID_KEY            "12345678"
#define PRODUCTION_KEY_TYPE            RTW_SECURITY_WPA2_AES_PSK
#define PRODUCTION_IP                  (0xC0A80A64)
#define SERVER_IP                      "192.168.10.186"
#define PRODUCTION_PORT                (8080)
#define SERVER_PORT                    (18899)

#define DEFAULT_IDENTIFY_SSID          "HET_000106_579C"
#define DEFAULT_IDENTIFY_SSID_KEY      0
#define DEFAULT_IDENTIFY_KEY_TYPE      RTW_SECURITY_OPEN



static void example_socket_trx_thread3(void *param)
{
    char recv_buffer[1024]={0};
	int ret=0,timeout=20,server_fd = -1, client_fd = -1;
	struct sockaddr_in server_addr, cli_addr;
	size_t cli_addr_size;
#if CONFIG_LWIP_LAYER 
        struct ip_addr ipaddr;
        struct ip_addr netmask;
        struct ip_addr gw;
        struct netif * pnetif = &xnetif[0];
#endif
#if 0   //AP MODE 
    vTaskDelay(5000);
	// Delay to wait for IP by DHCP
#if CONFIG_LWIP_LAYER
	printf("************\r\n");
	dhcps_deinit();
	IP4_ADDR(&ipaddr, GW_ADDR0, GW_ADDR1, 43, GW_ADDR3);
	IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1 , NETMASK_ADDR2, NETMASK_ADDR3);
	IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
	netif_set_addr(pnetif, &ipaddr, &netmask,&gw);
#endif
	wifi_off();
	vTaskDelay(20);
    if (wifi_on(RTW_MODE_AP) < 0){
		printf("\n\rERROR: Wifi on failed!");
		ret = RTW_ERROR;
		exit(1);
	}
    vTaskDelay(2000);
	if(wifi_start_ap(DEFAULT_IDENTIFY_SSID,DEFAULT_IDENTIFY_KEY_TYPE,\
     0, strlen(DEFAULT_IDENTIFY_SSID), \
     0, 1)<0)
	{
        printf("\n\rERROR: Operation failed!");
		exit(1);
     }
    //wpas_wps_dev_config(pnetif->hwaddr, 1);
     dhcps_init(&xnetif[0]);
    while(1)
    {
		char essid[33];
		if(wext_get_ssid(WLAN0_NAME, (unsigned char *) essid) > 0) 
        {
			if(strcmp((const char *) essid, (const char *)DEFAULT_IDENTIFY_SSID) == 0)
            {
				printf(DEFAULT_IDENTIFY_SSID);
				ret = 0;
				break;
			}
		}
		if(timeout == 0) {
			printf("Start AP timeout!\n\r");
			ret = -1;
			break;
		}
		vTaskDelay(1 * configTICK_RATE_HZ);
		timeout --;
	}
#else //STA MODE
///*
     vTaskDelay(1000);
     // Delay to wait for IP by DHCP
     wifi_off();
     vTaskDelay(20);
     wifi_on(RTW_MODE_STA);
     vTaskDelay(2000);
     ret=wifi_connect(PRODUCTION_SSID, PRODUCTION_KEY_TYPE, \
      PRODUCTION_SSID_KEY, strlen(PRODUCTION_SSID), \
      strlen(PRODUCTION_SSID_KEY), 0, NULL);
     if(ret == RTW_SUCCESS){
             LwIP_DHCP(0, DHCP_START);
         }
//*/     
   // Net_HAL_ConnectRouter(PRODUCTION_SSID, PRODUCTION_SSID_KEY, PRODUCTION_KEY_TYPE);
    vTaskDelay(1000);

#endif
#define dataserver_addr "192.168.10.186"//"119.29.9.233"//
#define  SERVER_TEST 0
#define  CLIENT_TEST 1
#if SERVER_TEST
#if 1  //test OPEN  udp server Net_HAL.CPP  
    vTaskDelay(1000);
	printf("\r\nExample: socket tx/rx 1\r\n");
    if(Network_Wifi_OpenUdpServer1(inet_addr(SERVER_IP))==0)
    //if(Net_HAL_OpenServer(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT))==0)
    {
        perror("\r\nopenclint failed");
    }
    char mac_buff[10]={0};
    u8 buf[5]={0x5a,0x10,0x11,0x12,0x00};
    unsigned char *ip=NULL;
    while(1)
    {
        if(Net_HAL_Read(NET_ID_UDP, recv_buffer,sizeof(recv_buffer))>0)
        {
            Net_HAL_Write(NET_ID_UDP, "SERVER SEND..", 13);
            printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
            
        }
        Net_HAL_Write(NET_ID_UDP, buf, 5);
        
        Net_HAL_GetIP();
        wifi_get_mac_address(mac_buff);
        vTaskDelay(2000);
        printf("\r\ngoon...%s",mac_buff);
    }
#else  //本文件
    vTaskDelay(1000);
	printf("\r\nExample: socket tx/rx 1\r\n");
    //Network_Wifi_OpenUdpServer(inet_addr(SERVER_IP));
    //Net_HAL_OpenServer1(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT));
    if(Net_HAL_OpenServer1(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT))==0)
    {
        perror("\r\nopenclint failed");
    }
    char mac_buff[10]={0};
    u8 buf[5]={0x5a,0x10,0x11,0x12,0x00};
    while(1)
    {
        if(Net_HAL_Read1(NET_ID_UDP, recv_buffer,sizeof(recv_buffer))>0)
        {
            Net_HAL_Write1(NET_ID_UDP, "SERVER SEND..", 13);
            printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
            
        }
        Net_HAL_Write1(NET_ID_UDP, buf, 5);
        
        Net_HAL_GetIP();
        wifi_get_mac_address(mac_buff);
        vTaskDelay(2000);
        printf("\r\ngoon...%s",mac_buff);
    }
        

#endif
#endif   

#if CLIENT_TEST
#if 0  //test OPEN  udp cli Net_HAL.CPP  
        vTaskDelay(1000);
        printf("\r\nExample: socket tx/rx 1\r\n");
        
        if(Net_HAL_OpenClint(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT))==0)
        {
            perror("\r\nopenclint failed");
        }
        char mac_buff[10]={0};
        u8 buf[5]={0x5a,0x10,0x11,0x12,0x00};
        while(1)
        {
            if(Net_HAL_Read(NET_ID_UDP, recv_buffer,sizeof(recv_buffer))>0)
            {
                Net_HAL_Write(NET_ID_UDP, "SERVER SEND..", 13);
                printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
                
            }
            Net_HAL_Write(NET_ID_UDP, buf, 5);
            
            Net_HAL_GetIP();
            wifi_get_mac_address(mac_buff);
            vTaskDelay(2000);
            printf("\r\ngoon...%s",mac_buff);
        }
#else  //TCP
        vTaskDelay(1000);
        printf("\r\nExample: socket tx/rx 1\r\n");//DOMIAN_API_ADDR
        //if(Net_HAL_OpenClint(NET_ID_HTTP, 0,dataserver_addr, TCP_TEST_PORT)==0)
        if(Net_HAL_OpenClint(NET_ID_TCP, inet_addr(dataserver_addr),0, (TCP_TEST_PORT))==0)
        {
            perror("\r\nopenclint failed");
        }
        char mac_buff[10]={0};
        u8 buf[5]={0x5a,0x10,0x11,0x12,0x13};
        while(1)
        {
            if(Net_HAL_Read(NET_ID_TCP, recv_buffer,sizeof(recv_buffer))>0)
            {
                Net_HAL_Write(NET_ID_TCP, "client SEND..", 13);
                printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
                
            }
            Net_HAL_Write(NET_ID_HTTP, buf, 5);
            //printf("\r\n2&xnetif[0]=%x,addr=%x",&xnetif[0],xnetif[0].ip_addr);
            Net_HAL_GetIP();
            wifi_get_mac_address(mac_buff);
            printf("\r\ngoon...%s\r\n",mac_buff);
            vTaskDelay(2000);
            
        }
            
    
#endif
#endif   


#if  0 
	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = INADDR_ANY;

	if(bind(server_fd, (struct sockaddr *) &server_addr, sizeof(server_addr)) != 0) {
		printf("ERROR: bind\n");
		goto trx_exit;
	}
    
	if(listen(server_fd, LISTEN_QLEN) != 0) {
		printf("ERROR: listen\n");
		goto trx_exit;
	}
    
	while(1) {
		cli_addr_size = sizeof(cli_addr);
		client_fd = accept(server_fd, (struct sockaddr *) &cli_addr, &cli_addr_size);

		if(client_fd >= 0) {
			tx_exit = 1;
			rx_exit = 1;
			//RtlInitSema(&tcp_tx_rx_sema, 1);			
			rtw_init_sema(&tcp_tx_rx_sema, 1);

			if(xTaskCreate(tx_thread, ((const char*)"tx_thread"), 2048, &client_fd, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
				printf("\n\r%s xTaskCreate(tx_thread) failed", __FUNCTION__);
			else
				tx_exit = 0;

			vTaskDelay(10);

			if(xTaskCreate(rx_thread, ((const char*)"rx_thread"), 2048, &client_fd, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
				printf("\n\r%s xTaskCreate(rx_thread) failed", __FUNCTION__);
			else
				rx_exit = 0;

			while(1) {
				if(tx_exit && rx_exit) {
					close(client_fd);
                    printf("\r\nall end");
					break;
				}
				else
					vTaskDelay(1000);
			}

			//RtlFreeSema(&tcp_tx_rx_sema);			
			rtw_free_sema(&tcp_tx_rx_sema);
		}
	}
#endif
trx_exit:
	close(server_fd);
	vTaskDelete(NULL);
}

void example_socket_tcp_trx_3(void)
{
	if(xTaskCreate(example_socket_trx_thread3, ((const char*)"example_socket_tcp_trx_thread"), 1024, NULL, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
		printf("\n\r%s xTaskCreate(example_socket_tcp_trx_thread) failed", __FUNCTION__);
}


/********************************************************/

#endif

