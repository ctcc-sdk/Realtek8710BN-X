GET BEACON FRAME EXAMPLE

Description:
Get beacon frame information in station mode

Configuration:
[platform_opts.h]
	#define CONFIG_EXAMPLE_GET_BEACON_FRAME 1

Execution:
Call example_get_beacon_frame() to create get beacon frame thread.
It can collect the beacon of AP in the air.

