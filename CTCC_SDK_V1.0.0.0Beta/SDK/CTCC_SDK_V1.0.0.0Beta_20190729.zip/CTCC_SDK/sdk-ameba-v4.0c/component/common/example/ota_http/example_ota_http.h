#ifndef EXAMPLE_OTA_HTTP_H
#define EXAMPLE_OTA_HTTP_H

void example_ota_http(void);

#endif /* EXAMPLE_OTA_HTTP_H */
