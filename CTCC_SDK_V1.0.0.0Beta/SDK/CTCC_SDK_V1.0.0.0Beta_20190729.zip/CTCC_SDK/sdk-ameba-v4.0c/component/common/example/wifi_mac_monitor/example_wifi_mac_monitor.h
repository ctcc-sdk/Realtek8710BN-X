#ifndef __EXAMPLE_WIFI_MAC_MONITOR_H__
#define __EXAMPLE_WIFI_MAC_MONITOR_H__

/******************************************************************************
 *
 * Copyright(c) 2007 - 2015 Realtek Corporation. All rights reserved.
 *
 *
 ******************************************************************************/

void example_wifi_mac_monitor(void);
int get_station_mac(unsigned char *sta_mac,char rssi);

#endif //#ifndef __EXAMPLE_WIFI_MAC_MONITOR_H__
