#ifndef EXAMPLE_HTTP_DOWNLOAD_H
#define EXAMPLE_HTTP_DOWNLOAD_H

void example_http_download(void);

#endif /* EXAMPLE_HTTP_DOWNLOAD_H */
