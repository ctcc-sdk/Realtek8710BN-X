XML EXAMPLE

Description:
The creation of a light XML document is used as the example of XML document generation.
The processing of a sensor XML document is used as the example of XML document parsing.

Configuration:
[platform_opts.h]
	#define CONFIG_EXAMPLE_XML    1
	
Execution:
An XML example thread will be started automatically when booting.

