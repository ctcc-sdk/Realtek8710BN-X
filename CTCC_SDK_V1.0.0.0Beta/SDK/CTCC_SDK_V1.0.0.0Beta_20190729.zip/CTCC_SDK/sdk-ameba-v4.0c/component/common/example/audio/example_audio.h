#ifdef _EXAMPLE_AUDIO_H_
#define _EXAMPLE_AUDIO_H_

void example_audio(void);

#endif
