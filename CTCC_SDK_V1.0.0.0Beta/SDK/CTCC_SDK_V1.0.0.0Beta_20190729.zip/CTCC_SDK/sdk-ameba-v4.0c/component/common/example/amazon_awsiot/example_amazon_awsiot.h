#ifndef EXAMPLE_AMAZON_AWSIOT_H
#define EXAMPLE_AMAZON_AWSIOT_H

void example_amazon_awsiot(void);

#endif /* EXAMPLE_AMAZON_AWSIOT_H */
