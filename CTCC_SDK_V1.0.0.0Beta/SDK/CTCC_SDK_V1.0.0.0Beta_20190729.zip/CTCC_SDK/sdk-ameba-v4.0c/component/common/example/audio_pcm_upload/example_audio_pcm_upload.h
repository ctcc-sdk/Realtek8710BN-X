#ifndef EXAMPLE_AUDIO_PCM_UPLOAD_H
#define EXAMPLE_AUDIO_PCM_UPLOAD_H

void example_audio_pcm_fw_upload(void);

#endif /* EXAMPLE_AUDIO_PCM_UPLOAD_H */
