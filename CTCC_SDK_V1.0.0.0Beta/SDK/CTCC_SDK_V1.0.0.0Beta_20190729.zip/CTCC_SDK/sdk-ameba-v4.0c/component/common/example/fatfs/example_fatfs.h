#ifndef _EXAMPLE_FATFS_H
#define _EXAMPLE_FATFS_H

void example_fatfs(void);

#endif /* _EXAMPLE_FATFS_H */

