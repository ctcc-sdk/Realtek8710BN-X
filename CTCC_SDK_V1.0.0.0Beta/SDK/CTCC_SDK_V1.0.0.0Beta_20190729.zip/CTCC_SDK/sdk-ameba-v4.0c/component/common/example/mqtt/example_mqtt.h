#ifndef EXAMPLE_MQTT_H
#define EXAMPLE_MQTT_H

void example_mqtt(void);

#endif /* EXAMPLE_MQTT_H */
