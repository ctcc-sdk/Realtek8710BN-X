HTTP CLIENT EXAMPLE

Description:
Http client send request to get server response.

Configuration:
Change HOST_NAME and HOST_PORT to user define.
[platform_opts.h]
	#define CONFIG_EXAMPLE_HTTP_CLIENT 1

Execution:
Call http_client() to send http request.

