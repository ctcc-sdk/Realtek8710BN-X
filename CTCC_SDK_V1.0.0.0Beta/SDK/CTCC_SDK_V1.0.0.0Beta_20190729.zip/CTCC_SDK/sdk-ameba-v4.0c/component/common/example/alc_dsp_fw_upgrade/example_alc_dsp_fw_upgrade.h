#ifndef EXAMPLE_ALC_DPS_FW_UPGRADE_H
#define EXAMPLE_ALC_DSP_FW_UPGRADE_H

void example_alc_dsp_fw_upgrade(void);

#endif /* EXAMPLE_ALC_CODEC_FW_UPGRADE_H */
