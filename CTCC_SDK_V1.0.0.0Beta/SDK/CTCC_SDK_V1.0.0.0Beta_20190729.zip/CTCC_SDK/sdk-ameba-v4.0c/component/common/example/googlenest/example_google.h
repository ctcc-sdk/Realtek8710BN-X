#ifndef GOOGLE_THREAD_H
#define GOOGLE_THREAD_H

#define HOST_ADDR       "your_firebase_address.firebaseio.com"
#define GN_PORT		443

void example_google(char *type);


#endif
