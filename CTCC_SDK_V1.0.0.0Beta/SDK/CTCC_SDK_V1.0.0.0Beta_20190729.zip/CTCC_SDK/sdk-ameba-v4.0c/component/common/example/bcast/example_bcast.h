#ifndef EXAMPLE_BCAST_H
#define EXAMPLE_BCAST_H

void example_bcast(void);

#endif /* EXAMPLE_BCAST_H */
