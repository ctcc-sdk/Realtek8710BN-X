#ifndef EXAMPLE_COAP_H
#define EXAMPLE_COAP_H

void example_coap(void);

#endif /* EXAMPLE_COAP_H */
