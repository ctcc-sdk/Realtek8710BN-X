#ifdef _EXAMPLE_AUDIO_H_
#define _EXAMPLE_AUDIO_H_

void example_audio_mp3(void);

#endif
