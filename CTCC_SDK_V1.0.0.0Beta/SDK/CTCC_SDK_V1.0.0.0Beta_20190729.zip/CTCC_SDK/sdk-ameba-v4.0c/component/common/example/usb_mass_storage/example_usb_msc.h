#ifndef _EXAMPLE_MASS_STORAGE_H
#define _EXAMPLE_MASS_STORAGE_H

void example_mass_storage(void);

#endif /* _EXAMPLE_FATFS_H */

