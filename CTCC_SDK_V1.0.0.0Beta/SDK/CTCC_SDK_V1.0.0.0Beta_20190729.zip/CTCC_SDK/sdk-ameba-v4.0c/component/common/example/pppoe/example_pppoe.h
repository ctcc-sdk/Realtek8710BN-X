#ifndef EXAMPLE_PPPOE_H
#define EXAMPLE_PPPOE_H

void example_pppoe(void);

#endif /* EXAMPLE_PPPOE_H */
