#ifndef _EXAMPLE_WSCLIENT_H
#define _EXAMPLE_WSCLIENT_H

void example_wsclient(void);

#endif /* _EXAMPLE_WSCLIENT_H */