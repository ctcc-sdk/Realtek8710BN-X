#ifndef EXAMPLE_HTTPC_H
#define EXAMPLE_HTTPC_H

void example_httpc(void);

#endif /* EXAMPLE_HTTPC_H */
