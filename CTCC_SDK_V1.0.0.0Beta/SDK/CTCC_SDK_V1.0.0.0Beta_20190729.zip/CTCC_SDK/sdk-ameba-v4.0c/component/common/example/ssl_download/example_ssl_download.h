#ifndef EXAMPLE_SSL_DOWNLOAD_H
#define EXAMPLE_SSL_DOWNLOAD_H

void example_ssl_download(void);

#endif /* EXAMPLE_SSL_DOWNLOAD_H */
