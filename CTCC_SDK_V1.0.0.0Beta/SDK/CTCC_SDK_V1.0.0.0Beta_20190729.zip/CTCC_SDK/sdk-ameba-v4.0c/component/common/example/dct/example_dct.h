#ifndef _EXAMPLE_DCT_H
#define _EXAMPLE_DCT_H

void example_dct(void);

#endif /* _EXAMPLE_DCT_H */

