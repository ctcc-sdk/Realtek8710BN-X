#ifndef EXAMPLE_SNTP_SHOWTIME_H
#define EXAMPLE_SNTP_SHOWTIME_H

void example_sntp_showtime(void);

#endif /* EXAMPLE_SNTP_SHOWTIME_H */
