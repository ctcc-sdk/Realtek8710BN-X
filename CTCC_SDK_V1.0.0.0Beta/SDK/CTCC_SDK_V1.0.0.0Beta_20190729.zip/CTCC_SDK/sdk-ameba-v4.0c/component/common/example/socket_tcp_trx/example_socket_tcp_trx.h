#ifndef EXAMPLE_SOCKET_TCP_TRX_H
#define EXAMPLE_SOCKET_TCP_TRX_H

void example_socket_tcp_trx_1(void);
void example_socket_tcp_trx_2(void);




#endif /* EXAMPLE_SOCKET_TCP_TRX_H */
