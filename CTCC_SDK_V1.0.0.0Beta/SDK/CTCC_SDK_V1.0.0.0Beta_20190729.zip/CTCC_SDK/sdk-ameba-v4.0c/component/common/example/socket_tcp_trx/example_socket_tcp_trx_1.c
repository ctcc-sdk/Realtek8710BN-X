
#define     _SOCKET_TEST_
#ifdef      _SOCKET_TEST_

#include <platform/platform_stdlib.h>
#include <platform_opts.h>
#include <stdio.h>
#include "osdep_service.h"
#include "lwip/ip_addr.h"
#include "main.h"
#include "FreeRTOS.h"
#include "task.h"

#include <lwip/sockets.h>
//#include <osdep_api.h>
#include <osdep_service.h>
#include"wifi_constants.h"
#include <lwip_netconf.h>
#include "HAL_Wifi.h"


//typedef signed char S8;
//typedef signed short S16;
//typedef signed long  S32;

//typedef unsigned char  U8, UINT8, uint8;
//typedef unsigned short U16, UINT16, uint16;
//typedef unsigned long  U32, UINT32, uint32;
#define BZERO(s, n)         memset(s, 0, n)

/** 255.255.255.255 */
#define INADDR_NONE         IPADDR_NONE
/** 127.0.0.1 */
#define INADDR_LOOPBACK     IPADDR_LOOPBACK
/** 0.0.0.0 */
#define INADDR_ANY          IPADDR_ANY
/** 255.255.255.255 */
#define INADDR_BROADCAST    IPADDR_BROADCAST


#define SERVER_PORT     18899
#define LISTEN_QLEN     2


#define PRODUCTION_SSID                "het-test-wifi"
#define PRODUCTION_SSID_KEY            "12345678"
#define PRODUCTION_KEY_TYPE            RTW_SECURITY_WPA2_AES_PSK
#define PRODUCTION_IP                  (0xC0A80A64)
#define SERVER_IP                      "192.168.10.186"
#define PRODUCTION_PORT                (8080)
#define SERVER_PORT                    (18899)

#define DEFAULT_IDENTIFY_SSID          "HET_000106_579C"
#define DEFAULT_IDENTIFY_SSID_KEY      0
#define DEFAULT_IDENTIFY_KEY_TYPE      RTW_SECURITY_OPEN

static int tx_exit = 0, rx_exit = 0;
//static _Sema tcp_tx_rx_sema;
static _sema tcp_tx_rx_sema;

extern struct netif xnetif[NET_IF_NUM]; 
extern void fATWx(void *arg);

static U32  udp_recv_addr;
static int  udp_socket= -1;
static int  tcp_socket[2] = {-1,-1};
static int  tcp_server_socket = -1;

static struct sockaddr_in server_addr;
static struct sockaddr_in tcpcli_addr = {0};
static struct sockaddr_in udpcli_addr = {0};

static  char *ip_addr;
static const char *udp_ip_addr;
static U32 getIpAddr;
static U16 udp_Server_Port;

/*
typedef enum
{
    NET_ID_TCP= 0x0,
    NET_ID_HTTP,
    NET_ID_UDP,
    NET_ID_MAX
}TE_NET_ID;
*/
#if 0
typedef struct WAN_MSG{
    char    wifi_sta_ssid[16],
    char    wifi_sta_pwd[16],
    char    server_ip[16],
    rtw_security_t security_type,
    int     ssid_len,
    int     password_len,
    int     channel,
    int     server_port
}WIFI_STA_MSG;
typedef struct LAN_MSG{
    char    wifi_ap_ssid[16],
    char    wifi_ap_pwd[16],
    char    wifi_ap_ip[16],
    rtw_security_t security_type,
    int     ssid_len,
    int     password_len,
    int     channel,
    int     server_port
}WIFI_AP_MSG;
typedef struct NET_MSG{
    WIFI_STA_MSG wifi_sta,
    WIFI_AP_MSG  wifi_ap
}WIFI_MSG;

WIFI_MSG wifi_msg;
#endif

BOOL Net_HAL_CloseClint1(U8 ID);
BOOL Net_HAL_CloseServer1(U8 ID);

void rlk_tcp_recv_func(void *param)
{
    int socket_fd = * (int *) param;
	
	fd_set read_fds;
	struct timeval timeout;
	unsigned char rx_buff[1024] = {0};
	int count=0;
	int ret = 0, sock_err = 0;
    size_t err_len = sizeof(sock_err);

	while(1) 

	{
		//printf("[%s]socket fd:%d\n",__FUNCTION__,socket_fd);
		FD_ZERO(&read_fds);
		timeout.tv_sec = 10;
		timeout.tv_usec = 0;
		//while(server_link == -1)
		{
			vTaskDelay(100);
		}
		FD_SET(socket_fd, &read_fds);
                
		if(select(socket_fd + 1, &read_fds, NULL, NULL, &timeout)) 
		{
			if(FD_ISSET(socket_fd, &read_fds)) 
			{
				int read_size = recv(socket_fd, rx_buff, sizeof(rx_buff), 0);
				printf("NET---->:");
				//printf("recv length:%d\n",read_size);
				printf("recv:(str)");
				printf("%s\r\n",rx_buff);
				//print_hex(rx_buff,read_size);
				
			}
		}
		else
		{
			printf("TCP recv: no data in 10 seconds\n");
		}
                
		vTaskDelay(300);
	}

    rx_exit = 1;
    vTaskDelete(NULL);
}

static void tx_thread(void *param)
{
	int client_fd = * (int *) param;
	unsigned char buffer[1024];
	memset(buffer, 0, sizeof(buffer));
    memcpy(buffer, "\r\nhello,I am tx_thread", 22);
	printf("\n%s start\n", __FUNCTION__);

	while(1) {
		int ret = 0;

		//RtlDownSema(&tcp_tx_rx_sema);		
		rtw_down_sema(&tcp_tx_rx_sema);
		ret = send(client_fd, buffer, sizeof(buffer), 0); 
		//RtlUpSema(&tcp_tx_rx_sema);		
		rtw_up_sema(&tcp_tx_rx_sema);

		if(ret <= 0)
			goto exit;

		vTaskDelay(10000);
	}

exit:
	printf("\n%s exit\n", __FUNCTION__);
	tx_exit = 1;
	vTaskDelete(NULL);
}

 void rx_thread(void *param)
{
    
	int client_fd = * (int *) param;
	
	unsigned char buffer[512]={0};
    fd_set read_fds;
	struct timeval timeout;
	int count=0;
	int ret = 0, sock_err = 0;
    size_t err_len = sizeof(sock_err);
    printf("\n%s start\n", __FUNCTION__);
 	while(1) {
		
        FD_ZERO(&read_fds);
		timeout.tv_sec = 10;
		timeout.tv_usec = 0;
        vTaskDelay(100);
        FD_SET(client_fd, &read_fds);

		//if(select(client_fd + 1, &read_fds, NULL, NULL, &timeout)) 
		{
            //if(FD_ISSET(client_fd, &read_fds)) 
		    {
                //RtlDownSema(&tcp_tx_rx_sema);     
    		    //rtw_down_sema(&tcp_tx_rx_sema);
    		    ret = recv(client_fd, buffer, sizeof(buffer), 0);//MSG_DONTWAIT
                //getsockopt用于获取任意类型、任意状态套接口的选项当前值
    		    getsockopt(client_fd, SOL_SOCKET, SO_ERROR, &sock_err, &err_len);
                if(ret>0)
                    printf("\r\nrecv(str):%s",buffer);
				printf("\r\n#####ret=%d#",ret);
    		    //RtlUpSema(&tcp_tx_rx_sema);
    		    //rtw_up_sema(&tcp_tx_rx_sema);
                //printf("\r\nrx_thread");
    		    // ret == -1 and socket error == EAGAIN when no data received for nonblocking
		    }
		}
		if((ret == -1) && (sock_err == EAGAIN))
        {
            printf("\r\n1----%d-------",ret);
            
			continue;
		}
        else if(ret == 0)
		{
            if(count++>1000)
            {
                printf("\r\n2 rx----ret=%d-------",ret);
                count=0;
            }
            
       //     goto exit;
        }
        
            
		vTaskDelay(1);
	}

exit:
	printf("\n%s exit\n", __FUNCTION__);
	rx_exit = 1;
	vTaskDelete(NULL);
}

static void example_socket_tcp_trx_thread(void *param)
{
	int ret=0,timeout=20,server_fd = -1, client_fd = -1;
	struct sockaddr_in server_addr, cli_addr;
	size_t cli_addr_size;
#if CONFIG_LWIP_LAYER 
    struct ip_addr ipaddr;
    struct ip_addr netmask;
    struct ip_addr gw;
    struct netif * pnetif = &xnetif[0];
#endif
#if 1    
    vTaskDelay(5000);
	// Delay to wait for IP by DHCP
#if CONFIG_LWIP_LAYER
	printf("************\r\n");
	dhcps_deinit();
	IP4_ADDR(&ipaddr, GW_ADDR0, GW_ADDR1, 43, GW_ADDR3);
	IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1 , NETMASK_ADDR2, NETMASK_ADDR3);
	IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
	netif_set_addr(pnetif, &ipaddr, &netmask,&gw);
#endif
	wifi_off();
	vTaskDelay(20);
    if (wifi_on(RTW_MODE_AP) < 0){
		printf("\n\rERROR: Wifi on failed!");
		ret = RTW_ERROR;
		goto tcp_trx_exit;
	}
    vTaskDelay(2000);
	if(wifi_start_ap(DEFAULT_IDENTIFY_SSID,DEFAULT_IDENTIFY_KEY_TYPE,\
     0, strlen(DEFAULT_IDENTIFY_SSID), \
     0, 1)<0)
	{
        printf("\n\rERROR: Operation failed!");
		goto tcp_trx_exit;
     }
    //wpas_wps_dev_config(pnetif->hwaddr, 1);
     dhcps_init(&xnetif[0]);
    while(1)
    {
		char essid[33];
		if(wext_get_ssid(WLAN0_NAME, (unsigned char *) essid) > 0) 
        {
			if(strcmp((const char *) essid, (const char *)DEFAULT_IDENTIFY_SSID) == 0)
            {
				printf(DEFAULT_IDENTIFY_SSID);
				ret = 0;
				break;
			}
		}
		if(timeout == 0) {
			printf("Start AP timeout!\n\r");
			ret = -1;
			break;
		}
		vTaskDelay(1 * configTICK_RATE_HZ);
		timeout --;
	}
#else
     vTaskDelay(5000);
     // Delay to wait for IP by DHCP
     wifi_off();
     vTaskDelay(20);
     wifi_on(RTW_MODE_STA);
     vTaskDelay(2000);
     //wifi_restart_ap(DEFAULT_IDENTIFY_SSID,PRODUCTION_KEY_TYPE,\
    //  PRODUCTION_SSID_KEY, strlen(PRODUCTION_SSID), \
    //  strlen(PRODUCTION_SSID_KEY), 1);    
    // vTaskDelay(10000);
     ret=wifi_connect(PRODUCTION_SSID, PRODUCTION_KEY_TYPE, \
      PRODUCTION_SSID_KEY, strlen(PRODUCTION_SSID), \
      strlen(PRODUCTION_SSID_KEY), 0, NULL);
     if(ret == RTW_SUCCESS){
             LwIP_DHCP(0, DHCP_START);
         }
     

#endif
    vTaskDelay(10000);
	printf("\nExample: socket tx/rx 1\n");
    
#if  1   
	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = INADDR_ANY;
    
	if(bind(server_fd, (struct sockaddr *) &server_addr, sizeof(server_addr)) != 0) {
		printf("ERROR: bind\n");
		goto tcp_trx_exit;
	}
    
	if(listen(server_fd, LISTEN_QLEN) != 0) {
		printf("ERROR: listen\n");
		goto tcp_trx_exit;
	}
    
	while(1) {
		cli_addr_size = sizeof(cli_addr);
		client_fd = accept(server_fd, (struct sockaddr *) &cli_addr, &cli_addr_size);

		if(client_fd >= 0) {
			tx_exit = 1;
			rx_exit = 1;
			//RtlInitSema(&tcp_tx_rx_sema, 1);			
			rtw_init_sema(&tcp_tx_rx_sema, 1);

			if(xTaskCreate(tx_thread, ((const char*)"tx_thread"), 2048, &client_fd, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
				printf("\n\r%s xTaskCreate(tx_thread) failed", __FUNCTION__);
			else
				tx_exit = 0;

			vTaskDelay(10);

			if(xTaskCreate(rx_thread, ((const char*)"rx_thread"), 2048, &client_fd, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
				printf("\n\r%s xTaskCreate(rx_thread) failed", __FUNCTION__);
			else
				rx_exit = 0;

			while(1) {
				if(tx_exit && rx_exit) {
					close(client_fd);
                    printf("\r\nall end");
					break;
				}
				else
					vTaskDelay(2000);
			}

			//RtlFreeSema(&tcp_tx_rx_sema);			
			rtw_free_sema(&tcp_tx_rx_sema);
		}
	}
#endif
tcp_trx_exit:
	close(server_fd);
	vTaskDelete(NULL);
}


#define IS_INVALID_ID(ID)   (ID >= NET_ID_MAX)

struct info
{
	char buf[100];
	int port;
};

#define UDP_TEST_PORT       18899
#define TCP_TEST_PORT       80

static struct timeval timeout;
static fd_set read_fds;

BOOL test_udpserver(U8 ID, U32 IpAddr, U16 Port)
{
    struct sockaddr_in addr;
    int sockfd, len = 0;   
	int addr_len = sizeof(struct sockaddr_in);
    char buffer[256];  

    /* 建立socket，注意必须是SOCK_DGRAM */
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror ("socket");
        exit(1);
    }

    /* 填写sockaddr_in 结构 */
    BZERO(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(UDP_TEST_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);// 接收任意IP发来的数据

    /* 绑定socket */
    if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr))<0) {
        perror("connect");
        exit(1);
    }

    while(1) {
        BZERO(buffer, sizeof(buffer));
		len = recvfrom(sockfd, buffer, sizeof(buffer), 0,
                       (struct sockaddr *)&addr ,&addr_len);
        /* 显示client端的网络地址和收到的字符串消息 */
        printf("Received a string from client %s, string is: %s\n",
                inet_ntoa(addr.sin_addr), buffer);
        /* 将收到的字符串消息返回给client端 */
        sendto(sockfd,buffer, len, 0, (struct sockaddr *)&addr, addr_len);
    }

    return 0;
}


BOOL Net_HAL_OpenServer1(U8 ID, U32 IpAddr, U16 Port)
{
	int ret=0;
    int sockfd, length,  j, i = 0;
    int len,addr_len = 0;
    
    char test_buffer[256]={0};
    

    const int opt=1;

    U32 getIpAddr;
    S16 RetVal = 0;
    int udp_broadcast = 1;
    if (IS_INVALID_ID(ID))
    {
        printf("\r\n[Net_HAL]OpenServer Failed, ID Wrong, ID = %d", ID);
        return FALSE;
    }    
    //Net_HAL_CloseServer(ID);
    switch (ID)
    {
        case NET_ID_UDP:
        { 
             if (-1 == udp_socket)
             {
                getIpAddr = (IpAddr);//ntohl
                udp_ip_addr = inet_ntoa(getIpAddr);
            	addr_len = sizeof(struct sockaddr_in);
                printf("\r\nserver_addr :%s,%04x", udp_ip_addr,getIpAddr);
                
            	udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
                printf("\r\nudp_socket=%d",udp_socket);
                if (udp_socket<0)
            	{
            		perror("socket");
            		goto openServer_exit;
            	}
                //ret=setsockopt(udp_socket,SOL_SOCKET,SO_BROADCAST,(char*)&opt,sizeof(opt));//设置套接字类型
                if(ret<0)
                {
                //    printf("\r\nerror...");
                //    goto  openServer_exit;
                }
                BZERO(&server_addr, sizeof(server_addr));
                server_addr.sin_family = AF_INET;
            	server_addr.sin_port = Port;
                server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
                ret = bind(udp_socket, (struct sockaddr *)&server_addr, sizeof(server_addr));
            	if (ret < 0)
            	{
            		perror("bind");
            		goto openServer_exit;
            	}
                while(0)//udpserver test
                {
                    ///*
                    BZERO(&server_addr, sizeof(server_addr));
                    server_addr.sin_family = AF_INET;
                	server_addr.sin_port = Port;
                    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
                    ret = bind(udp_socket, (struct sockaddr *)&server_addr, sizeof(server_addr));
                	if (ret < 0)
                	{
                		perror("bind");
                		goto openServer_exit;
                	}//*/
                    FD_ZERO(&read_fds);
                    timeout.tv_sec = 0;
		            timeout.tv_usec = 1;
                    FD_SET(udp_socket, &read_fds);
                    if(select(udp_socket + 1, &read_fds, NULL, NULL, &timeout)) 
            		{
            			if(FD_ISSET(udp_socket, &read_fds)) 
            			{
                            BZERO(test_buffer, sizeof(test_buffer));
                            len = recvfrom(udp_socket, test_buffer, sizeof(test_buffer),0,\
                                (struct sockaddr *)&server_addr,&addr_len);
                            if(len>0)
                            {
                                /* 显示client端的网络地址和收到的字符串消息 */
                                memcpy(&udpcli_addr,&server_addr,sizeof(udpcli_addr));
                                printf("Received a string from client %s, string is: %s\n",\
                                    inet_ntoa(server_addr.sin_addr), test_buffer);
                            }

                        }
                    }
                    BZERO(&server_addr, sizeof(server_addr));
                    server_addr.sin_family = AF_INET;
                	server_addr.sin_port = Port;
                    server_addr.sin_addr.s_addr = htonl(INADDR_BROADCAST);//udpcli_addr.sin_addr;//
                    ret=setsockopt(udp_socket,SOL_SOCKET,SO_BROADCAST,(char*)&opt,sizeof(opt));//设置套接字类型
                    if(ret<0)
                    {
                        printf("\r\nerror...");
                    //    goto  openServer_exit;
                    }
                    printf("\r\nserver_addr :%s",  inet_ntoa(server_addr.sin_addr.s_addr));
                    /* 将收到的字符串消息返回给client端 */
                    memcpy(test_buffer, "\r\nserver send...", 17);
                    ret=sendto(udp_socket,test_buffer,strlen(test_buffer),0,(struct sockaddr *)&server_addr,addr_len);
                    if(ret<0)
                    {
                        printf("\r\nsend error");
                    }
                    vTaskDelay(2 * configTICK_RATE_HZ);
                }
                
             }
             else
             {
                  printf("\r\n[Net_HAL]OpenUdpServer_open Failed, Err code1 = %d\r\n",RetVal);     
             }         
        }
        break;
        
        case NET_ID_TCP:
        {
            if(-1 != tcp_server_socket)
            {    
               return FALSE;
            }
            else
            {
               getIpAddr = ntohl(IpAddr);
               tcp_server_socket = socket(AF_INET, SOCK_STREAM, 0);
               server_addr.sin_family = AF_INET;
               server_addr.sin_port = Port;
               server_addr.sin_addr.s_addr = htonl(getIpAddr);

               if(bind(tcp_server_socket, (struct sockaddr *) &server_addr, sizeof(server_addr)) != 0) {
                   printf("ERROR: bind\n");
                   goto openServer_exit;
               }
               
               if(listen(tcp_server_socket, LISTEN_QLEN) != 0) {
                   printf("ERROR: listen\n");
                   goto openServer_exit;
               }
  
            }          
        }
        break;
        default:
        {
        }
        break;        
    }

    
    return TRUE;
openServer_exit:  
    exit(1);
    


}

BOOL Network_Wifi_OpenUdpServer1(U32 IPAddr)
/********************************************************************************/
{
    U32 DataTmp32 = IPAddr;
    DataTmp32 &= 0x00FFFFFF;
    DataTmp32 |= (0xFF<<24);
    printf("\r\nserver ip=%s,%04x",inet_ntoa(IPAddr),IPAddr);
    return Net_HAL_OpenServer(NET_ID_UDP, DataTmp32, htons(UDP_TEST_PORT));
}

BOOL Net_HAL_OpenClint1(U8 ID, U32 IpAddr, U8* Domain, U16 Port)
{
    int ret;
    U32 getIpAddr;
    S16 RetVal = 0;
    int udp_broadcast = 1;
//    struct sockaddr_in server_addr;
//    struct sockaddr_in cli_addr = {0};
        
    if (IS_INVALID_ID(ID))
    {
        printf("\r\n[Net_HAL]OpenClint Failed, ID Wrong, ID = %d\r\n", ID);
        return FALSE;
    }    
    Net_HAL_CloseClint1(ID);
    printf("\r\n[Net_HAL_OpenClint]ID=%d,socket udp=%d,tcp[2]={%d,%d}",ID,udp_socket,tcp_socket[0],tcp_socket[1]);
    switch (ID)
    {
        case NET_ID_UDP:
        {
            if (-1 == udp_socket)
            {
                udp_socket = socket(PF_INET, SOCK_DGRAM, 0);
                if (-1 == udp_socket)
                {
                    perror("\r\n[Net_HAL_OpenClint]socket");
                    goto openClintexit;
                }
                getIpAddr = ntohl(IpAddr);
                udp_ip_addr = inet_ntoa(getIpAddr);
                BZERO(&udpcli_addr, sizeof(udpcli_addr));
                udpcli_addr.sin_family = AF_INET;
                udpcli_addr.sin_port = Port;
                udpcli_addr.sin_addr.s_addr = inet_addr(udp_ip_addr);
                ret=setsockopt(udp_socket,SOL_SOCKET,SO_BROADCAST,(char*)&udpcli_addr,sizeof(udpcli_addr));//设置套接字类型
                if(ret==-1)
                {
                    printf("\r\n[Net_HAL_OpenClint]setsockopt failed");
                    goto openClintexit;
                }

                 
            }
            else
            {
                printf("\r\n[Net_HAL_OpenClint]OpenUdpClint_open Failed, Err code1 = %d\r\n",RetVal);
            }
        }
        break;
        case NET_ID_TCP:
        case NET_ID_HTTP:
        {
            if(-1 == tcp_socket[ID])
            {   
                getIpAddr = (IpAddr);
                
                tcp_socket[ID] = socket(AF_INET, SOCK_STREAM, 0);
                tcpcli_addr.sin_family = AF_INET;
                tcpcli_addr.sin_port = Port;
                tcpcli_addr.sin_addr.s_addr = inet_addr(SERVER_IP);
                //主机字节序转换成网络字节序
                //inet_pton(AF_INET,SERVER_IP,
                //         &tcpcli_addr.sin_addr.s_addr);
                printf("\r\nport=%d,tcpaddr=%s,%04x",Port,inet_ntoa(getIpAddr),getIpAddr);
                //if(bind(tcp_socket[ID], (struct sockaddr *) &tcpcli_addr, sizeof(tcpcli_addr)) < 0)
                {
                //    printf("ERROR: bind\n");
                //    goto openClintexit;
                }
                
                if(connect(tcp_socket[ID],(struct sockaddr*)&tcpcli_addr,sizeof(tcpcli_addr))<0)
                {
                    perror("connect error");
                    goto openClintexit;
                }
                
                
            }
            else
            {
               printf("\r\n[Net_HAL]OpenClint_open Failed 2, Err code = %d\r\n",RetVal);
            }
        }
        break;
        default:
        {
        }
        break;        
    }

    return TRUE;
openClintexit: 
    return FALSE;
}

/******************************************************************************/
BOOL Net_HAL_CloseClint1(U8 ID)
/******************************************************************************/
{   
    S16 RetVal; 

    if (IS_INVALID_ID(ID))
    {
        printf("\r\n[Net_HAL]CloseClint Failed, ID Wrong, ID = %d\r\n", ID);
        return FALSE;
    }
    
    switch (ID)
    {
        case NET_ID_UDP:
        {
            if (NULL != udp_socket)
            {  
               printf("\r\n[Net_HAL_CloseClint]udp_socket=%d",udp_socket);
               //RetVal = udp_socket->close();
               RetVal = close(udp_socket);
               if(0 != RetVal)
               {
                   printf("\r\n[Net_HAL]CloseUdpClint Failed, Err code = %d\r\n",RetVal);     
                   return FALSE;
               }
                
               //delete(udp_socket);
               //      udp_socket = NULL; 
               udp_socket = -1; 
                     printf("\r\n[Net_HAL_OpenClint]Close OK...");
             } 
        }
        break;

        case NET_ID_TCP:
        case NET_ID_HTTP:
        {
            if (NULL != tcp_socket[ID])
            {
                printf("\r\n[Net_HAL_CloseClint]tcp_socket[%d]=%d",ID,tcp_socket[ID]);
                //RetVal = tcp_socket[ID]->close();
                RetVal = close(tcp_socket[ID]);
                if(0 != RetVal)
                {
                    printf("\r\n[Net_HAL]CloseTcpClint Failed, Err code = %d\r\n",RetVal);
                    return FALSE;
                }
        
                //delete(tcp_socket[ID]);
                //tcp_socket[ID] = NULL;
                tcp_socket[ID] = -1;
                printf("\r\n[Net_HAL_OpenClint]Close OK...");
            }  
        }
        break;
        
        default:
        {
        }
        break;
    }
    
    return TRUE;
}

/******************************************************************************/
BOOL Net_HAL_CloseServer1(U8 ID)
/******************************************************************************/
{   
    S16 RetVal=0; 

    if (IS_INVALID_ID(ID))
    {
        printf("\r\n[Net_HAL]CloseClint Failed, ID Wrong, ID = %d\r\n", ID);
        return FALSE;
    }
    
    switch (ID)
    {
        case NET_ID_UDP:
        {
            if (NULL != udp_socket)
            {  
               //RetVal = udp_socket->close();
               RetVal = close(udp_socket);
               if(0 != RetVal)
               {
                   printf("\r\n[Net_HAL]CloseUdpServer Failed, Err code = %d\r\n",RetVal);     
                   return FALSE;
               }      
               //delete(udp_socket);
               //      udp_socket = NULL;   
               udp_socket = -1;
            } 
           
        }
        break;

        case NET_ID_TCP:
        {
            if (-1 != tcp_server_socket)
            {  
               RetVal = close(tcp_server_socket); 
               if(0 != RetVal)
               {
                   printf("\r\n[Net_HAL]CloseTcpServer Failed...\r\n");
                   return FALSE;
               }
               //delete(tcp_server_socket);
               //      tcp_server_socket = NULL;
               tcp_server_socket = -1;
            }            
        }
        break;

        default:
        {
        }
        break;
    }
    
    return TRUE;
}


/******************************************************************************/
U16 Net_HAL_Write1(S16 ID, U8* pBuf, U16 Len)
/******************************************************************************/
{
    S32 rLen;
    int ret,addr_len = sizeof(struct sockaddr_in);
    int opt = -1;
    //printf("\r\n[Net_HAL_Write]ID=%d,%s,%d",ID,pBuf,Len);
    if (IS_INVALID_ID(ID))
    {
        printf("\r\n[Net_HAL]OpenClint Failed, ID Wrong, ID = %d\r\n", ID);
        return FALSE;
    }  
    
    switch (ID)
    {
        case NET_ID_UDP:       
        {
            if ((udp_socket !=-1) && (NULL != udp_ip_addr) && (pBuf != NULL)
            && (Len > 0))
            { 
                #if 0
                   printf("Net_HAL_WriteUdp Len :%d\r\n", Len);
                   for(i=0;i<Len;i++)
                   {
                         printf("%02x ", pBuf[i]);
                   }
                   printf("\r\n");
                   #endif
                BZERO(&server_addr, sizeof(server_addr));
                server_addr.sin_family = AF_INET;
                server_addr.sin_port = htons(UDP_TEST_PORT);
                server_addr.sin_addr.s_addr = (inet_addr(SERVER_IP));//htonl(INADDR_BROADCAST);//
                ret = setsockopt(udp_socket, SOL_SOCKET, SO_BROADCAST, (char *)&opt, sizeof(opt));
	            if (ret == -1)
		            printf("Set sock to broadcast format fail\n");
                rLen=sendto(udp_socket,pBuf,strlen(pBuf),0,(struct sockaddr *)&server_addr,addr_len);  
                if (rLen > 0)
                {
                     
                     #if 1
                       printf("[Net_HAL_Write]Udpsend ok Len :%d\r\n", Len);
                       for(int i=0;i<Len;i++)
                       {
                             printf("%02x ", pBuf[i]);
                       }
                       printf("\r\n");
                       #endif
                     return 1;
                }
                else
                {
                      printf("\r\n[Net_HAL]WriteUdp Failed, Err code = %d\r\n",rLen);     
                }
                 
            } 
            else
            {
                printf("\r\n[Net_HAL]udp_socket=%d, udp_ip_addr=%s,pBuf= %s,len=%d\r\n",udp_socket,udp_ip_addr,pBuf,Len);     

            }
        }
        break;
        
        case NET_ID_TCP:
        case NET_ID_HTTP:
        {
           if ((-1 != tcp_socket[ID]) && (pBuf != NULL) || (Len > 0))
           {    
               U8 Counter = 0;
               do
               {
                   
                   rLen = send(tcp_socket[ID], pBuf, Len, 0);
                   if ((++ Counter) >= 3)
                   {
                       break;
                   }
               }
               while (rLen <= 0);
               
                   
               #if 0
               for(i=0;i<Len;i++)
                  {
                        printf("%02x ", pBuf[i]);
                  }
                  printf("\r\n");
                  printf("Net_HAL_WriteUdp rLen :%d\r\n", rLen);
                  #endif
               if (rLen > 0)
               {
                  return 1;
               }
               else
               {
                   printf("\r\n[Net_HAL]WriteTcp Failed, Err code = %d\r\n",rLen);     
               }
           }        
        }
        break;
        
        default:
        {
        }
        break;        
    } 
    
    return 0;
}

/******************************************************************************/
U16 Net_HAL_Read1(S16 ID, U8* pBuf, U16 Len)
/******************************************************************************/
{
    S32 rLen = 0;
    int ret=0,addr_len = sizeof(struct sockaddr_in);
    if (IS_INVALID_ID(ID))
    {
        printf("\r\n[Net_HAL_Read]OpenClint Failed, ID Wrong, ID = %d\r\n", ID);
        return FALSE;
    }   
    
    switch (ID)
    {
        case NET_ID_UDP:       
        {
            if ((-1 != udp_socket) && (NULL != udp_ip_addr) && (pBuf != NULL))
            {        
                BZERO(&server_addr, sizeof(server_addr));
                server_addr.sin_family = AF_INET;
            	server_addr.sin_port = htons(UDP_TEST_PORT);
                server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
                
                FD_ZERO(&read_fds);
                timeout.tv_sec = 0;
                timeout.tv_usec = 1;
                FD_SET(udp_socket, &read_fds);
                if(select(udp_socket + 1, &read_fds, NULL, NULL, &timeout)) 
        		{
        			if(FD_ISSET(udp_socket, &read_fds)) 
        			{
                        rLen = recvfrom(udp_socket,pBuf,(U32)Len,0,\
                          (struct sockaddr *)&udpcli_addr,&addr_len);
                       if (rLen > 0)
                       {
                           //const char *  ip_address  = udp_recv_addr.get_ip_address();
                           //printf("ip_address %s\r\n", ip_address);    
                           //printf("ip_addr %s\r\n", ip_addr);
                           printf("HAL_ReadUdp rLen %02x %02x %d \r\n", pBuf[0],pBuf[1],rLen);
                           //if (!strcmp(ip_address,ip_addr))
                           {
                           //    rLen = 0;
                           }
                       }
        			}
                }
                else
                {
                   rLen = 0;
                }
            }
        }
        break;
        
        case NET_ID_TCP:
        case NET_ID_HTTP:
        {
            if ((-1 != tcp_socket[ID]) && (pBuf != NULL))
            {
                if (Len > 0)
                {
                    FD_ZERO(&read_fds);
            		timeout.tv_sec = 0;
            		timeout.tv_usec = 10;
                    vTaskDelay(100);
                    FD_SET(tcp_socket[ID], &read_fds);

            		if(select(tcp_socket[ID] + 1, &read_fds, NULL, NULL, &timeout)) 
            		{
                        if(FD_ISSET(tcp_socket[ID], &read_fds)) 
            		    {
                            //RtlDownSema(&tcp_tx_rx_sema);     
                		    //rtw_down_sema(&tcp_tx_rx_sema);
                		    rLen = recv(tcp_socket[ID], pBuf, sizeof(pBuf), 0);//MSG_DONTWAIT
                            //getsockopt用于获取任意类型、任意状态套接口的选项当前值
                		    if(rLen>0)
            				{
                                printf("\r\nret=%d,pbuf=%s",rLen,pBuf);
                		    }
                		    //RtlUpSema(&tcp_tx_rx_sema);
                		    //rtw_up_sema(&tcp_tx_rx_sema);
                            //printf("\r\nrx_thread");
                		    // ret == -1 and socket error == EAGAIN when no data received for nonblocking
            		    }
            		}
                     #if 0
                     if( rLen >0)
                     {
                        for(i=0;i<rLen;i++)
                           {
                                 printf("%02x ", pBuf[i]);
                           }
                           printf("\r\n");
                           printf("Net_HAL_WriteUdp rLen :%d\r\n", rLen);                 
                        }
                     #endif
                } 
                if (rLen <= 0)
                {           
                    rLen =0;
                }
            }
        }
        break;
        
        default:
        {
        }
        break;        
    }   
    
    return (U16)rLen;
}

static void example_socket_trx_thread(void *param)
{
    char recv_buffer[1024]={0};
	int ret=0,timeout=20,server_fd = -1, client_fd = -1;
	struct sockaddr_in server_addr, cli_addr;
	size_t cli_addr_size;
#if CONFIG_LWIP_LAYER 
        struct ip_addr ipaddr;
        struct ip_addr netmask;
        struct ip_addr gw;
        struct netif * pnetif = &xnetif[0];
#endif
#if 0   //AP MODE 
    vTaskDelay(5000);
	// Delay to wait for IP by DHCP
#if CONFIG_LWIP_LAYER
	printf("************\r\n");
	dhcps_deinit();
	IP4_ADDR(&ipaddr, GW_ADDR0, GW_ADDR1, 43, GW_ADDR3);
	IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1 , NETMASK_ADDR2, NETMASK_ADDR3);
	IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
	netif_set_addr(pnetif, &ipaddr, &netmask,&gw);
#endif
	wifi_off();
	vTaskDelay(20);
    if (wifi_on(RTW_MODE_AP) < 0){
		printf("\n\rERROR: Wifi on failed!");
		ret = RTW_ERROR;
		exit(1);
	}
    vTaskDelay(2000);
	if(wifi_start_ap(DEFAULT_IDENTIFY_SSID,DEFAULT_IDENTIFY_KEY_TYPE,\
     0, strlen(DEFAULT_IDENTIFY_SSID), \
     0, 1)<0)
	{
        printf("\n\rERROR: Operation failed!");
		exit(1);
     }
    //wpas_wps_dev_config(pnetif->hwaddr, 1);
     dhcps_init(&xnetif[0]);
    while(1)
    {
		char essid[33];
		if(wext_get_ssid(WLAN0_NAME, (unsigned char *) essid) > 0) 
        {
			if(strcmp((const char *) essid, (const char *)DEFAULT_IDENTIFY_SSID) == 0)
            {
				printf(DEFAULT_IDENTIFY_SSID);
				ret = 0;
				break;
			}
		}
		if(timeout == 0) {
			printf("Start AP timeout!\n\r");
			ret = -1;
			break;
		}
		vTaskDelay(1 * configTICK_RATE_HZ);
		timeout --;
	}
#else //STA MODE
///*
     vTaskDelay(1000);
     // Delay to wait for IP by DHCP
     wifi_off();
     vTaskDelay(20);
     wifi_on(RTW_MODE_STA);
     vTaskDelay(2000);
     ret=wifi_connect(PRODUCTION_SSID, PRODUCTION_KEY_TYPE, \
      PRODUCTION_SSID_KEY, strlen(PRODUCTION_SSID), \
      strlen(PRODUCTION_SSID_KEY), 0, NULL);
     if(ret == RTW_SUCCESS){
             LwIP_DHCP(0, DHCP_START);
         }
//*/     
   // Net_HAL_ConnectRouter(PRODUCTION_SSID, PRODUCTION_SSID_KEY, PRODUCTION_KEY_TYPE);
    vTaskDelay(1000);

#endif
#define dataserver_addr "119.29.9.233"//"192.168.10.186"//
#define  SERVER_TEST 0
#define  CLIENT_TEST 1
#if SERVER_TEST
#if 1  //test OPEN  udp server Net_HAL.CPP  
    vTaskDelay(1000);
	printf("\r\nExample: socket tx/rx 1\r\n");
    if(Network_Wifi_OpenUdpServer1(inet_addr(SERVER_IP))==0)
    //if(Net_HAL_OpenServer(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT))==0)
    {
        perror("\r\nopenclint failed");
    }
    char mac_buff[10]={0};
    u8 buf[5]={0x5a,0x10,0x11,0x12,0x00};
    unsigned char *ip=NULL;
    while(1)
    {
        if(Net_HAL_Read(NET_ID_UDP, recv_buffer,sizeof(recv_buffer))>0)
        {
            Net_HAL_Write(NET_ID_UDP, "SERVER SEND..", 13);
            printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
            
        }
        Net_HAL_Write(NET_ID_UDP, buf, 5);
        
        Net_HAL_GetIP();
        wifi_get_mac_address(mac_buff);
        vTaskDelay(1000);
        printf("\r\ngoon...%s",mac_buff);
    }
#else  //本文件
    vTaskDelay(1000);
	printf("\r\nExample: socket tx/rx 1\r\n");
    //Network_Wifi_OpenUdpServer(inet_addr(SERVER_IP));
    //Net_HAL_OpenServer1(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT));
    if(Net_HAL_OpenServer1(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT))==0)
    {
        perror("\r\nopenclint failed");
    }
    char mac_buff[10]={0};
    u8 buf[5]={0x5a,0x10,0x11,0x12,0x00};
    while(1)
    {
        if(Net_HAL_Read1(NET_ID_UDP, recv_buffer,sizeof(recv_buffer))>0)
        {
            Net_HAL_Write1(NET_ID_UDP, "SERVER SEND..", 13);
            printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
            
        }
        Net_HAL_Write1(NET_ID_UDP, buf, 5);
        
        Net_HAL_GetIP();
        wifi_get_mac_address(mac_buff);
        vTaskDelay(2000);
        printf("\r\ngoon...%s",mac_buff);
    }
        

#endif
#endif   

#if CLIENT_TEST
#if 0  //test OPEN  udp cli Net_HAL.CPP  
        vTaskDelay(1000);
        printf("\r\nExample: socket tx/rx 1\r\n");
        
        if(Net_HAL_OpenClint(NET_ID_UDP, inet_addr(SERVER_IP), htons(UDP_TEST_PORT))==0)
        {
            perror("\r\nopenclint failed");
        }
        char mac_buff[10]={0};
        u8 buf[5]={0x5a,0x10,0x11,0x12,0x00};
        while(1)
        {
            if(Net_HAL_Read(NET_ID_UDP, recv_buffer,sizeof(recv_buffer))>0)
            {
                Net_HAL_Write(NET_ID_UDP, "SERVER SEND..", 13);
                printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
                
            }
            Net_HAL_Write(NET_ID_UDP, buf, 5);
            
            Net_HAL_GetIP();
            wifi_get_mac_address(mac_buff);
            vTaskDelay(2000);
            printf("\r\ngoon...%s",mac_buff);
        }
#else  //TCP
        vTaskDelay(100);
        printf("\r\nExample: socket tx/rx 1\r\n");//DOMIAN_API_ADDR inet_addr
        //if(Net_HAL_OpenClint(NET_ID_HTTP, 0,dataserver_addr, TCP_TEST_PORT)==0)
        if(Net_HAL_OpenClint(NET_ID_HTTP, 0,(DOMIAN_API_ADDR), (TCP_TEST_PORT))==0)
        {
            perror("\r\nopenclint failed");
        }
        char mac_buff[10]={0};
        u8 buf[5]={0x5a,0x10,0x11,0x12,0x13};
        while(1)
        {
            if(Net_HAL_Read(NET_ID_HTTP, recv_buffer,sizeof(recv_buffer))>0)
            {
                Net_HAL_Write(NET_ID_HTTP, "client SEND..", 13);
                printf("\r\n[Net_HAL_OpenClint]recvbuf=%s",recv_buffer);
                
            }
            Net_HAL_Write(NET_ID_HTTP, buf, 5);
            //printf("\r\n2&xnetif[0]=%x,addr=%x",&xnetif[0],xnetif[0].ip_addr);
            Net_HAL_GetIP();
            wifi_get_mac_address(mac_buff);
            printf("\r\ngoon...%s\r\n",mac_buff);
            //vTaskDelay(2000);
            
        }
            
    
#endif
#endif   


#if  0 
	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = INADDR_ANY;

	if(bind(server_fd, (struct sockaddr *) &server_addr, sizeof(server_addr)) != 0) {
		printf("ERROR: bind\n");
		goto trx_exit;
	}
    
	if(listen(server_fd, LISTEN_QLEN) != 0) {
		printf("ERROR: listen\n");
		goto trx_exit;
	}
    
	while(1) {
		cli_addr_size = sizeof(cli_addr);
		client_fd = accept(server_fd, (struct sockaddr *) &cli_addr, &cli_addr_size);

		if(client_fd >= 0) {
			tx_exit = 1;
			rx_exit = 1;
			//RtlInitSema(&tcp_tx_rx_sema, 1);			
			rtw_init_sema(&tcp_tx_rx_sema, 1);

			if(xTaskCreate(tx_thread, ((const char*)"tx_thread"), 2048, &client_fd, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
				printf("\n\r%s xTaskCreate(tx_thread) failed", __FUNCTION__);
			else
				tx_exit = 0;

			vTaskDelay(10);

			if(xTaskCreate(rx_thread, ((const char*)"rx_thread"), 2048, &client_fd, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
				printf("\n\r%s xTaskCreate(rx_thread) failed", __FUNCTION__);
			else
				rx_exit = 0;

			while(1) {
				if(tx_exit && rx_exit) {
					close(client_fd);
                    printf("\r\nall end");
					break;
				}
				else
					vTaskDelay(1000);
			}

			//RtlFreeSema(&tcp_tx_rx_sema);			
			rtw_free_sema(&tcp_tx_rx_sema);
		}
	}
#endif
trx_exit:
	close(server_fd);
	vTaskDelete(NULL);
}

void example_socket_tcp_trx_1(void)
{
	if(xTaskCreate(example_socket_trx_thread, ((const char*)"example_socket_tcp_trx_thread"), 1024, NULL, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
		printf("\n\r%s xTaskCreate(example_socket_tcp_trx_thread) failed", __FUNCTION__);
}


/********************************************************/

#endif
