#ifndef EXAMPLE_HIGH_LOAD_MEMORY_USE_H
#define EXAMPLE_HIGH_LOAD_MEMORY_USE_H

#include <platform/platform_stdlib.h>
#include "platform_opts.h"

void example_high_load_memory_use(void);

#endif
