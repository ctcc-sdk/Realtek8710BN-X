#ifndef EXAMPLE_TCP_KEEPALIVE_H
#define EXAMPLE_TCP_KEEPALIVE_H

void example_tcp_keepalive(void);

#endif /* EXAMPLE_TCP_KEEPALIVE_H */
