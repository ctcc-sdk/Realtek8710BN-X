#ifndef EXAMPLE_SOCKET_SELECT_H
#define EXAMPLE_SOCKET_SELECT_H

void example_socket_select(void);

#endif /* EXAMPLE_SOCKET_SELECT_H */
