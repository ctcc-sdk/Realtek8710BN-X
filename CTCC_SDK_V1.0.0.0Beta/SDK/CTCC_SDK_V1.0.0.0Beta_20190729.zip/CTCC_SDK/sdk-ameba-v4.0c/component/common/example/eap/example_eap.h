#ifndef EXAMPLE_EAP_H
#define EXAMPLE_EAP_H

#include <platform/platform_stdlib.h>
#include "platform_opts.h"

void example_eap(char *method);

#endif
