#ifndef EXAMPLE_NONBLOCK_CONNECT_H
#define EXAMPLE_NONBLOCK_CONNECT_H

void example_nonblock_connect(void);

#endif /* EXAMPLE_NONBLOCK_CONNECT_H */
