#ifndef _EXAMPLE_INIC_H
#define _EXAMPLE_INIC_H

void example_inic(void);

#endif /* _EXAMPLE_INIC_H */

