#ifndef EXAMPLE_HTTPD_H
#define EXAMPLE_HTTPD_H

void example_httpd(void);

#endif /* EXAMPLE_HTTPD_H */
