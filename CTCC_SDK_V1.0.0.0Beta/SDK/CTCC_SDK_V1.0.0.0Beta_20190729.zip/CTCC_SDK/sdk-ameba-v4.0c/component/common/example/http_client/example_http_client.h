#ifndef __EXAMPLE_HTTP_CLIENT_H__
#define __EXAMPLE_HTTP_CLIENT_H__

/******************************************************************************
 *
 * Copyright(c) 2007 - 2015 Realtek Corporation. All rights reserved.
 *
 *
 ******************************************************************************/

void example_http_client(void);

#endif //#ifndef __EXAMPLE_HTTP_CLIENT_H__
