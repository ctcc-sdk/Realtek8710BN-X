
#include "device.h"
#include "serial_api.h"
#include "main.h"

/*********CMD START*********/
#define CMD_AP_NAME      "ATW3=RTL8195A"
#define CMD_AP_PASSWD    "ATW4=12345678"
#define CMD_AP_CHANNEL   "ATW5=1"
#define CMD_AP_START     "ATWB"

#define CMD_STA_SSID     "ATW0=het-test-wifi"
#define CMD_STA_PASSWD   "ATW1=12345678"
#define CMD_STA_START    "ATWC"

#define CMD_AP_STA_LIST  "ATW?"

/*********CMD END********/

#define UART_TX    PA_23//PA_30
#define UART_RX    PA_18//PA_29

volatile char rc=0;
typedef struct NODE 
{
//    unsigned char *a1;
//    unsigned short a2;
//    unsigned short a3;
//    unsigned int a4;
      unsigned char a5;
      unsigned char a6[6];
}TEST_STRUCT;
void uart_send_string(serial_t *sobj, char *pstr)
{
    unsigned int i=0;

    while (*(pstr+i) != 0) {
        serial_putc(sobj, *(pstr+i));
        i++;
    }
}

void uart_irq(uint32_t id, SerialIrq event)
{
    serial_t    *sobj = (void*)id;

    if(event == RxIrq) {
        rc = serial_getc(sobj);
        serial_putc(sobj, rc);
    }

    if(event == TxIrq && rc!=0){
        uart_send_string(sobj, "\r\n8195a$");
        rc = 0;
    }
}


static void example_uart_test_thread(void *param)
{
	
    serial_t    sobj;
    TEST_STRUCT test_a={0};

    // mbed uart test
    serial_init(&sobj,UART_TX,UART_RX);
    serial_baud(&sobj,9600);
    serial_format(&sobj, 8, ParityNone, 1);

    uart_send_string(&sobj, "UART IRQ API Demo...\r\n");
    uart_send_string(&sobj, "Hello World!!\n");
    uart_send_string(&sobj, "\r\n8195a$");
    serial_irq_handler(&sobj, uart_irq, (uint32_t)&sobj);
    serial_irq_set(&sobj, RxIrq, 1);
    serial_irq_set(&sobj, TxIrq, 1);
    printf("\r\nsize=%d",sizeof(test_a));
	while(1)
	{
		uart_send_string(&sobj,"\r\n#");
	    vTaskDelay(10000);
        
        
	}
}


void example_uart_test(void)
{
	if(xTaskCreate(example_uart_test_thread, ((const char*)"example_nonblock_connect_thread"), 2048, NULL, tskIDLE_PRIORITY + 1, NULL) != pdPASS)
		printf("\n\r%s xTaskCreate(init_thread) failed", __FUNCTION__);
}
