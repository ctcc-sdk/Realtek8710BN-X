#ifndef WIGADGET_H
#define WIGADGET_H

#define FLASH_IOT_DATA (0x0007E000)
#define PSEUDO_DATA		1

void example_wigadget(void);
void gen_json_data(char *i, char *j, unsigned char *json_data);

#endif /* WIGADGET_H */

