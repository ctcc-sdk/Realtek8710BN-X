#ifndef _ALC5616_H_
#define _ALC5616_H_
void alc5616_reg_dump(void);
void alc5616_index_dump(void);
void alc5616_init(void);
void alc5616_set_word_len(int len_idx);
void alc5616_init_interface1(void);
void alc5616_init_interface2(void);
#endif
